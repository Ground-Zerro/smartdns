import * as React from 'react';
import type { MRT_RowData as MRTRowData, MRT_TableOptions as MRTTableOptions, MRT_VisibilityState as MRTVisibilityState } from 'material-react-table';

export function compactTableOptions<T extends MRTRowData>(): Partial<MRTTableOptions<T>> {
  return {
    layoutMode: 'semantic',
    defaultColumn: { minSize: 10, size: 10 },
  };
}

function readVisibility(key: string, defaults: MRTVisibilityState): MRTVisibilityState {
  try {
    const saved = localStorage.getItem(key);
    return saved ? (JSON.parse(saved) as MRTVisibilityState) : defaults;
  } catch {
    return defaults;
  }
}

export function usePersistedVisibility(key: string, defaults: MRTVisibilityState): [MRTVisibilityState, NonNullable<MRTTableOptions<MRTRowData>['onColumnVisibilityChange']>] {
  const [visibility, setVisibility] = React.useState(() => readVisibility(key, defaults));
  const onChange = React.useCallback<NonNullable<MRTTableOptions<MRTRowData>['onColumnVisibilityChange']>>((updater) => {
    setVisibility((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      localStorage.setItem(key, JSON.stringify(next));
      return next;
    });
  }, [key]);
  return [visibility, onChange];
}
