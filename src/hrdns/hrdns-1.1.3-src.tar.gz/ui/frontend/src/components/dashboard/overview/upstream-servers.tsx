"use client";

import * as React from 'react';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import { smartdnsServer, type UpStreamServers } from '@/lib/backend/server';
import { useNames } from '@/lib/names';
import { useTranslation } from 'react-i18next';
import { CardLoading } from './card-loading';
import { CountBar, TopTable, type TopTableRow } from './top-table';

const typeNames: Record<string, string> = { udp: 'Do53', tcp: 'TCP', tls: 'DoT', https: 'DoH', quic: 'DoQ', http3: 'DoH3' };

interface Upstream {
  key: string;
  host: string;
  type: string;
  count: number;
  success: number;
  timeSum: number;
}

function upstreamLabel(server: Upstream): React.ReactNode {
  return (
    <>
      {server.host}
      <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>{server.type}</Typography>
    </>
  );
}

export function UpstreamCards(): React.JSX.Element {
  const { t } = useTranslation();
  const names = useNames();
  const [stats, setStats] = React.useState<UpStreamServers[] | null>(null);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  React.useEffect(() => {
    void smartdnsServer.GetUpstreamServers().then((data) => {
      if (data.error) {
        setErrorMsg(smartdnsServer.getErrorMessage(data.error));
        return;
      }
      setStats(data.data ?? []);
    });
  }, []);

  const servers = React.useMemo(() => {
    if (!stats) {
      return null;
    }
    const merged = new Map<string, Upstream>();
    for (const s of stats) {
      const type = typeNames[s.server_type] ?? s.server_type;
      const host = names?.server(s.host) ?? names?.server(s.ip) ?? s.host;
      const key = `${host}/${type}`;
      const entry = merged.get(key) ?? { key, host, type, count: 0, success: 0, timeSum: 0 };
      entry.count += s.total_query_count;
      entry.success += s.total_query_success;
      entry.timeSum += s.avg_time * s.total_query_success;
      merged.set(key, entry);
    }
    return [...merged.values()];
  }, [stats, names]);

  const list = servers ?? [];
  const total = list.reduce((sum, s) => sum + s.count, 0);
  const byCount: TopTableRow[] = list
    .filter((s) => s.count > 0)
    .map((s) => ({ key: s.key, name: s.host, label: upstreamLabel(s), sort: s.count, value: <CountBar count={s.count} total={total} /> }));
  const byTime: TopTableRow[] = list
    .filter((s) => s.success > 0)
    .map((s) => ({ server: s, time: s.timeSum / s.success }))
    .map(({ server, time }) => ({ key: server.key, name: server.host, label: upstreamLabel(server), sort: time, value: `${Math.round(time)} ${t('ms')}` }));

  return (
    <>
      <Grid size={{ lg: 6, md: 12, xs: 12 }}>
        <CardLoading title={t('Top Upstream Servers')} isLoading={servers === null} errorMsg={errorMsg}>
          <TopTable head={[t('Upstream Server'), t('Number of Queries')]} rows={byCount} />
        </CardLoading>
      </Grid>
      <Grid size={{ lg: 6, md: 12, xs: 12 }}>
        <CardLoading title={t('Upstream Response Time')} isLoading={servers === null} errorMsg={errorMsg}>
          <TopTable head={[t('Upstream Server'), t('Response Time')]} rows={byTime} />
        </CardLoading>
      </Grid>
    </>
  );
}
