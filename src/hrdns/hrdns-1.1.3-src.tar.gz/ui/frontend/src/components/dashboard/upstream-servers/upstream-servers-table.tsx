"use client"

import * as React from 'react';
import { useMemo, useState } from 'react';
import {
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnDef as MRTColumnDef,
} from 'material-react-table';
import { Card, IconButton, Tooltip } from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { createTheme, useColorScheme } from '@mui/material/styles';
import { type UpStreamServers, smartdnsServer } from '@/lib/backend/server';
import { useTranslation } from 'react-i18next';
import { MRT_Localization_RU } from 'material-react-table/locales/ru';
import { type SnackbarOrigin, SnackbarProvider } from 'notistack';
import { compactTableOptions, usePersistedVisibility } from '@/lib/mrt-table';

function TableUpstreamServers(): React.JSX.Element {
  const { t } = useTranslation();
  const [data, setData] = useState<UpStreamServers[]>([]);
  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [columnVisibility, onColumnVisibilityChange] = usePersistedVisibility('upstream-columns', {});

  const columns = useMemo<MRTColumnDef<UpStreamServers>[]>(
    () => [
      {
        accessorKey: 'host',
        header: t('Host'),
        enableSorting: false,
      },
      {
        accessorKey: 'ip',
        header: t('IP'),
        enableSorting: false,
      },
      {
        accessorKey: 'port',
        header: t('Port'),
        enableSorting: false,
      },
      {
        accessorKey: 'server_type',
        header: t('Type'),
      },
      {
        accessorKey: 'security',
        header: t('Security'),
      },
      {
        accessorKey: 'status',
        header: t('Status'),
      },
      {
        accessorKey: 'query_success_rate',
        header: t('Success Rate'),
        enableSorting: true,
        Cell: ({ cell }) => {
          const rate = cell.getValue<number>();
          return <span>{rate} %</span>;
        },
      },
      {
        accessorKey: 'avg_time',
        header: t('Avg Time'),
        enableSorting: true,
        Cell: ({ cell }) => {
          const avgTime = cell.getValue<number>();
          if (avgTime < 0) {
            return <span>N/A</span>;
          }
          return <span>{avgTime} ms</span>;
        },
      },
      {
        accessorKey: 'total_query_count',
        header: t('Total Query Count'),
        enableSorting: true,
      },
      {
        accessorKey: 'total_query_success',
        header: t('Total Success Number'),
        enableSorting: true,
      },
    ],
    [t],
  );

  const [errorMsg, setErrorMsg] = useState("");

  const fetchData = React.useCallback(async (): Promise<void> => {
    setIsLoading(true);
    const ret = await smartdnsServer.GetUpstreamServers();
    if (ret.error) {
      setErrorMsg(smartdnsServer.getErrorMessage(ret.error));
      setIsError(true);
      setIsLoading(false);
      return;
    }

    if (ret.data === null || ret.data === undefined) {
      setIsError(true);
      setErrorMsg(t('No data returned.'));
      setIsLoading(false);
      return;
    }

    const translatedData = ret.data.map((item: UpStreamServers) => ({
      ...item,
      security: t(item.security),
      status: t(item.status),
    }));

    setData(translatedData);
    setIsError(false);
    setIsLoading(false);
  }, [t]);

  React.useEffect(() => {
    fetchData().catch((_error: unknown) => {
      // NOOP
    });
  }, [fetchData]);


  const { colorScheme } = useColorScheme();
  const tableTheme = React.useMemo(
    () => createTheme({ palette: { mode: colorScheme === 'dark' ? 'dark' : 'light' } }),
    [colorScheme],
  );
  const baseBackgroundColor = tableTheme.palette.background.paper;

  const table = useMaterialReactTable({
    columns,
    data,
    localization: MRT_Localization_RU,
    ...compactTableOptions<UpStreamServers>(),
    enableColumnOrdering: false,
    enableColumnActions: false,
    enableColumnFilters: false,
    enableSorting: true,
    enableClickToCopy: window.isSecureContext,
    enableGlobalFilter: true,
    enableColumnFilterModes: false,
    enableColumnPinning: true,
    enableColumnDragging: false,
    enableKeyboardShortcuts: false,
    enablePagination: false,
    enableGlobalFilterRankedResults: false,
    muiToolbarAlertBannerProps: errorMsg.length > 0
      ? {
        color: 'error',
        children: errorMsg,
      }
      : undefined,
    renderTopToolbarCustomActions: () => (
      <Tooltip arrow title={t("Refresh Data")}>
        <IconButton onClick={async () => fetchData()}>
          <RefreshIcon />
        </IconButton>
      </Tooltip>
    ),
    onColumnVisibilityChange,
    initialState: {
      density: 'compact',
      showGlobalFilter: true,
    },
    state: {
      showAlertBanner: isError,
      showProgressBars: isLoading,
      showSkeletons: isLoading,
      columnVisibility,
    },
    mrtTheme: (_theme) => ({
      baseBackgroundColor,
    }),
  });

  return (<MaterialReactTable table={table} />);
};

export function UpstreamServersTable(): React.JSX.Element {

  const [state, setState] = React.useState<SnackbarOrigin>({
    vertical: 'top',
    horizontal: 'left',
  });

  React.useEffect(() => {
    const mediaQuery = window.matchMedia('(max-width: 600px)');
    const handleMediaQueryChange = (event: MediaQueryListEvent): void => {
      if (event.matches) {
        setState({ vertical: 'top', horizontal: 'left' });
      } else {
        setState({ vertical: 'bottom', horizontal: 'left' });
      }
    };

    if (mediaQuery.matches) {
      setState({ vertical: 'top', horizontal: 'left' });
    } else {
      setState({ vertical: 'bottom', horizontal: 'left' });
    }

    mediaQuery.addEventListener('change', handleMediaQueryChange);

    return () => {
      mediaQuery.removeEventListener('change', handleMediaQueryChange);
    };
  }, [setState]);

  return (
    <SnackbarProvider
      anchorOrigin={state}
      maxSnack={5} autoHideDuration={6000}>
      <Card>
        <TableUpstreamServers />
      </Card>
    </SnackbarProvider>
  );
}
