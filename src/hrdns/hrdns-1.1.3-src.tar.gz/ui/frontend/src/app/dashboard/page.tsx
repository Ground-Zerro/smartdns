"use client";

import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionDetails from '@mui/material/AccordionDetails';
import AccordionSummary from '@mui/material/AccordionSummary';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import { config } from '@/config';
import { TopClientsCard } from '@/components/dashboard/overview/top-clients';
import { TopDomainsCard } from '@/components/dashboard/overview/top-domain';
import { UpstreamCards } from '@/components/dashboard/overview/upstream-servers';
import { HourlyQueryCountCard } from '@/components/dashboard/overview/hourly-query-count';
import { useTranslation } from 'react-i18next';
import { DailyQueryCountCard } from '@/components/dashboard/overview/daily-query-count';
import { MetricsCards } from '@/components/dashboard/overview/metrics-cards';
import { type SnackbarOrigin, SnackbarProvider } from 'notistack';

export default function Page(): React.JSX.Element {

  const { t } = useTranslation();

  React.useEffect(() => {
    document.title = `${t('Overview')} | ${t('Dashboard')} | ${config.site.name}`;
  }, [t]);


  const [state, setState] = React.useState<SnackbarOrigin>({
    vertical: 'top',
    horizontal: 'left',
  });

  React.useEffect(() => {
    const mediaQuery = window.matchMedia('(max-width: 600px)');
    const handleMediaQueryChange = (event: MediaQueryListEvent): void => {
      if (event.matches) {
        setState({ vertical: 'top', horizontal: 'left' });
      } else {
        setState({ vertical: 'bottom', horizontal: 'left' });
      }
    };

    if (mediaQuery.matches) {
      setState({ vertical: 'top', horizontal: 'left' });
    } else {
      setState({ vertical: 'bottom', horizontal: 'left' });
    }

    mediaQuery.addEventListener('change', handleMediaQueryChange);

    return () => {
      mediaQuery.removeEventListener('change', handleMediaQueryChange);
    };
  }, [setState]);

  return (
    <SnackbarProvider
      anchorOrigin={state}
      maxSnack={5} autoHideDuration={6000}>
      <Grid container spacing={3}>
        <Grid size={{ lg: 12, xs: 12 }}>
          <MetricsCards />
        </Grid>
        <Grid size={{ lg: 4, md: 12, xs: 12 }}>
          <TopClientsCard />
        </Grid>
        <Grid size={{ lg: 4, md: 12, xs: 12 }}>
          <TopDomainsCard />
        </Grid>
        <Grid size={{ lg: 4, md: 12, xs: 12 }}>
          <TopDomainsCard blocked />
        </Grid>
        <UpstreamCards />
        <Grid size={{ lg: 12, xs: 12 }}>
          <Accordion disableGutters slotProps={{ transition: { unmountOnExit: true } }}>
            <AccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Typography variant="h6">{t('Query Charts')}</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <Grid container spacing={3}>
                <Grid size={{ lg: 12, xs: 12 }}>
                  <HourlyQueryCountCard sx={{ height: '100%', width: '100%' }} />
                </Grid>
                <Grid size={{ lg: 12, xs: 12 }}>
                  <DailyQueryCountCard sx={{ height: '100%', width: '100%' }} />
                </Grid>
              </Grid>
            </AccordionDetails>
          </Accordion>
        </Grid>
      </Grid>
    </SnackbarProvider>
  );
}
