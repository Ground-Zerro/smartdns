package bridge

import (
	"encoding/binary"
	"errors"
	"net/netip"
)

const (
	FlagBlocked = 1 << iota
	FlagCached
	FlagHasMAC
)

const queryFixed = 47

var ErrShortQuery = errors.New("bridge: short query event")

type Query struct {
	TimeMs     uint64
	QueryMs    uint32
	PingTenths int32
	QType      uint16
	RCode      uint8
	Flags      uint8
	Family     uint8
	Addr       [16]byte
	MAC        [6]byte
	BlockList  uint8
	Group      []byte
	Domain     []byte
}

func (q *Query) Decode(p []byte) error {
	if len(p) < queryFixed {
		return ErrShortQuery
	}

	q.TimeMs = binary.LittleEndian.Uint64(p[0:])
	q.QueryMs = binary.LittleEndian.Uint32(p[8:])
	q.PingTenths = int32(binary.LittleEndian.Uint32(p[12:]))
	q.QType = binary.LittleEndian.Uint16(p[16:])
	q.RCode = p[18]
	q.Flags = p[19]
	q.Family = p[20]
	copy(q.Addr[:], p[21:37])
	copy(q.MAC[:], p[37:43])
	q.BlockList = p[43]
	groupLen := int(p[44])
	domainLen := int(binary.LittleEndian.Uint16(p[45:]))
	if len(p) < queryFixed+groupLen+domainLen {
		return ErrShortQuery
	}

	q.Group = p[queryFixed : queryFixed+groupLen]
	q.Domain = p[queryFixed+groupLen : queryFixed+groupLen+domainLen]
	return nil
}

func (q *Query) Blocked() bool { return q.Flags&FlagBlocked != 0 }

func (q *Query) Cached() bool { return q.Flags&FlagCached != 0 }

func (q *Query) HasMAC() bool { return q.Flags&FlagHasMAC != 0 }

func (q *Query) Address() netip.Addr {
	switch q.Family {
	case 4:
		return netip.AddrFrom4([4]byte(q.Addr[:4]))
	case 6:
		return netip.AddrFrom16(q.Addr)
	}

	return netip.Addr{}
}
