package api

import (
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"strings"
	"syscall"
	"time"

	"hrdns-ui/internal/store"
	"hrdns-ui/internal/ws"
)

const statsMaxAge = time.Second

type resolverStats struct {
	CacheHitRate float64 `json:"cache_hit_rate"`
	AvgTime      float64 `json:"avg_time"`
	CacheNumber  int     `json:"cache_number"`
	CacheMemsize int64   `json:"cache_memsize"`
	Lost         uint64  `json:"lost"`
}

func (s *Server) resolverStats(r *http.Request) resolverStats {
	s.statsMu.Lock()
	defer s.statsMu.Unlock()
	if time.Since(s.statsAt) < statsMaxAge {
		return s.stats
	}

	var st resolverStats
	if data, err := s.call(r, "stats"); err == nil {
		json.Unmarshal(data, &st)
	}

	s.stats, s.statsAt = st, time.Now()
	return st
}

func residentBytes(pid int) uint64 {
	data, err := os.ReadFile("/proc/" + strconv.Itoa(pid) + "/statm")
	if err != nil {
		return 0
	}

	fields := strings.Fields(string(data))
	if len(fields) < 2 {
		return 0
	}

	pages, _ := strconv.ParseUint(fields[1], 10, 64)
	return pages * uint64(os.Getpagesize())
}

type metricsJSON struct {
	AvgQueryTime       float64 `json:"avg_query_time"`
	BlockQueryCount    uint64  `json:"block_query_count"`
	CacheHitRate       float64 `json:"cache_hit_rate"`
	CacheMemorySize    int64   `json:"cache_memory_size"`
	CacheNumber        int     `json:"cache_number"`
	FailQueryCount     uint64  `json:"fail_query_count"`
	IsMetricsSuspended bool    `json:"is_metrics_suspended"`
	MemoryUsage        uint64  `json:"memory_usage"`
	QPS                uint64  `json:"qps"`
	RequestDropCount   uint64  `json:"request_drop_count"`
	TotalQueryCount    uint64  `json:"total_query_count"`
}

func (s *Server) Metrics(r *http.Request) metricsJSON {
	total, blocked, failed := s.opts.Store.Totals()
	st := s.resolverStats(r)
	m := metricsJSON{
		AvgQueryTime: st.AvgTime, BlockQueryCount: blocked, CacheHitRate: st.CacheHitRate, CacheMemorySize: st.CacheMemsize,
		CacheNumber: st.CacheNumber, FailQueryCount: failed, QPS: s.opts.Store.Rate(), RequestDropCount: st.Lost, TotalQueryCount: total,
	}
	m.MemoryUsage = residentBytes(s.opts.ResolverPID)
	return m
}

func (s *Server) metrics(w http.ResponseWriter, r *http.Request) error {
	if ws.IsUpgrade(r) {
		return s.metricsStream(w, r)
	}

	writeJSON(w, http.StatusOK, s.Metrics(r))
	return nil
}

func freeBytes(path string) uint64 {
	var st syscall.Statfs_t
	if syscall.Statfs(path, &st) != nil {
		return 0
	}

	return uint64(st.Bavail) * uint64(st.Bsize)
}

func (s *Server) overview(w http.ResponseWriter, r *http.Request) error {
	out := struct {
		DatabaseSize       int64  `json:"database_size"`
		FreeDiskSpace      uint64 `json:"free_disk_space"`
		IsProcessSuspended bool   `json:"is_process_suspended"`
		ServerName         string `json:"server_name"`
		StartupTimestamp   int64  `json:"startup_timestamp"`
	}{DatabaseSize: s.opts.Store.LogBytes(), FreeDiskSpace: freeBytes(s.opts.DataDir)}
	hello := s.opts.Resolver.Hello()
	out.ServerName, out.StartupTimestamp = hello.ServerName, hello.StartedMs

	writeJSON(w, http.StatusOK, out)
	return nil
}

func (s *Server) statsRefresh(w http.ResponseWriter, r *http.Request) error {
	s.opts.Store.RefreshTops()
	writeNoContent(w)
	return nil
}

func bucketsJSON(list []store.Bucket, labelKey string) []map[string]any {
	out := make([]map[string]any, len(list))
	for i, b := range list {
		out[i] = map[string]any{labelKey: b.Label, "query_count": b.Count}
	}

	return out
}

func (s *Server) hourly(w http.ResponseWriter, r *http.Request) error {
	hours, err := params{r}.u64Default("past_hours", 24)
	if err != nil || hours == 0 || hours > 24*400 {
		return errBadParam
	}

	now := time.Now()
	writeJSON(w, http.StatusOK, map[string]any{
		"hourly_query_count": bucketsJSON(s.opts.Store.Hourly(int(hours), now), "hour"),
		"query_timestamp":    now.UnixMilli(),
	})
	return nil
}

func (s *Server) daily(w http.ResponseWriter, r *http.Request) error {
	days, err := params{r}.u64Default("past_days", 30)
	if err != nil || days == 0 || days > 400 {
		return errBadParam
	}

	now := time.Now()
	writeJSON(w, http.StatusOK, map[string]any{
		"daily_query_count": bucketsJSON(s.opts.Store.Daily(int(days), now), "day"),
		"query_timestamp":   now.UnixMilli(),
	})
	return nil
}

func (s *Server) topClient(w http.ResponseWriter, r *http.Request) error {
	count, err := params{r}.u64Default("count", 10)
	if err != nil {
		return err
	}

	list, start, end := s.opts.Store.TopClients(int(min(count, 1000)))
	out := make([]map[string]any, len(list))
	for i := range list {
		e := &list[i]
		out[i] = map[string]any{"client_ip": e.Addr(), "query_count": e.Count, "timestamp_start": start, "timestamp_end": end}
		if mac := macString(e.MAC()); mac != "" {
			out[i]["client_mac"] = mac
		}
	}

	writeJSON(w, http.StatusOK, map[string]any{"client_top_list": out})
	return nil
}

func (s *Server) topDomain(w http.ResponseWriter, r *http.Request) error {
	count, err := params{r}.u64Default("count", 10)
	if err != nil {
		return err
	}

	blocked, _ := params{r}.str("is_blocked")
	list, start, end := s.opts.Store.TopDomains(int(min(count, 1000)), blocked == "true")
	out := make([]map[string]any, len(list))
	for i, e := range list {
		out[i] = map[string]any{"domain": e.Name, "query_count": e.Count, "timestamp_start": start, "timestamp_end": end}
	}

	writeJSON(w, http.StatusOK, map[string]any{"domain_top_list": out})
	return nil
}
