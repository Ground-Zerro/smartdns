package api

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"sync"
	"time"

	"hrdns-ui/internal/bridge"
	"hrdns-ui/internal/store"
)

const (
	resolverTimeout = 5 * time.Second
	countBudget     = 3 * time.Second
)

type Resolver interface {
	Call(ctx context.Context, command string) (json.RawMessage, error)
	Hello() bridge.Hello
}

type Options struct {
	Store       *store.Store
	Resolver    Resolver
	Version     string
	DataDir     string
	Location    *time.Location
	ResolverPID int
	Subs        Subscriber
	Logs        *Hub
	Audit       *Hub
}

type Server struct {
	opts    Options
	statsMu sync.Mutex
	statsAt time.Time
	stats   resolverStats
}

func New(opts Options) *Server {
	if opts.Location == nil {
		opts.Location = time.Local
	}

	return &Server{opts: opts}
}

type apiError struct {
	status int
	msg    string
}

func (e *apiError) Error() string { return e.msg }

var (
	errBadParam = &apiError{http.StatusBadRequest, "Invalid parameter."}
	errNotFound = &apiError{http.StatusNotFound, "Not found"}
)

func writeJSON(w http.ResponseWriter, status int, v any) {
	data, err := json.Marshal(v)
	if err != nil {
		writeError(w, http.StatusInternalServerError, err.Error())
		return
	}

	h := w.Header()
	h.Set("Content-Type", "application/json")
	h.Set("Cache-Control", "no-cache")
	w.WriteHeader(status)
	w.Write(data)
}

func writeRaw(w http.ResponseWriter, status int, data []byte) {
	h := w.Header()
	h.Set("Content-Type", "application/json")
	h.Set("Cache-Control", "no-cache")
	w.WriteHeader(status)
	w.Write(data)
}

func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

func writeNoContent(w http.ResponseWriter) {
	h := w.Header()
	h.Set("Content-Type", "application/json")
	h.Set("Cache-Control", "no-cache")
	w.WriteHeader(http.StatusNoContent)
}

func fail(w http.ResponseWriter, err error) {
	var ae *apiError
	if errors.As(err, &ae) {
		writeError(w, ae.status, ae.msg)
		return
	}

	writeError(w, http.StatusInternalServerError, err.Error())
}

type handler func(w http.ResponseWriter, r *http.Request) error

func serve(h handler) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if err := h(w, r); err != nil {
			fail(w, err)
		}
	}
}

func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	route := func(pattern string, h handler) { mux.HandleFunc(pattern, serve(h)) }

	route("GET /api/server/version", s.version)

	route("GET /api/stats/overview", s.overview)
	route("GET /api/stats/metrics", s.metrics)
	route("GET /api/log/stream", s.logStream)
	route("GET /api/log/audit/stream", s.auditStream)
	route("PUT /api/stats/refresh", s.statsRefresh)
	route("GET /api/stats/hourly-query-count", s.hourly)
	route("GET /api/stats/daily-query-count", s.daily)
	route("GET /api/stats/top/client", s.topClient)
	route("GET /api/stats/top/domain", s.topDomain)

	route("GET /api/domain", s.domainList)
	route("GET /api/domain/count", s.domainCount)
	route("GET /api/domain/{id}", s.domainGet)
	route("DELETE /api/domain", s.domainClear)

	route("GET /api/cache/count", s.cacheCount)
	route("GET /api/cache/domains", s.cacheDomains)
	route("PUT /api/cache/flush", s.cacheFlush)
	route("GET /api/upstream-server", s.upstreamServers)
	route("GET /api/log/level", s.logLevelGet)
	route("PUT /api/log/level", s.logLevelPut)
	route("PUT /api/service/restart", s.restart)

	mux.HandleFunc("/api/", func(w http.ResponseWriter, r *http.Request) {
		writeError(w, http.StatusNotFound, "API not found.")
	})
	return mux
}

type params struct{ r *http.Request }

func (p params) str(key string) (string, bool) {
	q := p.r.URL.Query()
	if !q.Has(key) {
		return "", false
	}

	return q.Get(key), true
}

func (p params) u64(key string) (v uint64, ok bool, err error) {
	raw, ok := p.str(key)
	if !ok {
		return 0, false, nil
	}

	v, perr := strconv.ParseUint(raw, 10, 64)
	if perr != nil {
		return 0, false, errBadParam
	}

	return v, true, nil
}

func (p params) u64Default(key string, def uint64) (uint64, error) {
	v, ok, err := p.u64(key)
	if err != nil || !ok {
		return def, err
	}

	return v, nil
}

func (p params) tri(key string) (store.Tri, error) {
	raw, ok := p.str(key)
	if !ok {
		return store.Any, nil
	}

	switch raw {
	case "true":
		return store.Yes, nil
	case "false":
		return store.No, nil
	}

	return store.Any, errBadParam
}

func (s *Server) call(r *http.Request, command string) (json.RawMessage, error) {
	ctx, cancel := context.WithTimeout(r.Context(), resolverTimeout)
	defer cancel()
	return s.opts.Resolver.Call(ctx, command)
}

func itoa(n int) string { return strconv.Itoa(n) }

func (s *Server) version(w http.ResponseWriter, r *http.Request) error {
	writeJSON(w, http.StatusOK, map[string]string{"smartdns": s.opts.Resolver.Hello().Build, "smartdns_ui": s.opts.Version})
	return nil
}
