package api

import (
	"net"
	"net/http"
	"strconv"

	"hrdns-ui/internal/store"
)

func macString(mac [6]byte) string {
	if mac == ([6]byte{}) {
		return ""
	}

	return net.HardwareAddr(mac[:]).String()
}

type domainJSON struct {
	Client      string  `json:"client"`
	ClientMAC   string  `json:"client_mac,omitempty"`
	Domain      string  `json:"domain"`
	DomainGroup string  `json:"domain_group"`
	DomainType  uint16  `json:"domain_type"`
	ID          uint64  `json:"id"`
	IsBlocked   bool    `json:"is_blocked"`
	BlockList   uint8   `json:"block_list,omitempty"`
	IsCached    bool    `json:"is_cached"`
	PingTime    float64 `json:"ping_time"`
	QueryTime   uint32  `json:"query_time"`
	ReplyCode   uint8   `json:"reply_code"`
	Timestamp   int64   `json:"timestamp"`
}

func (s *Server) toDomainJSON(r *store.Record) domainJSON {
	return domainJSON{
		Client: r.Client, ClientMAC: macString(r.MAC), Domain: r.Domain, DomainGroup: r.Group, DomainType: r.QType, ID: r.ID,
		IsBlocked: r.Blocked, BlockList: r.BlockList, IsCached: r.Cached, PingTime: float64(r.PingTenths) / 10, QueryTime: r.QueryMs,
		ReplyCode: r.RCode, Timestamp: r.TimeMs,
	}
}

type pageJSON struct {
	ListCount    int    `json:"list_count"`
	StepByCursor bool   `json:"step_by_cursor"`
	TotalCount   uint64 `json:"total_count"`
	TotalPage    uint64 `json:"total_page"`
}

func totalPages(total uint64, size int) uint64 {
	n := total / uint64(size)
	if total%uint64(size) != 0 {
		n++
	}

	return n
}

type pageParams struct {
	spec  store.PageSpec
	id    uint64
	hasID bool
}

func parsePage(p params) (pageParams, error) {
	var out pageParams
	num, err := p.u64Default("page_num", 1)
	if err != nil {
		return out, err
	}

	size, err := p.u64Default("page_size", 10)
	if err != nil {
		return out, err
	}

	if num == 0 || size == 0 {
		return out, &apiError{http.StatusBadRequest, "Invalid parameter: page_num or page_size"}
	}

	out.spec.Num, out.spec.Size = int(num), int(size)
	if order, ok := p.str("order"); ok {
		switch order {
		case "asc", "ASC":
			out.spec.Asc = true
		case "desc", "DESC":
		default:
			return out, &apiError{http.StatusBadRequest, "order param error"}
		}
	}

	out.id, out.hasID, err = p.u64("id")
	if err != nil {
		return out, err
	}

	cursor, hasCursor, err := p.u64("cursor")
	if err != nil {
		return out, err
	}

	direction, _ := p.str("cursor_direction")
	switch direction {
	case "", "next":
	case "prev":
		out.spec.Prev = true
	default:
		return out, &apiError{http.StatusBadRequest, "cursor direction param error"}
	}

	total, hasTotal, err := p.u64("total_count")
	if err != nil {
		return out, err
	}

	out.spec.Cursor, out.spec.HasCursor = cursor, hasCursor
	out.spec.Total, out.spec.TotalGiven = total, hasTotal || hasCursor
	return out, nil
}

func parseFilter(p params) (store.Filter, error) {
	var f store.Filter
	var err error
	f.Domain, _ = p.str("domain")
	f.DomainMode, _ = p.str("domain_filter_mode")
	switch f.DomainMode {
	case "", "contains", "equals", "notempty":
		if f.DomainMode == "equals" {
			f.DomainMode = ""
		}
	default:
		return f, &apiError{http.StatusBadRequest, "domain_filter_mode param error"}
	}

	if raw, ok := p.str("domain_type"); ok {
		v, perr := strconv.ParseUint(raw, 10, 16)
		if perr != nil {
			return f, errBadParam
		}

		f.QType, f.HasQType = int(v), true
	}

	f.Client, _ = p.str("client")
	f.Group, f.HasGroup = p.str("domain_group")
	if raw, ok := p.str("reply_code"); ok {
		v, perr := strconv.ParseUint(raw, 10, 8)
		if perr != nil {
			return f, errBadParam
		}

		f.RCode, f.HasRCode = int(v), true
	}

	if f.Blocked, err = p.tri("is_blocked"); err != nil {
		return f, err
	}

	if f.Cached, err = p.tri("is_cached"); err != nil {
		return f, err
	}

	after, _, err := p.u64("timestamp_after")
	if err != nil {
		return f, err
	}

	before, _, err := p.u64("timestamp_before")
	if err != nil {
		return f, err
	}

	f.After, f.Before = int64(after), int64(before)
	return f, nil
}

func (s *Server) domainList(w http.ResponseWriter, r *http.Request) error {
	p := params{r}
	page, err := parsePage(p)
	if err != nil {
		return err
	}

	f, err := parseFilter(p)
	if err != nil {
		return err
	}

	out := struct {
		DomainList []domainJSON `json:"domain_list"`
		pageJSON
	}{DomainList: []domainJSON{}}

	if page.hasID {
		if rec, ok := s.opts.Store.Get(page.id); ok {
			out.DomainList = append(out.DomainList, s.toDomainJSON(&rec))
			out.TotalCount = 1
		}

		out.TotalPage = totalPages(out.TotalCount, page.spec.Size)
		out.ListCount = len(out.DomainList)
		writeJSON(w, http.StatusOK, out)
		return nil
	}

	res := s.opts.Store.List(&f, page.spec, countBudget)
	for i := range res.Records {
		out.DomainList = append(out.DomainList, s.toDomainJSON(&res.Records[i]))
	}

	out.ListCount = len(out.DomainList)
	out.StepByCursor = res.StepByCursor
	out.TotalCount = res.Total
	out.TotalPage = totalPages(res.Total, page.spec.Size)
	writeJSON(w, http.StatusOK, out)
	return nil
}

func (s *Server) domainCount(w http.ResponseWriter, r *http.Request) error {
	n, _ := s.opts.Store.Count(&store.Filter{}, 0)
	writeJSON(w, http.StatusOK, map[string]uint64{"count": n})
	return nil
}

func (s *Server) domainGet(w http.ResponseWriter, r *http.Request) error {
	id, err := strconv.ParseUint(r.PathValue("id"), 10, 64)
	if err != nil {
		return errBadParam
	}

	rec, ok := s.opts.Store.Get(id)
	if !ok {
		return errNotFound
	}

	writeJSON(w, http.StatusOK, s.toDomainJSON(&rec))
	return nil
}

func (s *Server) domainClear(w http.ResponseWriter, r *http.Request) error {
	before, ok, err := params{r}.u64("timestamp_before")
	if err != nil || !ok {
		return errBadParam
	}

	n, _ := s.opts.Store.Count(&store.Filter{}, 0)
	if n == 0 {
		return errNotFound
	}

	if latest := s.opts.Store.List(&store.Filter{}, store.PageSpec{Num: 1, Size: 1}, 0).Records; len(latest) == 1 && int64(before) < latest[0].TimeMs {
		return &apiError{http.StatusBadRequest, "Only a full clear is supported."}
	}

	if err := s.opts.Store.Clear(); err != nil {
		return err
	}

	writeJSON(w, http.StatusOK, map[string]uint64{"count": n})
	return nil
}
