package store

import (
	"bytes"
	"cmp"
	"encoding/binary"
	"errors"
	"os"
	"path/filepath"
	"slices"
	"sort"
	"sync"
	"time"
)

const (
	sumMagic    = "SUM1"
	dayTopLimit = 200
	mergedTop   = 1000
	topWindow   = 7

	hourBucketLayout = "2006-01-02T15:00:00-07:00"
	dayBucketLayout  = "2006-01-02T00:00:00-07:00"
)

type topName struct {
	Name  string
	Count uint64
}

type clientTop struct {
	Key   clientKey
	Count uint64
}

func (c *clientTop) Addr() string { return c.Key.addr() }

func (c *clientTop) MAC() [macLen]byte { return c.Key.mac() }

type daySum struct {
	slots   [slotsPerDay]uint32
	domains []topName
	clients []clientTop
	blocked []topName
}

type sumCache struct {
	mu   sync.Mutex
	days map[int64]*daySum
}

type tops struct {
	clients []clientTop
	domains []topName
	blocked []topName
	start   int64
	end     int64
}

func (s *Store) sumPath(day int64) string {
	return filepath.Join(s.sumDir(), dayName(day)+".bin")
}

var errBadSum = errors.New("store: bad summary")

func (s *Store) readSum(day int64) (*daySum, error) {
	data, err := os.ReadFile(s.sumPath(day))
	if err != nil {
		return nil, err
	}

	return parseSum(data)
}

func parseSum(data []byte) (*daySum, error) {
	if len(data) < len(sumMagic)+slotsPerDay*4+4 || string(data[:4]) != sumMagic {
		return nil, errBadSum
	}

	sum := &daySum{}
	off := 4
	for i := range sum.slots {
		sum.slots[i] = binary.LittleEndian.Uint32(data[off:])
		off += 4
	}

	count := func() (int, bool) {
		if off+2 > len(data) {
			return 0, false
		}

		n := int(binary.LittleEndian.Uint16(data[off:]))
		off += 2
		return n, true
	}

	names := func() ([]topName, bool) {
		n, ok := count()
		if !ok {
			return nil, false
		}

		out := make([]topName, 0, n)
		for i := 0; i < n; i++ {
			if off+6 > len(data) {
				return nil, false
			}

			hits := uint64(binary.LittleEndian.Uint32(data[off:]))
			l := int(binary.LittleEndian.Uint16(data[off+4:]))
			off += 6
			if off+l > len(data) {
				return nil, false
			}

			out = append(out, topName{Name: string(data[off : off+l]), Count: hits})
			off += l
		}

		return out, true
	}

	var ok bool
	if sum.domains, ok = names(); !ok {
		return nil, errBadSum
	}

	n, ok := count()
	if !ok {
		return nil, errBadSum
	}

	sum.clients = make([]clientTop, n)
	for i := range sum.clients {
		if off+4+clientKeyLen > len(data) {
			return nil, errBadSum
		}

		sum.clients[i].Count = uint64(binary.LittleEndian.Uint32(data[off:]))
		copy(sum.clients[i].Key[:], data[off+4:])
		off += 4 + clientKeyLen
	}

	if off < len(data) {
		if sum.blocked, ok = names(); !ok {
			return nil, errBadSum
		}
	}

	return sum, nil
}

func (c *current) topDomains(counts []uint32, limit int) []topName {
	ids := make([]uint32, 0, len(counts))
	for id, n := range counts {
		if n > 0 {
			ids = append(ids, uint32(id))
		}
	}

	slices.SortFunc(ids, func(a, b uint32) int { return int(counts[b]) - int(counts[a]) })
	if len(ids) > limit {
		ids = ids[:limit]
	}

	out := make([]topName, len(ids))
	for i, id := range ids {
		out[i] = topName{Name: string(c.doms.get(id)), Count: uint64(counts[id])}
	}

	return out
}

func appendNames(buf []byte, list []topName) []byte {
	buf = binary.LittleEndian.AppendUint16(buf, uint16(len(list)))
	for _, d := range list {
		buf = binary.LittleEndian.AppendUint32(buf, uint32(d.Count))
		buf = binary.LittleEndian.AppendUint16(buf, uint16(len(d.Name)))
		buf = append(buf, d.Name...)
	}

	return buf
}

func (c *current) topClients(limit int) []clientTop {
	ids := make([]int, 0, len(c.cliCounts))
	for id, n := range c.cliCounts {
		if n > 0 {
			ids = append(ids, id)
		}
	}

	slices.SortFunc(ids, func(a, b int) int { return int(c.cliCounts[b]) - int(c.cliCounts[a]) })
	if len(ids) > limit {
		ids = ids[:limit]
	}

	out := make([]clientTop, len(ids))
	for i, id := range ids {
		out[i] = clientTop{Key: c.clis[id], Count: uint64(c.cliCounts[id])}
	}

	return out
}

func (s *Store) writeSum(c *current) error {
	buf := make([]byte, 0, 4+slotsPerDay*4+4096)
	buf = append(buf, sumMagic...)
	for _, v := range c.slots {
		buf = binary.LittleEndian.AppendUint32(buf, v)
	}

	buf = appendNames(buf, c.topDomains(c.doms.counts, dayTopLimit))
	clients := c.topClients(dayTopLimit)
	buf = binary.LittleEndian.AppendUint16(buf, uint16(len(clients)))
	for _, t := range clients {
		buf = binary.LittleEndian.AppendUint32(buf, uint32(t.Count))
		buf = append(buf, t.Key[:]...)
	}

	buf = appendNames(buf, c.topDomains(c.doms.blocked, dayTopLimit))
	return atomicWrite(s.sumPath(c.day), buf)
}

func (s *Store) closedSum(day int64) *daySum {
	s.sums.mu.Lock()
	defer s.sums.mu.Unlock()
	if sum, ok := s.sums.days[day]; ok {
		return sum
	}

	sum, err := s.readSum(day)
	if err != nil {
		sum = nil
	}

	if s.sums.days == nil {
		s.sums.days = map[int64]*daySum{}
	}

	s.sums.days[day] = sum
	return sum
}

func (s *Store) pruneSums() {
	entries, err := os.ReadDir(s.sumDir())
	if err != nil {
		return
	}

	today := time.Now().UTC().Unix() / 86400
	for _, e := range entries {
		name := e.Name()
		if len(name) < len(dayLayout) {
			continue
		}

		if d, ok := parseDay(name[:len(dayLayout)]); ok && today-d >= sumKeepDays {
			os.Remove(filepath.Join(s.sumDir(), name))
			s.sums.mu.Lock()
			delete(s.sums.days, d)
			s.sums.mu.Unlock()
		}
	}
}

func (s *Store) liveSums(from, to int64) map[int64]*daySum {
	out := map[int64]*daySum{}
	s.mu.RLock()
	curDay := s.cur.day
	curSlots := s.cur.slots
	s.mu.RUnlock()
	for d := from; d <= to; d++ {
		if d == curDay {
			out[d] = &daySum{slots: curSlots}
		} else if sum := s.closedSum(d); sum != nil {
			out[d] = sum
		}
	}

	return out
}

type Bucket struct {
	Label string
	Count uint64
}

func (s *Store) Hourly(pastHours int, now time.Time) []Bucket {
	loc := s.cfg.Location
	local := now.In(loc)
	current := time.Date(local.Year(), local.Month(), local.Day(), local.Hour(), 0, 0, 0, loc)
	first := current.Add(-time.Duration(pastHours-1) * time.Hour)
	counts := map[int64]uint64{}
	sums := s.liveSums(first.UTC().Unix()/86400, now.UTC().Unix()/86400)
	for day, sum := range sums {
		for i, n := range sum.slots {
			if n == 0 {
				continue
			}

			t := time.UnixMilli(day*dayMillis + int64(i)*slotMillis).In(loc)
			bucket := time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), 0, 0, 0, loc)
			if !bucket.Before(first) && !bucket.After(current) {
				counts[bucket.Unix()] += uint64(n)
			}
		}
	}

	return orderedBuckets(counts, loc, hourBucketLayout)
}

func (s *Store) Daily(pastDays int, now time.Time) []Bucket {
	loc := s.cfg.Location
	local := now.In(loc)
	current := time.Date(local.Year(), local.Month(), local.Day(), 0, 0, 0, 0, loc)
	first := current.AddDate(0, 0, -(pastDays - 1))
	counts := map[int64]uint64{}
	sums := s.liveSums(first.UTC().Unix()/86400-1, now.UTC().Unix()/86400)
	for day, sum := range sums {
		for i, n := range sum.slots {
			if n == 0 {
				continue
			}

			t := time.UnixMilli(day*dayMillis + int64(i)*slotMillis).In(loc)
			bucket := time.Date(t.Year(), t.Month(), t.Day(), 0, 0, 0, 0, loc)
			if !bucket.Before(first) && !bucket.After(current) {
				counts[bucket.Unix()] += uint64(n)
			}
		}
	}

	return orderedBuckets(counts, loc, dayBucketLayout)
}

func orderedBuckets(counts map[int64]uint64, loc *time.Location, layout string) []Bucket {
	keys := make([]int64, 0, len(counts))
	for k := range counts {
		keys = append(keys, k)
	}

	sort.Slice(keys, func(i, j int) bool { return keys[i] > keys[j] })
	out := make([]Bucket, len(keys))
	for i, k := range keys {
		out[i] = Bucket{Label: time.Unix(k, 0).In(loc).Format(layout), Count: counts[k]}
	}

	return out
}

func mergeTop(into map[string]uint64, list []topName) {
	for _, e := range list {
		into[e.Name] += e.Count
	}
}

func mergeClients(into map[clientKey]uint64, list []clientTop) {
	for _, e := range list {
		into[e.Key] += e.Count
	}
}

func sortClients(list []clientTop) {
	slices.SortFunc(list, func(a, b clientTop) int {
		if a.Count != b.Count {
			return cmp.Compare(b.Count, a.Count)
		}

		return bytes.Compare(a.Key[:], b.Key[:])
	})
}

func rankClients(m map[clientKey]uint64, limit int) []clientTop {
	all := make([]clientTop, 0, len(m))
	for key, n := range m {
		all = append(all, clientTop{Key: key, Count: n})
	}

	sortClients(all)
	out := all[:0]
	byMAC := make(map[[macLen]byte]int, len(all))
	for _, e := range all {
		mac := e.Key.mac()
		if i, ok := byMAC[mac]; ok {
			out[i].Count += e.Count
			if out[i].Key[0] != 4 && e.Key[0] == 4 {
				out[i].Key = e.Key
			}

			continue
		}

		if mac != ([macLen]byte{}) {
			byMAC[mac] = len(out)
		}

		out = append(out, e)
	}

	sortClients(out)
	return out[:min(limit, len(out))]
}

func rankTop(m map[string]uint64, limit int) []topName {
	out := make([]topName, 0, len(m))
	for name, n := range m {
		out = append(out, topName{Name: name, Count: n})
	}

	sort.Slice(out, func(i, j int) bool {
		if out[i].Count != out[j].Count {
			return out[i].Count > out[j].Count
		}

		return out[i].Name < out[j].Name
	})
	if len(out) > limit {
		out = out[:limit]
	}

	return out
}

func (s *Store) refreshTops() {
	now := time.Now()
	domains := map[string]uint64{}
	blocked := map[string]uint64{}
	clients := map[clientKey]uint64{}
	s.mu.RLock()
	curDay := s.cur.day
	mergeTop(domains, s.cur.topDomains(s.cur.doms.counts, mergedTop))
	mergeTop(blocked, s.cur.topDomains(s.cur.doms.blocked, mergedTop))
	mergeClients(clients, s.cur.topClients(mergedTop))
	s.mu.RUnlock()
	for d := curDay - topWindow + 1; d < curDay; d++ {
		if sum := s.closedSum(d); sum != nil {
			mergeTop(domains, sum.domains)
			mergeTop(blocked, sum.blocked)
			mergeClients(clients, sum.clients)
		}
	}

	for name := range blocked {
		delete(domains, name)
	}

	t := tops{
		clients: rankClients(clients, mergedTop),
		domains: rankTop(domains, mergedTop),
		blocked: rankTop(blocked, mergedTop),
		end:     now.UnixMilli(),
		start:   now.UnixMilli() - topWindow*dayMillis,
	}
	s.topMu.Lock()
	s.tops = t
	s.topMu.Unlock()
}

func (s *Store) RefreshTops() { s.refreshTops() }

func (s *Store) TopClients(count int) ([]clientTop, int64, int64) {
	s.topMu.RLock()
	defer s.topMu.RUnlock()
	return s.tops.clients[:min(count, len(s.tops.clients))], s.tops.start, s.tops.end
}

func (s *Store) TopDomains(count int, blocked bool) ([]topName, int64, int64) {
	s.topMu.RLock()
	defer s.topMu.RUnlock()
	list := s.tops.domains
	if blocked {
		list = s.tops.blocked
	}

	return list[:min(count, len(list))], s.tops.start, s.tops.end
}
