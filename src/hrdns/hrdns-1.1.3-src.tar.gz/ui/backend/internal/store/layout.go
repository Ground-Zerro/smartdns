package store

const (
	dayMillis      = 86_400_000
	slotMillis     = 900_000
	slotsPerDay    = dayMillis / slotMillis
	idDayShift     = 27
	idIndexMask    = 1<<idDayShift - 1
	pingNone       = 0xFFFF
	addrLen        = 16
	macLen         = 6
	clientKeyLen   = 1 + addrLen + macLen
	maxGroups      = 255
	maxClients     = 65535
	maxDomains     = 262144
	overflowDomain = "(other)"
)

const (
	colTms = iota
	colDom
	colCli
	colGrp
	colQType
	colRCode
	colFlags
	colQms
	colPing
	colBlk
	numCols
)

const (
	dictDom = numCols + iota
	dictCli
	dictGrp
	numFiles
)

var (
	colWidth  = [numCols]int{4, 3, 2, 1, 2, 1, 1, 2, 2, 1}
	fileNames = [numFiles]string{"col-tms", "col-dom", "col-cli", "col-grp", "col-qtype", "col-rcode", "col-flags", "col-qms", "col-ping", "col-blk", "dict-dom", "dict-cli", "dict-grp"}
)

const (
	flagBlocked = 1
	flagCached  = 2
)

type rec struct {
	tms   uint32
	dom   uint32
	cli   uint16
	grp   uint8
	qtype uint16
	rcode uint8
	flags uint8
	qms   uint16
	ping  uint16
	blk   uint8
}

func appendRec(cols *[numCols][]byte, r *rec) {
	cols[colTms] = append(cols[colTms], byte(r.tms), byte(r.tms>>8), byte(r.tms>>16), byte(r.tms>>24))
	cols[colDom] = append(cols[colDom], byte(r.dom), byte(r.dom>>8), byte(r.dom>>16))
	cols[colCli] = append(cols[colCli], byte(r.cli), byte(r.cli>>8))
	cols[colGrp] = append(cols[colGrp], r.grp)
	cols[colQType] = append(cols[colQType], byte(r.qtype), byte(r.qtype>>8))
	cols[colRCode] = append(cols[colRCode], r.rcode)
	cols[colFlags] = append(cols[colFlags], r.flags)
	cols[colQms] = append(cols[colQms], byte(r.qms), byte(r.qms>>8))
	cols[colPing] = append(cols[colPing], byte(r.ping), byte(r.ping>>8))
	cols[colBlk] = append(cols[colBlk], r.blk)
}

func lateColumn(col int) bool { return col == colBlk }

func getU16(b []byte, i int) uint16 { return uint16(b[i*2]) | uint16(b[i*2+1])<<8 }

func getU24(b []byte, i int) uint32 {
	return uint32(b[i*3]) | uint32(b[i*3+1])<<8 | uint32(b[i*3+2])<<16
}

func getU32(b []byte, i int) uint32 {
	return uint32(b[i*4]) | uint32(b[i*4+1])<<8 | uint32(b[i*4+2])<<16 | uint32(b[i*4+3])<<24
}

func clampU16(v uint32) uint16 {
	if v > 0xFFFE {
		return 0xFFFE
	}

	return uint16(v)
}

func recordID(day int64, index int) uint64 {
	return uint64(day)<<idDayShift | uint64(index+1)
}

func splitID(id uint64) (day int64, index int) {
	return int64(id >> idDayShift), int(id&idIndexMask) - 1
}
