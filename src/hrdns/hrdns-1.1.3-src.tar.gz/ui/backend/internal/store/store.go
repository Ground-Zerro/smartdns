package store

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"sync/atomic"
	"time"

	"hrdns-ui/internal/bridge"
)

const (
	sumKeepDays = 90
	dayLayout   = "2006-01-02"
)

type Config struct {
	Dir        string
	Days       int
	MaxBytes   int64
	FlushEvery time.Duration
	Location   *time.Location
}

type current struct {
	day        int64
	dir        string
	files      [numFiles]*os.File
	sizes      [numFiles]int64
	pending    []rec
	colBuf     [numCols][]byte
	flushed    int
	doms       *domainTable
	domFlushed int
	clis       []clientKey
	cliMap     map[clientKey]uint16
	cliCounts  []uint32
	cliFlushed int
	grps       groupTable
	grpFlushed int
	slots      [slotsPerDay]uint32
}

type Store struct {
	cfg    Config
	mu     sync.RWMutex
	cur    *current
	days   []int64
	sums   sumCache
	topMu  sync.RWMutex
	tops   tops
	dictMu sync.Mutex
	dicts  []*dictView

	total   atomic.Uint64
	blocked atomic.Uint64
	failed  atomic.Uint64
	tick    atomic.Uint64
	rate    atomic.Uint64
	sizeLog atomic.Int64
	stop    chan struct{}
	done    chan struct{}
}

func dayName(day int64) string {
	return time.Unix(day*86400, 0).UTC().Format(dayLayout)
}

func parseDay(name string) (int64, bool) {
	t, err := time.Parse(dayLayout, name)
	if err != nil {
		return 0, false
	}

	return t.Unix() / 86400, true
}

func (s *Store) logDir() string { return filepath.Join(s.cfg.Dir, "log") }

func (s *Store) sumDir() string { return filepath.Join(s.cfg.Dir, "sum") }

func (s *Store) segDir(day int64) string { return filepath.Join(s.logDir(), dayName(day)) }

func Open(cfg Config) (*Store, error) {
	if cfg.Location == nil {
		cfg.Location = time.Local
	}

	s := &Store{cfg: cfg, stop: make(chan struct{}), done: make(chan struct{})}
	for _, dir := range []string{s.logDir(), s.sumDir()} {
		if err := os.MkdirAll(dir, 0o755); err != nil {
			return nil, err
		}
	}

	if err := s.loadState(); err != nil {
		return nil, err
	}

	days, err := s.listDays()
	if err != nil {
		return nil, err
	}

	cur := time.Now().UTC().Unix() / 86400
	if n := len(days); n > 0 && days[n-1] > cur {
		cur = days[n-1]
	}

	for _, d := range days {
		if d < cur {
			s.days = append(s.days, d)
		}
	}

	if err := s.openCurrent(cur); err != nil {
		return nil, err
	}

	s.enforceRetention()
	s.refreshTops()
	go s.run()
	return s, nil
}

func (s *Store) listDays() ([]int64, error) {
	entries, err := os.ReadDir(s.logDir())
	if err != nil {
		return nil, err
	}

	var days []int64
	for _, e := range entries {
		if d, ok := parseDay(e.Name()); ok && e.IsDir() {
			days = append(days, d)
		}
	}

	sort.Slice(days, func(i, j int) bool { return days[i] < days[j] })
	return days, nil
}

func (s *Store) run() {
	defer close(s.done)
	flush := time.NewTicker(s.cfg.FlushEvery)
	second := time.NewTicker(time.Second)
	hour := time.NewTicker(time.Hour)
	defer flush.Stop()
	defer second.Stop()
	defer hour.Stop()
	for {
		select {
		case <-s.stop:
			return
		case <-second.C:
			s.rate.Store(s.tick.Swap(0))
		case <-flush.C:
			s.Flush()
		case <-hour.C:
			s.refreshTops()
		}
	}
}

func (s *Store) Close() error {
	close(s.stop)
	<-s.done
	err := s.Flush()
	s.mu.Lock()
	s.closeCurrent()
	s.mu.Unlock()
	return err
}

func (s *Store) Rate() uint64 { return s.rate.Load() }

func (s *Store) openCurrent(day int64) error {
	c := &current{day: day, dir: s.segDir(day), doms: newDomainTable(), cliMap: map[clientKey]uint16{}}
	if err := os.MkdirAll(c.dir, 0o755); err != nil {
		return err
	}

	for i, name := range fileNames {
		f, err := os.OpenFile(filepath.Join(c.dir, name), os.O_CREATE|os.O_RDWR, 0o644)
		if err != nil {
			return err
		}

		c.files[i] = f
	}

	if err := s.restore(c); err != nil {
		return err
	}

	s.cur = c
	return nil
}

func (c *current) closeFiles() {
	for _, f := range c.files {
		if f != nil {
			f.Close()
		}
	}
}

func (s *Store) closeCurrent() {
	if s.cur != nil {
		s.cur.closeFiles()
		s.cur = nil
	}
}

func readAll(f *os.File) ([]byte, error) {
	st, err := f.Stat()
	if err != nil {
		return nil, err
	}

	b := make([]byte, st.Size())
	if _, err := f.ReadAt(b, 0); err != nil && len(b) > 0 {
		return nil, err
	}

	return b, nil
}

func (s *Store) restore(c *current) error {
	dom, err := readAll(c.files[dictDom])
	if err != nil {
		return err
	}

	valid := c.doms.load(dom)
	c.domFlushed = valid
	c.sizes[dictDom] = int64(valid)
	if valid != len(dom) {
		if err := c.files[dictDom].Truncate(int64(valid)); err != nil {
			return err
		}
	}

	cli, err := readAll(c.files[dictCli])
	if err != nil {
		return err
	}

	n := min(len(cli)/clientKeyLen, maxClients)
	for i := 0; i < n; i++ {
		var k clientKey
		copy(k[:], cli[i*clientKeyLen:])
		c.clis = append(c.clis, k)
		c.cliMap[k] = uint16(i)
	}

	c.cliCounts = make([]uint32, n)
	c.cliFlushed = n
	c.sizes[dictCli] = int64(n * clientKeyLen)
	if len(cli) != n*clientKeyLen {
		if err := c.files[dictCli].Truncate(int64(n * clientKeyLen)); err != nil {
			return err
		}
	}

	grp, err := readAll(c.files[dictGrp])
	if err != nil {
		return err
	}

	off := 0
	for off < len(grp) && off+1+int(grp[off]) <= len(grp) {
		c.grps.names = append(c.grps.names, string(grp[off+1:off+1+int(grp[off])]))
		off += 1 + int(grp[off])
	}

	c.grpFlushed = len(c.grps.names)
	c.sizes[dictGrp] = int64(off)
	if off != len(grp) {
		if err := c.files[dictGrp].Truncate(int64(off)); err != nil {
			return err
		}
	}

	return s.restoreRecords(c)
}

func (s *Store) restoreRecords(c *current) error {
	records := -1
	for i := 0; i < numCols; i++ {
		if lateColumn(i) {
			continue
		}

		st, err := c.files[i].Stat()
		if err != nil {
			return err
		}

		n := int(st.Size()) / colWidth[i]
		if records < 0 || n < records {
			records = n
		}
	}

	var data [4][]byte
	for i, col := range []int{colTms, colDom, colCli, colFlags} {
		data[i] = make([]byte, records*colWidth[col])
		if _, err := c.files[col].ReadAt(data[i], 0); err != nil && records > 0 {
			return err
		}
	}

	valid := 0
	for ; valid < records; valid++ {
		tms, dom, cli := getU32(data[0], valid), getU24(data[1], valid), getU16(data[2], valid)
		if tms >= dayMillis || int(dom) >= c.doms.count() || int(cli) >= len(c.clis) {
			break
		}

		c.doms.counts[dom]++
		if data[3][valid]&flagBlocked != 0 {
			c.doms.blocked[dom]++
		}

		c.cliCounts[cli]++
		c.slots[tms/slotMillis]++
	}

	for i := 0; i < numCols; i++ {
		size := int64(valid * colWidth[i])
		st, err := c.files[i].Stat()
		if err != nil {
			return err
		}

		if st.Size() != size {
			if err := c.files[i].Truncate(size); err != nil {
				return err
			}
		}

		c.sizes[i] = size
	}

	c.flushed = valid
	if sum, err := s.readSum(c.day); err == nil {
		for i, v := range sum.slots {
			c.slots[i] = max(c.slots[i], v)
		}
	}

	return nil
}

func (s *Store) Add(q *bridge.Query) {
	s.total.Add(1)
	s.tick.Add(1)
	if q.Blocked() {
		s.blocked.Add(1)
	}

	if q.RCode != 0 {
		s.failed.Add(1)
	}

	s.mu.Lock()
	c := s.cur
	if c == nil {
		s.mu.Unlock()
		return
	}

	day := int64(q.TimeMs / dayMillis)
	if day > c.day {
		s.rolloverLocked(day)
		c = s.cur
	}

	tms := uint32(0)
	if day == c.day {
		tms = uint32(q.TimeMs % dayMillis)
	}

	var mac [macLen]byte
	if q.HasMAC() {
		mac = q.MAC
	}

	key := makeClientKey(q.Family, q.Addr, mac)
	cli, ok := c.cliMap[key]
	if !ok {
		cli = s.addClientLocked(c, key)
	}

	r := rec{
		tms:   tms,
		dom:   c.doms.intern(q.Domain),
		cli:   cli,
		grp:   c.grps.intern(q.Group),
		qtype: q.QType,
		rcode: q.RCode,
		qms:   clampU16(q.QueryMs),
		ping:  pingValue(q.PingTenths),
		blk:   q.BlockList,
	}
	if q.Blocked() {
		r.flags |= flagBlocked
	}

	if q.Cached() {
		r.flags |= flagCached
	}

	c.doms.counts[r.dom]++
	if q.Blocked() {
		c.doms.blocked[r.dom]++
	}

	c.cliCounts[cli]++
	c.slots[tms/slotMillis]++
	c.pending = append(c.pending, r)
	s.mu.Unlock()
}

func pingValue(tenths int32) uint16 {
	if tenths < 0 {
		return pingNone
	}

	return clampU16(uint32(tenths))
}

func (s *Store) addClientLocked(c *current, key clientKey) uint16 {
	if len(c.clis) >= maxClients {
		return maxClients - 1
	}

	id := uint16(len(c.clis))
	c.clis = append(c.clis, key)
	c.cliCounts = append(c.cliCounts, 0)
	c.cliMap[key] = id
	return id
}

var errClosed = errors.New("store: closed")

func (s *Store) Flush() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.cur == nil {
		return errClosed
	}

	return s.flushLocked()
}

func (s *Store) flushLocked() error {
	c := s.cur
	if err := c.writeTail(dictDom, c.doms.arena[c.domFlushed:]); err != nil {
		return err
	}

	c.domFlushed = len(c.doms.arena)
	var buf []byte
	for _, k := range c.clis[c.cliFlushed:] {
		buf = append(buf, k[:]...)
	}

	if err := c.writeTail(dictCli, buf); err != nil {
		return err
	}

	c.cliFlushed = len(c.clis)
	buf = buf[:0]
	for _, name := range c.grps.names[c.grpFlushed:] {
		buf = append(buf, byte(len(name)))
		buf = append(buf, name...)
	}

	if err := c.writeTail(dictGrp, buf); err != nil {
		return err
	}

	c.grpFlushed = len(c.grps.names)
	for i := range c.pending {
		appendRec(&c.colBuf, &c.pending[i])
	}

	for col := 0; col < numCols; col++ {
		if err := c.writeTail(col, c.colBuf[col]); err != nil {
			c.rollbackColumns()
			return err
		}
	}

	for col := range c.colBuf {
		c.colBuf[col] = c.colBuf[col][:0]
	}

	c.flushed += len(c.pending)
	c.pending = c.pending[:0]
	s.sizeLog.Store(s.diskUsage())
	if err := s.writeSum(c); err != nil {
		return err
	}

	return s.saveState()
}

func (c *current) rollbackColumns() {
	for col := 0; col < numCols; col++ {
		size := int64(c.flushed * colWidth[col])
		c.files[col].Truncate(size)
		c.sizes[col] = size
		c.colBuf[col] = c.colBuf[col][:0]
	}
}

func (c *current) writeTail(file int, b []byte) error {
	if len(b) == 0 {
		return nil
	}

	f := c.files[file]
	if _, err := f.WriteAt(b, c.sizes[file]); err != nil {
		return err
	}

	c.sizes[file] += int64(len(b))
	return f.Sync()
}

func (s *Store) rolloverLocked(day int64) {
	s.flushLocked()
	old := s.cur
	if err := s.openCurrent(day); err != nil {
		s.cur = old
		return
	}

	old.closeFiles()
	s.days = append(s.days, old.day)
	s.enforceRetentionLocked()
	s.pruneSums()
}

func (s *Store) enforceRetention() {
	s.mu.Lock()
	s.enforceRetentionLocked()
	s.mu.Unlock()
	s.pruneSums()
}

func (s *Store) enforceRetentionLocked() {
	limit := s.cfg.Days
	if limit < 1 {
		limit = 1
	}

	for len(s.days) > limit-1 {
		s.dropOldestLocked()
	}

	for len(s.days) > 0 && s.diskUsage() > s.cfg.MaxBytes {
		s.dropOldestLocked()
	}

	s.sizeLog.Store(s.diskUsage())
}

func (s *Store) dropOldestLocked() {
	os.RemoveAll(s.segDir(s.days[0]))
	s.forgetDict(s.days[0])
	s.days = s.days[1:]
}

func (s *Store) diskUsage() int64 {
	var total int64
	filepath.WalkDir(s.logDir(), func(_ string, d os.DirEntry, err error) error {
		if err == nil && !d.IsDir() {
			if info, err := d.Info(); err == nil {
				total += info.Size()
			}
		}

		return nil
	})
	return total
}

func (s *Store) Clear() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if err := s.flushLocked(); err != nil {
		return err
	}

	day := s.cur.day
	s.closeCurrent()
	s.dictMu.Lock()
	s.dicts = nil
	s.dictMu.Unlock()
	if err := os.RemoveAll(s.logDir()); err != nil {
		return err
	}

	if err := os.MkdirAll(s.logDir(), 0o755); err != nil {
		return err
	}

	s.days = nil
	s.sizeLog.Store(0)
	if err := s.openCurrent(day); err != nil {
		return fmt.Errorf("store: reopen after clear: %w", err)
	}

	return nil
}

func (s *Store) LogBytes() int64 { return s.sizeLog.Load() }
