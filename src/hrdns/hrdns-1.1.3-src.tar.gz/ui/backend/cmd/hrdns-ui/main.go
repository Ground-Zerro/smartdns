package main

import (
	"context"
	"flag"
	"fmt"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"strings"
	"syscall"
	"time"

	webui "hrdns-ui"
	"hrdns-ui/internal/api"
	"hrdns-ui/internal/bridge"
	"hrdns-ui/internal/store"
	"hrdns-ui/internal/tz"
	"hrdns-ui/internal/www"
)

var version = "dev"

const (
	bridgeFD      = 3
	zoneFile      = "/var/TZ"
	defaultListen = "unix:/var/run/hrdns-ui.sock"
	coreLogNotice = 2
	coreLogWarn   = 3
)

type coreLog struct{ client *bridge.Client }

func (w coreLog) Write(p []byte) (int, error) {
	w.client.Log(coreLogWarn, strings.TrimSuffix(string(p), "\n"))
	return len(p), nil
}

type ingest struct {
	store *store.Store
	logs  *api.Hub
	audit *api.Hub
}

func (i *ingest) OnQuery(q *bridge.Query) { i.store.Add(q) }

func (i *ingest) OnLog(level byte, text []byte) {
	if i.logs.Active() {
		i.logs.Publish(append([]byte{0, level}, text...))
	}
}

func (i *ingest) OnAudit(text []byte) {
	if i.audit.Active() {
		i.audit.Publish(append([]byte{0}, text...))
	}
}

func (i *ingest) OnLost(count uint32) { log.Printf("resolver dropped %d events", count) }

func listen(spec string) (net.Listener, error) {
	if path, ok := strings.CutPrefix(spec, "unix:"); ok {
		os.Remove(path)
		old := syscall.Umask(0o077)
		defer syscall.Umask(old)
		return net.Listen("unix", path)
	}

	host, _, err := net.SplitHostPort(spec)
	if err != nil {
		return nil, fmt.Errorf("invalid listen address %q: %w", spec, err)
	}

	if ip := net.ParseIP(host); ip == nil || !ip.IsLoopback() {
		return nil, fmt.Errorf("invalid listen address %q: only unix:path or a loopback address is allowed", spec)
	}

	return net.Listen("tcp", spec)
}

func run() error {
	listenSpec := flag.String("listen", defaultListen, "listen address: unix:path or a loopback ip:port")
	dataDir := flag.String("data", "/opt/etc/HydraRoute/dns", "data directory")
	days := flag.Int("days", 7, "query log retention in days")
	maxMB := flag.Int("max-mb", 256, "query log size limit in MB")
	flushSeconds := flag.Int("flush", 300, "query log flush period in seconds")
	showVersion := flag.Bool("version", false, "print the version and exit")
	flag.Parse()
	if *showVersion {
		fmt.Println(version)
		return nil
	}

	client, err := bridge.FromFD(bridgeFD)
	if err != nil {
		return err
	}

	log.SetOutput(coreLog{client})
	time.Local = tz.Load(zoneFile)
	if err := os.MkdirAll(*dataDir, 0o755); err != nil {
		return err
	}

	st, err := store.Open(store.Config{Dir: *dataDir, Days: *days, MaxBytes: int64(*maxMB) << 20, FlushEvery: time.Duration(*flushSeconds) * time.Second})
	if err != nil {
		return err
	}

	defer st.Close()

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	logs, audit := api.NewHub(), api.NewHub()
	resolver := bridge.NewManager(client, &ingest{store: st, logs: logs, audit: audit})
	resolverDone := make(chan error, 1)
	go func() { resolverDone <- resolver.Run(ctx) }()

	srv := api.New(api.Options{
		Store:       st,
		Resolver:    resolver,
		Version:     version,
		DataDir:     *dataDir,
		ResolverPID: os.Getppid(),
		Subs:        resolver,
		Logs:        logs,
		Audit:       audit,
	})
	assets, err := fs.Sub(webui.Assets, "www")
	if err != nil {
		return err
	}

	static, err := www.New(assets)
	if err != nil {
		return err
	}

	mux := http.NewServeMux()
	mux.Handle("/api/", srv.Handler())
	mux.Handle("/", static)
	ln, err := listen(*listenSpec)
	if err != nil {
		return err
	}

	httpSrv := &http.Server{Handler: mux, ReadHeaderTimeout: 10 * time.Second, IdleTimeout: 2 * time.Minute}
	failed := make(chan error, 1)
	go func() { failed <- httpSrv.Serve(ln) }()
	client.Log(coreLogNotice, fmt.Sprintf("hrdns-ui %s listening on %s, journal %s", version, *listenSpec, *dataDir))

	select {
	case err := <-failed:
		return err
	case err := <-resolverDone:
		if err == nil {
			break
		}

		return fmt.Errorf("resolver connection lost: %w", err)
	case <-ctx.Done():
	}

	return httpSrv.Close()
}

func main() {
	runtime.GOMAXPROCS(1)
	log.SetFlags(0)
	if err := run(); err != nil {
		log.Fatal(err)
	}
}
