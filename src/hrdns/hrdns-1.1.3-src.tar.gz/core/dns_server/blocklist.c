#include "smartdns/blocklist.h"
#include "smartdns/tlog.h"
#include "smartdns/util.h"

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#define BLOCKLIST_MAGIC 0x4852424CU
#define BLOCKLIST_VERSION 1
#define BLOCKLIST_HEADER_SIZE 16
#define BLOCKLIST_RELEASE_DELAY_MS 10000

struct blocklist_map {
	void *addr;
	size_t size;
	const uint64_t *block;
	const uint64_t *allow;
	uint32_t block_num;
	uint32_t allow_num;
	struct blocklist_map *next;
	unsigned long retired_tick;
};

static char blocklist_path[PATH_MAX];
static struct blocklist_map *blocklist_current;
static struct blocklist_map *blocklist_retired;
static struct stat blocklist_seen;

int blocklist_conf_file(void *data, int argc, char *argv[])
{
	if (argc < 2 || strlen(argv[1]) >= sizeof(blocklist_path)) {
		tlog(TLOG_ERROR, "invalid block-file.");
		return -1;
	}

	safe_strncpy(blocklist_path, argv[1], sizeof(blocklist_path));
	return 0;
}

static void _blocklist_unmap(struct blocklist_map *map)
{
	munmap(map->addr, map->size);
	free(map);
}

static struct blocklist_map *_blocklist_open(void)
{
	uint32_t header[4];
	struct stat st;
	int fd = open(blocklist_path, O_RDONLY | O_CLOEXEC);
	if (fd < 0) {
		return NULL;
	}

	struct blocklist_map *map = NULL;
	if (pread(fd, header, sizeof(header), 0) != (ssize_t)sizeof(header)) {
		tlog(TLOG_WARN, "block-file %s: short header.", blocklist_path);
		goto out;
	}

	if (header[0] == __builtin_bswap32(BLOCKLIST_MAGIC)) {
		tlog(TLOG_WARN, "block-file %s: foreign byte order.", blocklist_path);
		goto out;
	}

	if (header[0] != BLOCKLIST_MAGIC || header[1] != BLOCKLIST_VERSION) {
		tlog(TLOG_WARN, "block-file %s: bad magic or version.", blocklist_path);
		goto out;
	}

	uint64_t size = BLOCKLIST_HEADER_SIZE + 8 * ((uint64_t)header[2] + header[3]);
	if (fstat(fd, &st) != 0 || (uint64_t)st.st_size != size || size > SIZE_MAX) {
		tlog(TLOG_WARN, "block-file %s: size mismatch.", blocklist_path);
		goto out;
	}

	void *addr = mmap(NULL, size, PROT_READ, MAP_SHARED, fd, 0);
	if (addr == MAP_FAILED) {
		tlog(TLOG_WARN, "block-file %s: mmap failed, %s.", blocklist_path, strerror(errno));
		goto out;
	}

	map = malloc(sizeof(*map));
	if (map == NULL) {
		munmap(addr, size);
		goto out;
	}

	map->addr = addr;
	map->size = size;
	map->block = (const uint64_t *)((const char *)addr + BLOCKLIST_HEADER_SIZE);
	map->allow = map->block + header[2];
	map->block_num = header[2];
	map->allow_num = header[3];
	tlog(TLOG_INFO, "block-file %s loaded: %u block, %u allow.", blocklist_path, header[2], header[3]);
out:
	close(fd);
	return map;
}

static void _blocklist_replace(struct blocklist_map *map)
{
	struct blocklist_map *old = __atomic_exchange_n(&blocklist_current, map, __ATOMIC_ACQ_REL);
	if (old != NULL) {
		old->retired_tick = get_tick_count();
		old->next = blocklist_retired;
		blocklist_retired = old;
	}
}

static void _blocklist_release_retired(void)
{
	unsigned long now = get_tick_count();
	struct blocklist_map **link = &blocklist_retired;
	while (*link != NULL) {
		struct blocklist_map *map = *link;
		if (now - map->retired_tick < BLOCKLIST_RELEASE_DELAY_MS) {
			link = &map->next;
			continue;
		}
		*link = map->next;
		_blocklist_unmap(map);
	}
}

void blocklist_check_update(void)
{
	struct stat st;

	if (blocklist_path[0] == '\0') {
		return;
	}

	_blocklist_release_retired();

	if (stat(blocklist_path, &st) != 0) {
		memset(&blocklist_seen, 0, sizeof(blocklist_seen));
		if (blocklist_current != NULL) {
			_blocklist_replace(NULL);
			tlog(TLOG_INFO, "block-file %s removed.", blocklist_path);
		}
		return;
	}

	if (st.st_ino == blocklist_seen.st_ino && st.st_size == blocklist_seen.st_size &&
		st.st_mtime == blocklist_seen.st_mtime) {
		return;
	}
	blocklist_seen = st;

	struct blocklist_map *map = _blocklist_open();
	if (map != NULL) {
		_blocklist_replace(map);
	}
}

static uint64_t _blocklist_key(const char *name)
{
	uint64_t hash = 0xcbf29ce484222325ULL;
	for (const unsigned char *p = (const unsigned char *)name; *p != '\0'; p++) {
		hash = (hash ^ *p) * 0x100000001b3ULL;
	}
	return hash >> 8;
}

static const uint64_t *_blocklist_find(const uint64_t *entries, uint32_t num, uint64_t key)
{
	uint32_t lo = 0;
	uint32_t hi = num;
	while (lo < hi) {
		uint32_t mid = lo + (hi - lo) / 2;
		if (entries[mid] >> 8 < key) {
			lo = mid + 1;
		} else {
			hi = mid;
		}
	}
	return lo < num && entries[lo] >> 8 == key ? &entries[lo] : NULL;
}

static const char *_blocklist_parent(const char *name)
{
	const char *dot = strchr(name, '.');
	return dot != NULL && dot[1] != '\0' ? dot + 1 : NULL;
}

int blocklist_match(const char *domain)
{
	const struct blocklist_map *map = __atomic_load_n(&blocklist_current, __ATOMIC_ACQUIRE);
	const uint64_t *hit = NULL;

	if (map == NULL || domain[0] == '\0') {
		return 0;
	}

	for (const char *name = domain; name != NULL && hit == NULL; name = _blocklist_parent(name)) {
		hit = _blocklist_find(map->block, map->block_num, _blocklist_key(name));
	}

	if (hit == NULL) {
		return 0;
	}

	for (const char *name = domain; name != NULL; name = _blocklist_parent(name)) {
		if (_blocklist_find(map->allow, map->allow_num, _blocklist_key(name)) != NULL) {
			return 0;
		}
	}

	return *hit & 0xff;
}
