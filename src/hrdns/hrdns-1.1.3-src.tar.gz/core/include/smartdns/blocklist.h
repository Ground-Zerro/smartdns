#ifndef _SMARTDNS_BLOCKLIST_H_
#define _SMARTDNS_BLOCKLIST_H_

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

int blocklist_conf_file(void *data, int argc, char *argv[]);

void blocklist_check_update(void);

int blocklist_match(const char *domain);

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
