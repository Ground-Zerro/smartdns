/*************************************************************************
 *
 * Copyright (C) 2018-2025 Ruilin Peng (Nick) <pymumu@gmail.com>.
 *
 * smartdns is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * smartdns is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#define _GNU_SOURCE

#include "smartdns/dns_plugin.h"

#include "smartdns/dns_conf.h"
#include "smartdns/lib/list.h"
#include "smartdns/tlog.h"
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

struct dns_plugin_ops {
	struct list_head list;
	struct smartdns_operations ops;
};

struct dns_plugins {
	struct list_head list;
	pthread_rwlock_t lock;
};

static struct dns_plugins plugins;
static atomic_t is_plugin_init = ATOMIC_INIT(0);

int smartdns_plugin_func_server_recv(struct dns_packet *packet, unsigned char *inpacket, int inpacket_len,
									 struct sockaddr_storage *local, socklen_t local_len, struct sockaddr_storage *from,
									 socklen_t from_len)
{
	struct dns_plugin_ops *chain = NULL;
	int ret = 0;

	if (unlikely(atomic_read(&is_plugin_init) == 0)) {
		return 0;
	}

	pthread_rwlock_rdlock(&plugins.lock);
	list_for_each_entry(chain, &plugins.list, list)
	{
		if (!chain->ops.server_recv) {
			continue;
		}

		ret = chain->ops.server_recv(packet, inpacket, inpacket_len, local, local_len, from, from_len);
		if (ret != 0) {
			pthread_rwlock_unlock(&plugins.lock);
			return ret;
		}
	}
	pthread_rwlock_unlock(&plugins.lock);

	return 0;
}

void smartdns_plugin_func_server_complete_request(struct dns_request *request)
{
	struct dns_plugin_ops *chain = NULL;

	if (unlikely(atomic_read(&is_plugin_init) == 0)) {
		return;
	}

	pthread_rwlock_rdlock(&plugins.lock);
	list_for_each_entry(chain, &plugins.list, list)
	{
		if (!chain->ops.server_query_complete) {
			continue;
		}

		chain->ops.server_query_complete(request);
	}
	pthread_rwlock_unlock(&plugins.lock);

	return;
}

void smartdns_plugin_func_server_log_callback(smartdns_log_level level, const char *msg, int msg_len)
{
	struct dns_plugin_ops *chain = NULL;

	if (unlikely(atomic_read(&is_plugin_init) == 0)) {
		return;
	}

	pthread_rwlock_rdlock(&plugins.lock);
	list_for_each_entry(chain, &plugins.list, list)
	{
		if (!chain->ops.server_log) {
			continue;
		}

		chain->ops.server_log(level, msg, msg_len);
	}
	pthread_rwlock_unlock(&plugins.lock);

	return;
}

void smartdns_plugin_func_server_audit_log_callback(const char *msg, int msg_len)
{
	struct dns_plugin_ops *chain = NULL;

	if (unlikely(atomic_read(&is_plugin_init) == 0)) {
		return;
	}

	pthread_rwlock_rdlock(&plugins.lock);
	list_for_each_entry(chain, &plugins.list, list)
	{
		if (!chain->ops.server_audit_log) {
			continue;
		}

		chain->ops.server_audit_log(msg, msg_len);
	}
	pthread_rwlock_unlock(&plugins.lock);

	return;
}

int smartdns_operations_register(const struct smartdns_operations *operations)
{
	struct dns_plugin_ops *chain = NULL;

	chain = (struct dns_plugin_ops *)malloc(sizeof(struct dns_plugin_ops));
	if (!chain) {
		return -1;
	}

	memcpy(&chain->ops, operations, sizeof(struct smartdns_operations));
	pthread_rwlock_wrlock(&plugins.lock);
	list_add_tail(&chain->list, &plugins.list);
	pthread_rwlock_unlock(&plugins.lock);

	return 0;
}

int smartdns_operations_unregister(const struct smartdns_operations *operations)
{
	struct dns_plugin_ops *chain = NULL;
	struct dns_plugin_ops *tmp = NULL;

	pthread_rwlock_wrlock(&plugins.lock);
	list_for_each_entry_safe(chain, tmp, &plugins.list, list)
	{
		if (memcmp(&chain->ops, operations, sizeof(struct smartdns_operations)) == 0) {
			list_del(&chain->list);
			pthread_rwlock_unlock(&plugins.lock);
			free(chain);
			return 0;
		}
	}
	pthread_rwlock_unlock(&plugins.lock);

	return -1;
}

static int _dns_plugin_remove_all_ops(void)
{
	struct dns_plugin_ops *chain = NULL;
	struct dns_plugin_ops *tmp = NULL;

	pthread_rwlock_wrlock(&plugins.lock);
	list_for_each_entry_safe(chain, tmp, &plugins.list, list)
	{
		list_del(&chain->list);
		free(chain);
	}
	pthread_rwlock_unlock(&plugins.lock);

	return 0;
}

int dns_server_plugin_init(void)
{
	if (atomic_read(&is_plugin_init) == 1) {
		return 0;
	}

	INIT_LIST_HEAD(&plugins.list);
	if (pthread_rwlock_init(&plugins.lock, NULL) != 0) {
		tlog(TLOG_ERROR, "init plugin rwlock failed.");
		return -1;
	}
	atomic_set(&is_plugin_init, 1);
	return 0;
}

void dns_server_plugin_exit(void)
{
	if (atomic_read(&is_plugin_init) == 0) {
		return;
	}

	_dns_plugin_remove_all_ops();

	pthread_rwlock_destroy(&plugins.lock);
	atomic_set(&is_plugin_init, 0);
	return;
}

void smartdns_plugin_log_setlevel(smartdns_log_level level)
{
	tlog_setlevel((tlog_level)level);
}

int smartdns_plugin_log_getlevel(void)
{
	return tlog_getlevel();
}
