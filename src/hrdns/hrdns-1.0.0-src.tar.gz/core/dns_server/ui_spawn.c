#define _GNU_SOURCE

#include "smartdns/ui_spawn.h"
#include "smartdns/tlog.h"
#include "smartdns/ui_bridge.h"
#include "smartdns/util.h"

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <spawn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef HRDNS_UI_ID
#define HRDNS_UI_ID "none"
#endif

#define UI_SPAWN_NAME "hrdns-ui"
#define UI_SPAWN_DIR_MAX (UI_CONF_PATH_MAX + 32)
#define UI_SPAWN_ENTRY_MAX (UI_SPAWN_DIR_MAX + 272)
#define UI_SPAWN_STOP_WAIT_MS 5000
#define UI_SPAWN_STOP_POLL_US 50000
#define UI_SPAWN_FD_LIMIT 65536
#define UI_SPAWN_ARGV_MAX 16
#define UI_SPAWN_NUM_LEN 16

extern const unsigned char hrdns_ui_blob[];
extern const unsigned char hrdns_ui_blob_end[];
extern char **environ;

static size_t ui_blob_size(void)
{
	return (size_t)(hrdns_ui_blob_end - hrdns_ui_blob);
}

static int ui_mkdirs(const char *path)
{
	char tmp[UI_SPAWN_DIR_MAX];
	char *p = NULL;

	safe_strncpy(tmp, path, sizeof(tmp));
	for (p = tmp + 1; *p != '\0'; p++) {
		if (*p != '/') {
			continue;
		}

		*p = '\0';
		if (mkdir(tmp, 0755) != 0 && errno != EEXIST) {
			return -1;
		}

		*p = '/';
	}

	return (mkdir(tmp, 0755) != 0 && errno != EEXIST) ? -1 : 0;
}

static void ui_remove_dir(const char *path)
{
	DIR *dir = opendir(path);
	struct dirent *ent = NULL;

	if (dir == NULL) {
		unlink(path);
		return;
	}

	while ((ent = readdir(dir)) != NULL) {
		if (strcmp(ent->d_name, ".") != 0 && strcmp(ent->d_name, "..") != 0) {
			unlinkat(dirfd(dir), ent->d_name, 0);
		}
	}

	closedir(dir);
	rmdir(path);
}

static void ui_prune_stale(const char *ui_dir)
{
	DIR *dir = opendir(ui_dir);
	struct dirent *ent = NULL;
	char entry[UI_SPAWN_ENTRY_MAX];

	if (dir == NULL) {
		return;
	}

	while ((ent = readdir(dir)) != NULL) {
		if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0 || strcmp(ent->d_name, HRDNS_UI_ID) == 0) {
			continue;
		}

		snprintf(entry, sizeof(entry), "%s/%s", ui_dir, ent->d_name);
		ui_remove_dir(entry);
	}

	closedir(dir);
}

static void ui_release_blob_pages(void)
{
	uintptr_t page = (uintptr_t)sysconf(_SC_PAGESIZE);
	uintptr_t start = (uintptr_t)hrdns_ui_blob & ~(page - 1);
	uintptr_t end = ((uintptr_t)hrdns_ui_blob_end + page - 1) & ~(page - 1);

	madvise((void *)start, end - start, MADV_DONTNEED);
}

static int ui_write_blob(const char *dir, const char *exe)
{
	char tmp[UI_SPAWN_EXE_MAX];
	size_t size = ui_blob_size();
	size_t off = 0;
	int fd = -1;
	int err = 0;

	snprintf(tmp, sizeof(tmp), "%s/.%s.tmp", dir, UI_SPAWN_NAME);
	fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0700);
	if (fd < 0) {
		return -1;
	}

	while (off < size) {
		ssize_t n = write(fd, hrdns_ui_blob + off, size - off);
		if (n < 0 && errno == EINTR) {
			continue;
		}

		if (n <= 0) {
			goto fail;
		}

		off += (size_t)n;
	}

	if (fsync(fd) != 0 || fchmod(fd, 0700) != 0) {
		goto fail;
	}

	if (close(fd) != 0) {
		fd = -1;
		goto fail;
	}

	if (rename(tmp, exe) != 0) {
		fd = -1;
		goto fail;
	}

	ui_release_blob_pages();
	return 0;
fail:
	err = errno;
	if (fd >= 0) {
		close(fd);
	}

	unlink(tmp);
	errno = err;
	return -1;
}

int ui_spawn_prepare(char *exe, size_t exe_len)
{
	char ui_dir[UI_SPAWN_DIR_MAX];
	char dir[UI_SPAWN_DIR_MAX];
	struct stat st;

	if (ui_conf.exec[0] != '\0') {
		safe_strncpy(exe, ui_conf.exec, exe_len);
		return 0;
	}

	if (ui_blob_size() == 0) {
		tlog(TLOG_ERROR, "ui is not embedded in this build.");
		return -1;
	}

	snprintf(ui_dir, sizeof(ui_dir), "%s/ui", ui_conf.data_dir);
	snprintf(dir, sizeof(dir), "%s/ui/%s", ui_conf.data_dir, HRDNS_UI_ID);
	snprintf(exe, exe_len, "%s/%s", dir, UI_SPAWN_NAME);
	if (stat(exe, &st) == 0 && (size_t)st.st_size == ui_blob_size() && (st.st_mode & S_IXUSR) != 0) {
		ui_prune_stale(ui_dir);
		return 0;
	}

	if (ui_mkdirs(dir) != 0 || ui_write_blob(dir, exe) != 0) {
		tlog(TLOG_ERROR, "cannot unpack ui to %s: %s", exe, strerror(errno));
		return -1;
	}

	ui_prune_stale(ui_dir);
	tlog(TLOG_NOTICE, "ui unpacked to %s", exe);
	return 0;
}

static int ui_collect_fds(int **fds)
{
	DIR *dir = opendir("/proc/self/fd");
	struct dirent *ent = NULL;
	int count = 0;
	int cap = 64;
	int self = -1;

	if (dir == NULL) {
		return -1;
	}

	*fds = malloc(cap * sizeof(int));
	if (*fds == NULL) {
		closedir(dir);
		return -1;
	}

	self = dirfd(dir);
	while ((ent = readdir(dir)) != NULL) {
		char *end = NULL;
		long fd = strtol(ent->d_name, &end, 10);

		if (end == ent->d_name || *end != '\0' || fd <= UI_SPAWN_FD || fd == self) {
			continue;
		}

		if (count == cap) {
			int *grown = realloc(*fds, cap * 2 * sizeof(int));
			if (grown == NULL) {
				closedir(dir);
				free(*fds);
				*fds = NULL;
				return -1;
			}

			*fds = grown;
			cap *= 2;
		}

		(*fds)[count++] = (int)fd;
	}

	closedir(dir);
	return count;
}

static int ui_add_close_actions(posix_spawn_file_actions_t *actions)
{
	int *fds = NULL;
	int count = ui_collect_fds(&fds);
	int i = 0;
	int ret = 0;

	if (count >= 0) {
		for (i = 0; i < count && ret == 0; i++) {
			ret = posix_spawn_file_actions_addclose(actions, fds[i]);
		}

		free(fds);
		return ret;
	}

	count = getdtablesize();
	if (count > UI_SPAWN_FD_LIMIT) {
		count = UI_SPAWN_FD_LIMIT;
	}

	for (i = UI_SPAWN_FD + 1; i < count && ret == 0; i++) {
		ret = posix_spawn_file_actions_addclose(actions, i);
	}

	return ret;
}

static int ui_build_actions(posix_spawn_file_actions_t *actions, int child_end)
{
	if (posix_spawn_file_actions_adddup2(actions, child_end, UI_SPAWN_FD) != 0 ||
		ui_add_close_actions(actions) != 0 ||
		posix_spawn_file_actions_addopen(actions, STDIN_FILENO, "/dev/null", O_RDONLY, 0) != 0 ||
		posix_spawn_file_actions_addopen(actions, STDOUT_FILENO, "/dev/null", O_WRONLY, 0) != 0 ||
		posix_spawn_file_actions_addopen(actions, STDERR_FILENO, "/dev/null", O_WRONLY, 0) != 0) {
		return -1;
	}

	return 0;
}

static int ui_build_argv(char **argv, char (*numbers)[UI_SPAWN_NUM_LEN])
{
	int argc = 0;

	snprintf(numbers[0], UI_SPAWN_NUM_LEN, "%d", ui_conf.days);
	snprintf(numbers[1], UI_SPAWN_NUM_LEN, "%d", ui_conf.max_mb);
	snprintf(numbers[2], UI_SPAWN_NUM_LEN, "%d", ui_conf.flush_seconds);
	argv[argc++] = (char *)UI_SPAWN_NAME;
	argv[argc++] = "-data";
	argv[argc++] = ui_conf.data_dir;
	argv[argc++] = "-days";
	argv[argc++] = numbers[0];
	argv[argc++] = "-max-mb";
	argv[argc++] = numbers[1];
	argv[argc++] = "-flush";
	argv[argc++] = numbers[2];
	if (ui_conf.listen[0] != '\0') {
		argv[argc++] = "-listen";
		argv[argc++] = ui_conf.listen;
	}

	argv[argc] = NULL;
	return argc;
}

static int ui_exec(const char *exe, int child_end, pid_t *pid)
{
	static char *clean_env[] = {"PATH=/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin", "GODEBUG=madvdontneed=1", NULL};
	char *argv[UI_SPAWN_ARGV_MAX];
	char numbers[3][UI_SPAWN_NUM_LEN];
	posix_spawn_file_actions_t actions;
	posix_spawnattr_t attr;
	sigset_t all;
	sigset_t none;
	int ret = -1;

	ui_build_argv(argv, numbers);
	sigfillset(&all);
	sigemptyset(&none);
	if (posix_spawnattr_init(&attr) != 0) {
		return ENOMEM;
	}

	if (posix_spawn_file_actions_init(&actions) != 0) {
		posix_spawnattr_destroy(&attr);
		return ENOMEM;
	}

	if (posix_spawnattr_setsigdefault(&attr, &all) == 0 && posix_spawnattr_setsigmask(&attr, &none) == 0 &&
		posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETSIGDEF | POSIX_SPAWN_SETSIGMASK) == 0 &&
		ui_build_actions(&actions, child_end) == 0) {
		ret = posix_spawn(pid, exe, &actions, &attr, argv, ui_conf.exec[0] != '\0' ? environ : clean_env);
	} else {
		ret = ENOMEM;
	}

	posix_spawn_file_actions_destroy(&actions);
	posix_spawnattr_destroy(&attr);
	return ret;
}

int ui_spawn_start(const char *exe, int *sock, pid_t *pid)
{
	int pair[2];
	int ret = 0;

	if (socketpair(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0, pair) != 0) {
		return -1;
	}

	if (pair[1] == UI_SPAWN_FD) {
		int moved = fcntl(pair[1], F_DUPFD_CLOEXEC, UI_SPAWN_FD + 1);
		if (moved < 0) {
			close(pair[0]);
			close(pair[1]);
			return -1;
		}

		close(pair[1]);
		pair[1] = moved;
	}

	if (fcntl(pair[0], F_SETFL, O_NONBLOCK) != 0) {
		close(pair[0]);
		close(pair[1]);
		return -1;
	}

	ret = ui_exec(exe, pair[1], pid);
	close(pair[1]);
	if (ret != 0) {
		close(pair[0]);
		errno = ret;
		return -1;
	}

	*sock = pair[0];
	return 0;
}

int ui_spawn_exited(pid_t pid)
{
	int status = 0;
	pid_t ret = waitpid(pid, &status, WNOHANG);

	if (ret == 0 || (ret < 0 && errno == EINTR)) {
		return 0;
	}

	if (ret < 0) {
		tlog(TLOG_WARN, "ui process %d is gone: %s", (int)pid, strerror(errno));
	} else if (WIFSIGNALED(status)) {
		tlog(TLOG_WARN, "ui process %d killed by signal %d", (int)pid, WTERMSIG(status));
	} else {
		tlog(TLOG_NOTICE, "ui process %d exited with status %d", (int)pid, WEXITSTATUS(status));
	}

	return 1;
}

void ui_spawn_stop(pid_t pid)
{
	int waited_us = 0;

	if (pid <= 0) {
		return;
	}

	kill(pid, SIGTERM);
	while (waited_us < UI_SPAWN_STOP_WAIT_MS * 1000) {
		if (ui_spawn_exited(pid)) {
			return;
		}

		usleep(UI_SPAWN_STOP_POLL_US);
		waited_us += UI_SPAWN_STOP_POLL_US;
	}

	kill(pid, SIGKILL);
	waitpid(pid, NULL, 0);
}
