#define _GNU_SOURCE

#include "smartdns/ui_bridge.h"
#include "smartdns/dns_cache.h"
#include "smartdns/dns_client.h"
#include "smartdns/dns_plugin.h"
#include "smartdns/dns_server.h"
#include "smartdns/dns_stats.h"
#include "smartdns/lib/atomic.h"
#include "smartdns/smartdns.h"
#include "smartdns/tlog.h"
#include "smartdns/ui_spawn.h"
#include "smartdns/util.h"

#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

#define UI_BRIDGE_RING_BYTES (256 * 1024)
#define UI_BRIDGE_TICK_MS 100
#define UI_BRIDGE_OUT_MAX (1024 * 1024)
#define UI_BRIDGE_REPLY_MAX (4 * 1024 * 1024)
#define UI_BRIDGE_CMD_MAX 256
#define UI_BRIDGE_HEADER 5
#define UI_BRIDGE_EVENT_MAX 384
#define UI_BRIDGE_TEXT_MAX 1024
#define UI_BRIDGE_DOMAIN_MAX 255
#define UI_BRIDGE_SERVERS_MAX 128
#define UI_BRIDGE_CACHE_LIST_DEFAULT 20000
#define UI_BRIDGE_PAUSE_MIN_MS 1000
#define UI_BRIDGE_PAUSE_MAX_MS 30000
#define UI_BRIDGE_STABLE_MS 60000
#define UI_BRIDGE_TERM_WAIT_MS 5000

enum ui_kind {
	UI_KIND_CMD = 0x02,
	UI_KIND_UILOG = 0x03,
	UI_KIND_HELLO = 0x81,
	UI_KIND_REPLY = 0x82,
	UI_KIND_QUERY = 0x90,
	UI_KIND_LOG = 0x91,
	UI_KIND_AUDIT = 0x92,
	UI_KIND_LOST = 0x93,
};

enum ui_want {
	UI_WANT_QUERY = 1,
	UI_WANT_LOG = 2,
	UI_WANT_AUDIT = 4,
};

enum ui_flag {
	UI_FLAG_BLOCKED = 1,
	UI_FLAG_CACHED = 2,
	UI_FLAG_HAS_MAC = 4,
};

struct ui_jbuf {
	char *p;
	size_t len;
	size_t cap;
	int failed;
};

struct ui_client {
	int fd;
	unsigned int want;
	int drop;
	unsigned char in[UI_BRIDGE_HEADER + UI_BRIDGE_CMD_MAX];
	size_t in_len;
	unsigned char *out;
	size_t out_len;
	size_t out_off;
	size_t out_cap;
};

static struct {
	pthread_mutex_t lock;
	unsigned char *buf;
	size_t head;
	size_t used;
	uint32_t lost;
	uint64_t lost_total;
	atomic_t want;
} ui_ring = {.lock = PTHREAD_MUTEX_INITIALIZER};

struct ui_conf ui_conf = {
	.days = 7,
	.max_mb = 256,
	.flush_seconds = 300,
	.data_dir = "/opt/var/lib/hrdns",
};

static struct {
	int running;
	int failed;
	int restart_requested;
	pthread_t thread;
	atomic_t stop;
	unsigned long long started_ms;
	struct ui_client client;
	unsigned char *scratch;
	pid_t pid;
	unsigned long long launches;
	unsigned long long spawned_at;
	unsigned long long next_spawn_at;
	unsigned long long term_deadline;
	unsigned int pause_ms;
} ui_bridge;

static const char *ui_server_types[] = {"udp", "tcp", "tls", "https", "quic", "http3", "mdns"};

static unsigned char *ui_put16(unsigned char *p, unsigned int v)
{
	p[0] = v & 0xff;
	p[1] = (v >> 8) & 0xff;
	return p + 2;
}

static unsigned char *ui_put32(unsigned char *p, uint32_t v)
{
	p[0] = v & 0xff;
	p[1] = (v >> 8) & 0xff;
	p[2] = (v >> 16) & 0xff;
	p[3] = (v >> 24) & 0xff;
	return p + 4;
}

static unsigned char *ui_put64(unsigned char *p, uint64_t v)
{
	p = ui_put32(p, (uint32_t)(v & 0xffffffffu));
	return ui_put32(p, (uint32_t)(v >> 32));
}

static uint32_t ui_get32(const unsigned char *p)
{
	return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static void ui_jb_reserve(struct ui_jbuf *jb, size_t extra)
{
	size_t need = jb->len + extra + 1;
	size_t cap = jb->cap ? jb->cap : 1024;
	char *p = NULL;

	if (jb->failed || need <= jb->cap) {
		return;
	}

	if (need > UI_BRIDGE_REPLY_MAX) {
		jb->failed = 1;
		return;
	}

	while (cap < need) {
		cap *= 2;
	}

	p = realloc(jb->p, cap);
	if (p == NULL) {
		jb->failed = 1;
		return;
	}

	jb->p = p;
	jb->cap = cap;
}

static void ui_jb_raw(struct ui_jbuf *jb, const char *s, size_t n)
{
	ui_jb_reserve(jb, n);
	if (jb->failed) {
		return;
	}

	memcpy(jb->p + jb->len, s, n);
	jb->len += n;
	jb->p[jb->len] = '\0';
}

static void ui_jb_fmt(struct ui_jbuf *jb, const char *fmt, ...)
{
	va_list ap;
	int n = 0;

	va_start(ap, fmt);
	n = vsnprintf(NULL, 0, fmt, ap);
	va_end(ap);
	if (n < 0) {
		jb->failed = 1;
		return;
	}

	ui_jb_reserve(jb, (size_t)n);
	if (jb->failed) {
		return;
	}

	va_start(ap, fmt);
	vsnprintf(jb->p + jb->len, (size_t)n + 1, fmt, ap);
	va_end(ap);
	jb->len += (size_t)n;
}

static void ui_jb_str(struct ui_jbuf *jb, const char *s)
{
	ui_jb_raw(jb, "\"", 1);
	for (; s != NULL && *s != '\0'; s++) {
		unsigned char c = (unsigned char)*s;
		if (c == '"' || c == '\\') {
			char esc[2] = {'\\', (char)c};
			ui_jb_raw(jb, esc, 2);
		} else if (c < 0x20) {
			ui_jb_fmt(jb, "\\u%04x", c);
		} else {
			ui_jb_raw(jb, (const char *)&c, 1);
		}
	}
	ui_jb_raw(jb, "\"", 1);
}

static void ui_ring_push(const unsigned char *frame, size_t len)
{
	size_t first = 0;

	pthread_mutex_lock(&ui_ring.lock);
	if (ui_ring.buf == NULL) {
		pthread_mutex_unlock(&ui_ring.lock);
		return;
	}

	if (ui_ring.used + len > UI_BRIDGE_RING_BYTES) {
		ui_ring.lost++;
		ui_ring.lost_total++;
		pthread_mutex_unlock(&ui_ring.lock);
		return;
	}

	first = UI_BRIDGE_RING_BYTES - ui_ring.head;
	if (first > len) {
		first = len;
	}

	memcpy(ui_ring.buf + ui_ring.head, frame, first);
	memcpy(ui_ring.buf, frame + first, len - first);
	ui_ring.head = (ui_ring.head + len) % UI_BRIDGE_RING_BYTES;
	ui_ring.used += len;
	pthread_mutex_unlock(&ui_ring.lock);
}

static size_t ui_ring_drain(unsigned char *out, uint32_t *lost)
{
	size_t n = 0;
	size_t tail = 0;
	size_t first = 0;

	pthread_mutex_lock(&ui_ring.lock);
	n = ui_ring.used;
	tail = (ui_ring.head + UI_BRIDGE_RING_BYTES - n) % UI_BRIDGE_RING_BYTES;
	first = UI_BRIDGE_RING_BYTES - tail;
	if (first > n) {
		first = n;
	}

	memcpy(out, ui_ring.buf + tail, first);
	memcpy(out + first, ui_ring.buf, n - first);
	ui_ring.used = 0;
	*lost = ui_ring.lost;
	ui_ring.lost = 0;
	pthread_mutex_unlock(&ui_ring.lock);
	return n;
}

static unsigned int ui_fill_addr(const struct sockaddr *sa, unsigned char *out)
{
	memset(out, 0, 16);
	if (sa == NULL) {
		return 0;
	}

	if (sa->sa_family == AF_INET) {
		memcpy(out, &((const struct sockaddr_in *)sa)->sin_addr, 4);
		return 4;
	}

	if (sa->sa_family == AF_INET6) {
		const struct in6_addr *a6 = &((const struct sockaddr_in6 *)sa)->sin6_addr;
		if (IN6_IS_ADDR_V4MAPPED(a6)) {
			memcpy(out, a6->s6_addr + 12, 4);
			return 4;
		}

		memcpy(out, a6, 16);
		return 6;
	}

	return 0;
}

static int ui_ping_tenths(struct dns_request *request)
{
	float ping = dns_server_request_get_ping_time(request) * 10;
	return (int)(ping < 0 ? ping - 0.5f : ping + 0.5f);
}

static void ui_on_query(struct dns_request *request)
{
	unsigned char frame[UI_BRIDGE_EVENT_MAX];
	unsigned char *p = frame + UI_BRIDGE_HEADER;
	const char *domain = NULL;
	const char *group = NULL;
	const uint8_t *mac = NULL;
	unsigned int flags = 0;
	size_t domain_len = 0;
	size_t group_len = 0;
	unsigned char addr[16];
	unsigned int family = 0;
	int i = 0;

	if ((atomic_read(&ui_ring.want) & UI_WANT_QUERY) == 0) {
		return;
	}

	if (dns_server_request_is_prefetch(request) || dns_server_request_is_dualstack(request)) {
		return;
	}

	domain = dns_server_request_get_domain(request);
	group = dns_server_request_get_group_name(request);
	mac = dns_server_request_get_remote_mac(request);
	domain_len = domain != NULL ? strnlen(domain, UI_BRIDGE_DOMAIN_MAX) : 0;
	group_len = group != NULL ? strnlen(group, DNS_GROUP_NAME_LEN - 1) : 0;
	family = ui_fill_addr(dns_server_request_get_remote_addr(request), addr);

	if (dns_server_request_is_blocked(request)) {
		flags |= UI_FLAG_BLOCKED;
	}

	if (dns_server_request_is_cached(request)) {
		flags |= UI_FLAG_CACHED;
	}

	for (i = 0; mac != NULL && i < 6; i++) {
		if (mac[i] != 0) {
			flags |= UI_FLAG_HAS_MAC;
			break;
		}
	}

	p = ui_put64(p, dns_server_request_get_query_timestamp(request));
	p = ui_put32(p, (uint32_t)dns_server_request_get_query_time(request));
	p = ui_put32(p, (uint32_t)ui_ping_tenths(request));
	p = ui_put16(p, (unsigned int)dns_server_request_get_qtype(request));
	*p++ = (unsigned char)dns_server_request_get_rcode(request);
	*p++ = (unsigned char)flags;
	*p++ = (unsigned char)family;
	memcpy(p, addr, 16);
	p += 16;
	if (mac != NULL) {
		memcpy(p, mac, 6);
	} else {
		memset(p, 0, 6);
	}
	p += 6;
	*p++ = (unsigned char)group_len;
	p = ui_put16(p, (unsigned int)domain_len);
	if (group_len > 0) {
		memcpy(p, group, group_len);
		p += group_len;
	}

	if (domain_len > 0) {
		memcpy(p, domain, domain_len);
		p += domain_len;
	}

	ui_put32(frame, (uint32_t)(p - frame - UI_BRIDGE_HEADER));
	frame[4] = UI_KIND_QUERY;
	ui_ring_push(frame, (size_t)(p - frame));
}

static void ui_push_text(unsigned int kind, int level, const char *msg, int msg_len)
{
	unsigned char frame[UI_BRIDGE_HEADER + 1 + UI_BRIDGE_TEXT_MAX];
	unsigned char *p = frame + UI_BRIDGE_HEADER;
	size_t len = msg_len > 0 ? (size_t)msg_len : 0;

	if (len > UI_BRIDGE_TEXT_MAX) {
		len = UI_BRIDGE_TEXT_MAX;
	}

	if (level >= 0) {
		*p++ = (unsigned char)level;
	}

	memcpy(p, msg, len);
	p += len;
	ui_put32(frame, (uint32_t)(p - frame - UI_BRIDGE_HEADER));
	frame[4] = (unsigned char)kind;
	ui_ring_push(frame, (size_t)(p - frame));
}

static void ui_on_log(smartdns_log_level level, const char *msg, int msg_len)
{
	if ((atomic_read(&ui_ring.want) & UI_WANT_LOG) == 0) {
		return;
	}

	ui_push_text(UI_KIND_LOG, (int)level, msg, msg_len);
}

static void ui_on_audit(const char *msg, int msg_len)
{
	if ((atomic_read(&ui_ring.want) & UI_WANT_AUDIT) == 0) {
		return;
	}

	ui_push_text(UI_KIND_AUDIT, -1, msg, msg_len);
}

int ui_bridge_audit_wanted(void)
{
	return (atomic_read(&ui_ring.want) & UI_WANT_AUDIT) != 0;
}

static const struct smartdns_operations ui_ops = {
	.server_recv = NULL,
	.server_query_complete = ui_on_query,
	.server_log = ui_on_log,
	.server_audit_log = ui_on_audit,
};

static int ui_client_append(struct ui_client *c, const void *data, size_t len)
{
	size_t pending = c->out_len - c->out_off;
	size_t need = 0;
	unsigned char *p = NULL;

	if (pending + len > UI_BRIDGE_OUT_MAX) {
		return -1;
	}

	if (c->out_off > 0 && (pending == 0 || c->out_off > c->out_cap / 2)) {
		memmove(c->out, c->out + c->out_off, pending);
		c->out_len = pending;
		c->out_off = 0;
	}

	need = c->out_len + len;
	if (need > c->out_cap) {
		size_t cap = c->out_cap ? c->out_cap : 4096;
		while (cap < need) {
			cap *= 2;
		}

		p = realloc(c->out, cap);
		if (p == NULL) {
			return -1;
		}

		c->out = p;
		c->out_cap = cap;
	}

	memcpy(c->out + c->out_len, data, len);
	c->out_len += len;
	return 0;
}

static int ui_client_send(struct ui_client *c, unsigned int kind, const void *data, size_t len)
{
	unsigned char header[UI_BRIDGE_HEADER];

	ui_put32(header, (uint32_t)len);
	header[4] = (unsigned char)kind;
	if (ui_client_append(c, header, sizeof(header)) != 0) {
		return -1;
	}

	return ui_client_append(c, data, len);
}

static int ui_client_flush(struct ui_client *c)
{
	while (c->out_off < c->out_len) {
		ssize_t n = send(c->fd, c->out + c->out_off, c->out_len - c->out_off, MSG_NOSIGNAL);
		if (n < 0) {
			return (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) ? 0 : -1;
		}

		c->out_off += (size_t)n;
	}

	c->out_off = 0;
	c->out_len = 0;
	if (c->out_cap > 64 * 1024) {
		free(c->out);
		c->out = NULL;
		c->out_cap = 0;
	}

	return 0;
}

static void ui_client_close(struct ui_client *c)
{
	if (c->fd >= 0) {
		close(c->fd);
	}

	free(c->out);
	memset(c, 0, sizeof(*c));
	c->fd = -1;
}

static void ui_update_want(void)
{
	unsigned int want = ui_bridge.client.fd >= 0 ? ui_bridge.client.want : 0;

	if (want != 0) {
		pthread_mutex_lock(&ui_ring.lock);
		if (ui_ring.buf == NULL) {
			ui_ring.buf = malloc(UI_BRIDGE_RING_BYTES);
			ui_ring.head = 0;
			ui_ring.used = 0;
			ui_ring.lost = 0;
		}
		pthread_mutex_unlock(&ui_ring.lock);

		if (ui_bridge.scratch == NULL) {
			ui_bridge.scratch = malloc(UI_BRIDGE_RING_BYTES);
		}

		if (ui_ring.buf == NULL || ui_bridge.scratch == NULL) {
			want = 0;
		}
	}

	atomic_set(&ui_ring.want, (long)want);
	if (want != 0) {
		return;
	}

	pthread_mutex_lock(&ui_ring.lock);
	free(ui_ring.buf);
	ui_ring.buf = NULL;
	ui_ring.used = 0;
	pthread_mutex_unlock(&ui_ring.lock);
	free(ui_bridge.scratch);
	ui_bridge.scratch = NULL;
}

struct ui_cache_ctx {
	struct ui_jbuf *jb;
	long left;
};

static void ui_cache_cb(const char *domain, uint16_t qtype, int ttl_remaining, time_t insert_time, void *userdata)
{
	struct ui_cache_ctx *ctx = userdata;
	struct ui_jbuf *jb = ctx->jb;

	if (ctx->left <= 0) {
		return;
	}

	ctx->left--;
	ui_jb_raw(jb, jb->len > 1 ? ",{\"domain\":" : "{\"domain\":", jb->len > 1 ? 11 : 10);
	ui_jb_str(jb, domain);
	ui_jb_fmt(jb, ",\"qtype\":%u,\"ttl\":%d,\"time\":%lld}", (unsigned int)qtype, ttl_remaining, (long long)insert_time);
}

static void ui_cmd_stats(struct ui_jbuf *jb)
{
	uint64_t lost = 0;

	pthread_mutex_lock(&ui_ring.lock);
	lost = ui_ring.lost_total;
	pthread_mutex_unlock(&ui_ring.lock);

	ui_jb_fmt(jb,
			  "{\"total\":%llu,\"success\":%llu,\"from_client\":%llu,\"blocked\":%llu,\"cache_hit\":%llu,"
			  "\"cache_hit_rate\":%.1f,\"avg_time\":%.1f,\"cache_number\":%d,\"cache_memsize\":%ld,"
			  "\"servers\":%d,\"servers_alive\":%d,\"lost\":%llu,\"log_level\":%d,\"ui_pid\":%d,\"ui_restarts\":%llu}",
			  (unsigned long long)dns_stats_request_total_get(), (unsigned long long)dns_stats_request_success_get(),
			  (unsigned long long)dns_stats_request_from_client_get(),
			  (unsigned long long)dns_stats_request_blocked_get(), (unsigned long long)dns_stats_cache_hit_get(),
			  dns_stats_cache_hit_rate_get(), dns_stats_avg_time_get(), dns_cache_total_num(), dns_cache_total_memsize(),
			  dns_server_num(), dns_server_alive_num(), (unsigned long long)lost, smartdns_plugin_log_getlevel(),
			  (int)ui_bridge.pid, ui_bridge.launches > 0 ? ui_bridge.launches - 1 : 0);
}

static void ui_cmd_servers(struct ui_jbuf *jb)
{
	struct dns_server_info *list[UI_BRIDGE_SERVERS_MAX];
	int n = dns_client_get_server_info_lists(list, UI_BRIDGE_SERVERS_MAX);
	int i = 0;

	ui_jb_raw(jb, "[", 1);
	for (i = 0; i < n; i++) {
		struct dns_server_info *server = list[i];
		struct dns_server_stats *stats = dns_client_get_server_stats(server);
		unsigned int type = (unsigned int)dns_client_get_server_type(server);

		ui_jb_raw(jb, i > 0 ? ",{\"host\":" : "{\"host\":", i > 0 ? 9 : 8);
		ui_jb_str(jb, dns_client_get_server_host(server));
		ui_jb_raw(jb, ",\"ip\":", 6);
		ui_jb_str(jb, dns_client_get_server_ip(server));
		ui_jb_fmt(jb, ",\"port\":%d,\"type\":", dns_client_get_server_port(server));
		ui_jb_str(jb, type < sizeof(ui_server_types) / sizeof(ui_server_types[0]) ? ui_server_types[type] : "unknown");
		ui_jb_fmt(jb,
				  ",\"alive\":%s,\"security\":%d,\"total\":%llu,\"success\":%llu,\"recv\":%llu,\"avg_time\":%.1f}",
				  dns_client_server_is_alive(server) ? "true" : "false",
				  (int)dns_client_get_server_security_status(server),
				  (unsigned long long)dns_stats_server_stats_total_get(stats),
				  (unsigned long long)dns_stats_server_stats_success_get(stats),
				  (unsigned long long)dns_stats_server_stats_recv_get(stats),
				  dns_stats_server_stats_avg_time_get(stats));
		dns_client_server_info_release(server);
	}
	ui_jb_raw(jb, "]", 1);
}

static int ui_cmd_subscribe(struct ui_client *c, const char *arg)
{
	unsigned int want = 0;

	for (; *arg != '\0'; arg++) {
		if (*arg == 'q') {
			want |= UI_WANT_QUERY;
		} else if (*arg == 'l') {
			want |= UI_WANT_LOG;
		} else if (*arg == 'a') {
			want |= UI_WANT_AUDIT;
		} else {
			return -1;
		}
	}

	c->want = want;
	ui_update_want();
	return 0;
}

static void ui_send_reply(struct ui_client *c, unsigned long id, const char *error, struct ui_jbuf *data)
{
	char prefix[96];
	struct ui_jbuf jb = {0};
	int n = 0;

	if (error == NULL && !data->failed) {
		n = snprintf(prefix, sizeof(prefix), "{\"id\":%lu,\"ok\":true,\"data\":", id);
		ui_jb_raw(&jb, prefix, (size_t)n);
		ui_jb_raw(&jb, data->p != NULL ? data->p : "null", data->p != NULL ? data->len : 4);
		ui_jb_raw(&jb, "}", 1);
	} else {
		n = snprintf(prefix, sizeof(prefix), "{\"id\":%lu,\"ok\":false,\"error\":", id);
		ui_jb_raw(&jb, prefix, (size_t)n);
		ui_jb_str(&jb, error != NULL ? error : "response too large");
		ui_jb_raw(&jb, "}", 1);
	}

	if (jb.failed || ui_client_send(c, UI_KIND_REPLY, jb.p, jb.len) != 0) {
		c->drop = 1;
	}

	free(jb.p);
}

static void ui_handle_command(struct ui_client *c, const unsigned char *payload, size_t len)
{
	char line[UI_BRIDGE_CMD_MAX + 1];
	struct ui_jbuf data = {0};
	const char *error = NULL;
	char *cmd = NULL;
	char *arg = NULL;
	char *end = NULL;
	unsigned long id = 0;

	memcpy(line, payload, len);
	line[len] = '\0';
	id = strtoul(line, &end, 10);
	if (end == line || *end != ' ') {
		c->drop = 1;
		return;
	}

	cmd = end + 1;
	arg = strchr(cmd, ' ');
	if (arg != NULL) {
		*arg++ = '\0';
	} else {
		arg = cmd + strlen(cmd);
	}

	if (strcmp(cmd, "ping") == 0) {
		ui_jb_raw(&data, "true", 4);
	} else if (strcmp(cmd, "subscribe") == 0) {
		if (ui_cmd_subscribe(c, arg) != 0) {
			error = "invalid subscription";
		} else {
			ui_jb_raw(&data, "true", 4);
		}
	} else if (strcmp(cmd, "stats") == 0) {
		ui_cmd_stats(&data);
	} else if (strcmp(cmd, "servers") == 0) {
		ui_cmd_servers(&data);
	} else if (strcmp(cmd, "cache.count") == 0) {
		ui_jb_fmt(&data, "{\"cache_number\":%d}", dns_cache_total_num());
	} else if (strcmp(cmd, "cache.flush") == 0) {
		dns_cache_flush();
		ui_jb_fmt(&data, "{\"cache_number\":%d}", dns_cache_total_num());
	} else if (strcmp(cmd, "cache.list") == 0) {
		struct ui_cache_ctx ctx = {.jb = &data, .left = UI_BRIDGE_CACHE_LIST_DEFAULT};
		if (*arg != '\0') {
			ctx.left = strtol(arg, &end, 10);
		}

		if (ctx.left <= 0 || (*arg != '\0' && *end != '\0')) {
			error = "invalid limit";
		} else {
			ui_jb_raw(&data, "[", 1);
			dns_cache_foreach(ui_cache_cb, &ctx);
			ui_jb_raw(&data, "]", 1);
		}
	} else if (strcmp(cmd, "log.get") == 0) {
		ui_jb_fmt(&data, "{\"log_level\":%d}", smartdns_plugin_log_getlevel());
	} else if (strcmp(cmd, "restart") == 0) {
		ui_bridge.restart_requested = 1;
		ui_jb_raw(&data, "true", 4);
	} else if (strcmp(cmd, "log.set") == 0) {
		long level = strtol(arg, &end, 10);
		if (end == arg || *end != '\0' || level < SMARTDNS_LOG_DEBUG || level > SMARTDNS_LOG_OFF) {
			error = "invalid log level";
		} else {
			smartdns_plugin_log_setlevel((smartdns_log_level)level);
			ui_jb_fmt(&data, "{\"log_level\":%d}", smartdns_plugin_log_getlevel());
		}
	} else {
		error = "unknown command";
	}

	ui_send_reply(c, id, error, &data);
	free(data.p);
}

static void ui_handle_uilog(const unsigned char *payload, size_t len)
{
	char text[UI_BRIDGE_CMD_MAX];
	size_t n = len - 1;
	int level = payload[0] <= TLOG_FATAL ? payload[0] : TLOG_FATAL;

	while (n > 0 && (payload[n] == '\n' || payload[n] == '\r')) {
		n--;
	}

	memcpy(text, payload + 1, n);
	text[n] = '\0';
	tlog(level, "ui: %s", text);
}

static int ui_client_read(struct ui_client *c)
{
	ssize_t n = recv(c->fd, c->in + c->in_len, sizeof(c->in) - c->in_len, 0);

	if (n == 0) {
		return -1;
	}

	if (n < 0) {
		return (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) ? 0 : -1;
	}

	c->in_len += (size_t)n;
	while (c->in_len >= UI_BRIDGE_HEADER && !c->drop) {
		uint32_t len = ui_get32(c->in);
		size_t total = UI_BRIDGE_HEADER + (size_t)len;

		if (len > UI_BRIDGE_CMD_MAX) {
			return -1;
		}

		if (c->in_len < total) {
			break;
		}

		if (c->in[4] == UI_KIND_CMD) {
			ui_handle_command(c, c->in + UI_BRIDGE_HEADER, len);
		} else if (c->in[4] == UI_KIND_UILOG && len > 0) {
			ui_handle_uilog(c->in + UI_BRIDGE_HEADER, len);
		}

		memmove(c->in, c->in + total, c->in_len - total);
		c->in_len -= total;
	}

	return c->drop ? -1 : 0;
}

static void ui_send_hello(struct ui_client *c)
{
	struct ui_jbuf jb = {0};
	char name[64] = {0};

	dns_server_get_server_name(name, sizeof(name));
	ui_jb_raw(&jb, "{\"build\":", 9);
	ui_jb_str(&jb, smartdns_version());
	ui_jb_raw(&jb, ",\"server_name\":", 15);
	ui_jb_str(&jb, name);
	ui_jb_fmt(&jb, ",\"started_ms\":%llu}", ui_bridge.started_ms);
	if (jb.failed || ui_client_send(c, UI_KIND_HELLO, jb.p, jb.len) != 0) {
		c->drop = 1;
	}

	free(jb.p);
}

static unsigned int ui_kind_want(unsigned int kind)
{
	switch (kind) {
	case UI_KIND_QUERY:
		return UI_WANT_QUERY;
	case UI_KIND_LOG:
		return UI_WANT_LOG;
	case UI_KIND_AUDIT:
		return UI_WANT_AUDIT;
	default:
		return 0;
	}
}

static void ui_distribute(void)
{
	struct ui_client *c = &ui_bridge.client;
	unsigned char lost_frame[UI_BRIDGE_HEADER + 4];
	uint32_t lost = 0;
	size_t n = 0;
	size_t off = 0;

	if (ui_bridge.scratch == NULL || atomic_read(&ui_ring.want) == 0) {
		return;
	}

	n = ui_ring_drain(ui_bridge.scratch, &lost);
	while (off + UI_BRIDGE_HEADER <= n) {
		size_t total = UI_BRIDGE_HEADER + (size_t)ui_get32(ui_bridge.scratch + off);
		unsigned int want = ui_kind_want(ui_bridge.scratch[off + 4]);

		if (off + total > n) {
			break;
		}

		if (c->fd >= 0 && !c->drop && (c->want & want) != 0 && ui_client_append(c, ui_bridge.scratch + off, total) != 0) {
			c->drop = 1;
		}

		off += total;
	}

	if (lost == 0) {
		return;
	}

	ui_put32(lost_frame, 4);
	lost_frame[4] = UI_KIND_LOST;
	ui_put32(lost_frame + UI_BRIDGE_HEADER, lost);
	if (c->fd >= 0 && !c->drop && c->want != 0 && ui_client_append(c, lost_frame, sizeof(lost_frame)) != 0) {
		c->drop = 1;
	}
}

static unsigned long long ui_now_ms(void)
{
	struct timespec ts;

	clock_gettime(CLOCK_MONOTONIC, &ts);
	return (unsigned long long)ts.tv_sec * 1000 + (unsigned long long)ts.tv_nsec / 1000000;
}

static void ui_schedule_spawn(unsigned long long now)
{
	ui_bridge.next_spawn_at = now + ui_bridge.pause_ms;
	ui_bridge.pause_ms = ui_bridge.pause_ms * 2 < UI_BRIDGE_PAUSE_MAX_MS ? ui_bridge.pause_ms * 2 : UI_BRIDGE_PAUSE_MAX_MS;
}

static void ui_process_launch(unsigned long long now)
{
	char exe[UI_SPAWN_EXE_MAX];
	int sock = -1;
	pid_t pid = 0;

	if (ui_spawn_prepare(exe, sizeof(exe)) != 0) {
		ui_bridge.failed = 1;
		return;
	}

	if (ui_spawn_start(exe, &sock, &pid) != 0) {
		tlog(TLOG_WARN, "cannot start ui %s: %s", exe, strerror(errno));
		ui_schedule_spawn(now);
		return;
	}

	ui_bridge.client.fd = sock;
	ui_bridge.pid = pid;
	ui_bridge.launches++;
	ui_bridge.spawned_at = now;
	ui_bridge.term_deadline = 0;
	ui_send_hello(&ui_bridge.client);
	tlog(TLOG_NOTICE, "ui started, pid %d", (int)pid);
}

static void ui_process_gone(unsigned long long now)
{
	ui_bridge.pid = 0;
	ui_bridge.term_deadline = 0;
	ui_client_close(&ui_bridge.client);
	ui_update_want();
	if (now - ui_bridge.spawned_at >= UI_BRIDGE_STABLE_MS) {
		ui_bridge.pause_ms = UI_BRIDGE_PAUSE_MIN_MS;
	}

	ui_schedule_spawn(now);
}

static void ui_process_tick(unsigned long long now)
{
	if (ui_bridge.failed) {
		return;
	}

	if (ui_bridge.pid <= 0) {
		if (now >= ui_bridge.next_spawn_at) {
			ui_process_launch(now);
		}

		return;
	}

	if (ui_spawn_exited(ui_bridge.pid)) {
		ui_process_gone(now);
		return;
	}

	if (ui_bridge.term_deadline != 0 && now >= ui_bridge.term_deadline) {
		kill(ui_bridge.pid, SIGKILL);
		ui_bridge.term_deadline = 0;
	}
}

static void ui_sweep(unsigned long long now)
{
	struct ui_client *c = &ui_bridge.client;

	if (c->fd >= 0 && !c->drop && ui_client_flush(c) != 0) {
		c->drop = 1;
	}

	if (c->fd < 0 || !c->drop) {
		return;
	}

	ui_client_close(c);
	ui_update_want();
	if (ui_bridge.pid > 0) {
		kill(ui_bridge.pid, SIGTERM);
		ui_bridge.term_deadline = now + UI_BRIDGE_TERM_WAIT_MS;
	}
}

static void ui_poll_client(void)
{
	struct ui_client *c = &ui_bridge.client;
	struct pollfd pfd;
	int nfds = 0;

	if (c->fd >= 0) {
		pfd.fd = c->fd;
		pfd.events = POLLIN | (c->out_off < c->out_len ? POLLOUT : 0);
		pfd.revents = 0;
		nfds = 1;
	}

	if (poll(&pfd, (nfds_t)nfds, UI_BRIDGE_TICK_MS) <= 0 || nfds == 0) {
		return;
	}

	if ((pfd.revents & POLLIN) && ui_client_read(c) != 0) {
		c->drop = 1;
	} else if (pfd.revents & (POLLERR | POLLHUP | POLLNVAL)) {
		c->drop = 1;
	}
}

static void *ui_bridge_thread(void *arg)
{
	(void)arg;

	while (atomic_read(&ui_bridge.stop) == 0 && !ui_bridge.failed) {
		unsigned long long now = ui_now_ms();

		ui_process_tick(now);
		ui_poll_client();
		ui_distribute();
		ui_sweep(ui_now_ms());
		if (ui_bridge.restart_requested) {
			ui_bridge.restart_requested = 0;
			smartdns_request_restart();
		}
	}

	if (ui_bridge.failed) {
		smartdns_operations_unregister(&ui_ops);
	}

	return NULL;
}

int ui_bridge_init(void)
{
	if (!ui_conf.enable || ui_bridge.running) {
		return 0;
	}

	ui_bridge.client.fd = -1;
	ui_bridge.pause_ms = UI_BRIDGE_PAUSE_MIN_MS;
	ui_bridge.started_ms = get_utc_time_ms();
	if (smartdns_operations_register(&ui_ops) != 0) {
		tlog(TLOG_WARN, "ui disabled, cannot register operations.");
		return 0;
	}

	atomic_set(&ui_bridge.stop, 0);
	if (pthread_create(&ui_bridge.thread, NULL, ui_bridge_thread, NULL) != 0) {
		tlog(TLOG_WARN, "ui disabled, cannot start thread.");
		smartdns_operations_unregister(&ui_ops);
		return 0;
	}

	ui_bridge.running = 1;
	return 0;
}

void ui_bridge_exit(void)
{
	if (!ui_bridge.running) {
		return;
	}

	atomic_set(&ui_bridge.stop, 1);
	pthread_join(ui_bridge.thread, NULL);
	smartdns_operations_unregister(&ui_ops);
	ui_client_close(&ui_bridge.client);
	ui_spawn_stop(ui_bridge.pid);
	ui_bridge.pid = 0;
	ui_update_want();
	ui_bridge.running = 0;
}
