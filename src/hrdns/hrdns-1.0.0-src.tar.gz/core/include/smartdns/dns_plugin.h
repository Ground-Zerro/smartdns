/*************************************************************************
 *
 * Copyright (C) 2018-2025 Ruilin Peng (Nick) <pymumu@gmail.com>.
 *
 * smartdns is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * smartdns is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SMART_DNS_PLUGIN_H
#define SMART_DNS_PLUGIN_H

#include "smartdns/dns.h"
#include <sys/socket.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

struct dns_request;

int dns_server_plugin_init(void);

void dns_server_plugin_exit(void);

typedef enum {
	SMARTDNS_LOG_DEBUG = 0,
	SMARTDNS_LOG_INFO = 1,
	SMARTDNS_LOG_NOTICE = 2,
	SMARTDNS_LOG_WARN = 3,
	SMARTDNS_LOG_ERROR = 4,
	SMARTDNS_LOG_FATAL = 5,
	SMARTDNS_LOG_OFF = 6,
	SMARTDNS_LOG_END = 7
} smartdns_log_level;

void smartdns_plugin_log_setlevel(smartdns_log_level level);

int smartdns_plugin_log_getlevel(void);

int smartdns_plugin_func_server_recv(struct dns_packet *packet, unsigned char *inpacket, int inpacket_len,
									 struct sockaddr_storage *local, socklen_t local_len, struct sockaddr_storage *from,
									 socklen_t from_len);
void smartdns_plugin_func_server_complete_request(struct dns_request *request);

void smartdns_plugin_func_server_log_callback(smartdns_log_level level, const char *msg, int msg_len);

void smartdns_plugin_func_server_audit_log_callback(const char *msg, int msg_len);

struct smartdns_operations {
	int (*server_recv)(struct dns_packet *packet, unsigned char *inpacket, int inpacket_len,
					   struct sockaddr_storage *local, socklen_t local_len, struct sockaddr_storage *from,
					   socklen_t from_len);
	void (*server_query_complete)(struct dns_request *request);

	void (*server_log)(smartdns_log_level level, const char *msg, int msg_len);

	void (*server_audit_log)(const char *msg, int msg_len);
};

int smartdns_operations_register(const struct smartdns_operations *operations);

int smartdns_operations_unregister(const struct smartdns_operations *operations);

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
