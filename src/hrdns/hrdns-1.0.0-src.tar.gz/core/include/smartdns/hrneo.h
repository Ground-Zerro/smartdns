#ifndef _SMARTDNS_HRNEO_H_
#define _SMARTDNS_HRNEO_H_

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

int hrneo_conf_socket(void *data, int argc, char *argv[]);

int hrneo_conf_target(void *data, int argc, char *argv[]);

int hrneo_match(const char *domain, const char **group);

extern int hrneo_ecs_strip;

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
