#ifndef SMART_DNS_UI_SPAWN_H
#define SMART_DNS_UI_SPAWN_H

#include <stddef.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

#define UI_SPAWN_FD 3
#define UI_SPAWN_EXE_MAX 320

int ui_spawn_prepare(char *exe, size_t exe_len);

int ui_spawn_start(const char *exe, int *sock, pid_t *pid);

int ui_spawn_exited(pid_t pid);

void ui_spawn_stop(pid_t pid);

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
