#ifndef SMART_DNS_UI_BRIDGE_H
#define SMART_DNS_UI_BRIDGE_H

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

#define UI_CONF_PATH_MAX 256
#define UI_CONF_ADDR_MAX 64

struct ui_conf {
	int enable;
	int days;
	int max_mb;
	int flush_seconds;
	char listen[UI_CONF_ADDR_MAX];
	char data_dir[UI_CONF_PATH_MAX];
	char exec[UI_CONF_PATH_MAX];
};

extern struct ui_conf ui_conf;

int ui_bridge_init(void);

void ui_bridge_exit(void);

int ui_bridge_audit_wanted(void);

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
