import * as React from 'react';

import GlobalStyles from '@mui/material/GlobalStyles';

import { NoSsr } from '@/components/core/no-ssr';
import ClientLayout from '@/components/dashboard/layout/client-layout';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps): React.JSX.Element {

  return (
    <NoSsr>
      <GlobalStyles
        styles={{
          body: {
            '--MainNav-height': '65px',
            '--MainNav-zIndex': 1000,
            '--Footer-height': '65px',
            '--Footer-zIndex': 1000,
            '--Footer-height-mobile': '110px',
            '--Footer-zIndex-mobile': 1000,
          },
        }}
      />
      <ClientLayout> {children} </ClientLayout>
    </NoSsr>
  );
}
