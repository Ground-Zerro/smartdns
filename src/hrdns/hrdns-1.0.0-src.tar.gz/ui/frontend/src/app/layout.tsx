"use client";

import * as React from 'react';

import '@/styles/global.css';

import { LocalizationProvider } from '@/components/core/localization-provider';
import { ThemeProvider } from '@/components/core/theme-provider/theme-provider';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps): React.JSX.Element {
  return (
    <html lang="en">
      {typeof document !== 'undefined' && document.title ? <head><title>{document.title}</title></head> : null}
      <body>
        <LocalizationProvider>
          <ThemeProvider>{children}</ThemeProvider>
        </LocalizationProvider>
      </body>
    </html>
  );
}
