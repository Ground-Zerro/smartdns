"use client";

import * as React from 'react';
import RouterLink from 'next/link';
import Box from '@mui/material/Box';
import { smartdnsServer } from '@/lib/backend/server';
import type { TopDomains } from '@/lib/backend/server';
import { CardLoading } from './card-loading';
import { TopTable } from './top-table';
import { paths } from '@/paths';
import { Link } from '@mui/material';
import { useTranslation } from 'react-i18next';

function TopDomainsTable({ domains }: { domains: TopDomains[] }): React.JSX.Element {
  const { t } = useTranslation();

  const rows = domains.map((domain) => {
    let url = `${paths.dashboard.queryLog}?domain=${encodeURIComponent(domain.domain)}&total_count=${domain.query_count}`;
    if (domain.timestamp_start !== undefined && domain.timestamp_start !== null) {
      url += `&timestamp_after=${domain.timestamp_start}`;
    }
    if (domain.timestamp_end !== undefined && domain.timestamp_end !== null) {
      url += `&timestamp_before=${domain.timestamp_end}`;
    }
    return {
      key: domain.domain,
      label: <Link component={RouterLink} href={url}>{domain.domain}</Link>,
      value: domain.query_count,
    };
  });

  return <TopTable head={[t('Domain'), t('Count')]} rows={rows} />;
}

export function TopDomainsCard(): React.JSX.Element {
  const [domains, setDomains] = React.useState<TopDomains[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);
  const { t } = useTranslation();

  React.useEffect(() => {
    const fetchData = async (): Promise<void> => {
      const data = await smartdnsServer.GetTopDomains();
      if (data.error) {
        setErrorMsg(smartdnsServer.getErrorMessage(data.error));
        return;
      }

      if (data.data === null) {
        return;
      }

      setDomains(data.data || []);
      setLoading(false);
    };

    void fetchData();
  }, []);

  return (
    <Box>
      <CardLoading title={t("Top Domains")} isLoading={loading} errorMsg={errorMsg}>
        <TopDomainsTable domains={domains} />
      </CardLoading>
    </Box>
  )
}
