'use client';

import * as React from 'react';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import { HeaderNav } from './header-nav';
import { HrwebTheme } from '@/components/core/hrweb-theme';

export function MainNav(): React.JSX.Element {
  return (
    <Box
      component="header"
      sx={{
        color: 'var(--mui-palette-toolbar-title-color)',
        borderBottom: '1px solid var(--mui-palette-divider)',
        backgroundColor: 'var(--mui-palette-toolbar-title-background)',
        position: 'sticky',
        top: 0,
        zIndex: 'var(--mui-zIndex-appBar)',
      }}
    >
      <Stack
        direction="row"
        spacing={2}
        sx={{ alignItems: 'center', minHeight: '64px', px: 2 }}
      >
        <HrwebTheme />
        <HeaderNav />
      </Stack>
    </Box>
  );
}
