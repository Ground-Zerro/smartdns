import * as React from 'react';
import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';

const rowHeight = 52;
const visibleRows = 10;

export interface TopTableRow {
  key: string;
  label: React.ReactNode;
  value: React.ReactNode;
}

interface TopTableProps {
  head: [string, string];
  rows: TopTableRow[];
}

export function TopTable({ head, rows }: TopTableProps): React.JSX.Element {
  return (
    <TableContainer sx={{ maxHeight: rowHeight * (visibleRows + 1) }}>
      <Table stickyHeader sx={{ minWidth: 100, '& td, & th': { height: rowHeight, py: 0, boxSizing: 'border-box' } }}>
        <TableHead>
          <TableRow>
            <TableCell>{head[0]}</TableCell>
            <TableCell sx={{ width: '40%' }}>{head[1]}</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.key}>
              <TableCell sx={{ wordBreak: 'break-all' }}>{row.label}</TableCell>
              <TableCell>{row.value}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export function CountBar({ count, total }: { count: number; total: number }): React.JSX.Element {
  const percent = total > 0 ? (count / total) * 100 : 0;
  return (
    <Box>
      <Typography component="span" variant="body2" sx={{ fontWeight: 600 }}>{count.toLocaleString('ru-RU')}</Typography>
      <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 1 }}>{percent.toFixed(2)}%</Typography>
      <LinearProgress variant="determinate" value={percent} color="success" sx={{ mt: 0.5, height: 4, borderRadius: 2 }} />
    </Box>
  );
}
