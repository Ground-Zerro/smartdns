'use client';

import * as React from 'react';
import RouterLink from 'next/link';
import { usePathname } from 'next/navigation';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import { useTranslation } from 'react-i18next';

import { isNavItemActive } from '@/lib/is-nav-item-active';

import { navItems } from './config';
import { navIcons } from './nav-icons';

export function HeaderNav(): React.JSX.Element {
  const pathname = usePathname();
  const { t } = useTranslation();
  const activeRef = React.useRef<HTMLAnchorElement>(null);

  React.useEffect(() => {
    activeRef.current?.scrollIntoView({ block: 'nearest', inline: 'center' });
  }, [pathname]);

  return (
    <Stack
      component="nav"
      direction="row"
      spacing={1}
      sx={{ alignItems: 'center', minWidth: 0, overflowX: 'auto', scrollbarWidth: 'none', '&::-webkit-scrollbar': { display: 'none' } }}
    >
      {navItems.map(({ key, title, href, icon }) => {
        const active = isNavItemActive({ href, pathname });
        const Icon = navIcons[icon];

        return (
          <Box
            key={key}
            ref={active ? activeRef : undefined}
            component={RouterLink}
            href={href}
            aria-current={active ? 'page' : undefined}
            sx={{
              alignItems: 'center',
              border: '2px solid',
              borderColor: active ? 'var(--mui-palette-info-main)' : 'transparent',
              borderRadius: 0.5,
              color: 'var(--mui-palette-toolbar-navItem-color)',
              display: 'flex',
              flex: '0 0 auto',
              gap: 1,
              p: '4px 10px',
              textDecoration: 'none',
              whiteSpace: 'nowrap',
              '&:hover': { bgcolor: 'var(--mui-palette-toolbar-navItem-hoverBackground)' },
              '& svg': { color: 'var(--mui-palette-toolbar-navItem-iconColor)' },
            }}
          >
            <Icon />
            <Typography component="span" sx={{ color: 'inherit', fontSize: '0.875rem', fontWeight: 500, lineHeight: '28px' }}>
              {t(title)}
            </Typography>
          </Box>
        );
      })}
    </Stack>
  );
}
