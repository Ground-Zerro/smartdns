"use client";

import * as React from 'react';
import RouterLink from 'next/link';
import { smartdnsServer } from '@/lib/backend/server';
import type { TopClients } from '@/lib/backend/server';
import { CardLoading } from './card-loading';
import { TopTable } from './top-table';
import { paths } from '@/paths';
import { clientLabel } from '@/lib/client-label';
import { useNames } from '@/lib/names';
import { Link } from '@mui/material';
import { useTranslation } from 'react-i18next';

function TopClientsTable({ clients }: { clients: TopClients[] }): React.JSX.Element {
  const { t } = useTranslation();
  const names = useNames();

  const rows = clients.map((client) => {
    let url = `${paths.dashboard.queryLog}?client=${encodeURIComponent(client.client_ip)}&total_count=${client.query_count}`;
    if (client.timestamp_start !== undefined && client.timestamp_start !== null) {
      url += `&timestamp_after=${client.timestamp_start}`;
    }
    if (client.timestamp_end !== undefined && client.timestamp_end !== null) {
      url += `&timestamp_before=${client.timestamp_end}`;
    }
    return {
      key: client.client_ip,
      label: <Link component={RouterLink} href={url}>{clientLabel(client.client_ip, names?.client(client.client_ip, client.client_mac))}</Link>,
      value: client.query_count,
    };
  });

  return <TopTable head={[t('Client'), t('Count')]} rows={rows} />;
}

export function TopClientsCard(): React.JSX.Element {
  const [clients, setClients] = React.useState<TopClients[]>([]);
  const [loading, setLoading] = React.useState<boolean>(true);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  const { t } = useTranslation();

  React.useEffect(() => {
    const fetchData = async (): Promise<void> => {
      const data = await smartdnsServer.GetTopClients();
      if (data.error) {
        setErrorMsg(smartdnsServer.getErrorMessage(data.error));
        return;
      }

      if (data.data === null || data.data === undefined) {
        return;
      }

      setClients(data.data);
      setLoading(false);
    };

    void fetchData();
  }, []);

  return (
    <CardLoading title={t("Top Clients")} isLoading={loading} errorMsg={errorMsg}>
      <TopClientsTable clients={clients} />
    </CardLoading>
  );
}
