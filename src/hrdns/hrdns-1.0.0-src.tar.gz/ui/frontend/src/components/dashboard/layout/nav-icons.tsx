import { ArticleOutlined, DnsOutlined, type SvgIconComponent, QueryStatsOutlined, EventNoteOutlined } from '@mui/icons-material';

export const navIcons = {
  'QueryStats': QueryStatsOutlined,
  'EventNote': EventNoteOutlined,
  "Dns": DnsOutlined,
  'Article': ArticleOutlined,
} as Record<string, SvgIconComponent>;
