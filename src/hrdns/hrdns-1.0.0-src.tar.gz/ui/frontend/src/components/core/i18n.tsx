import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import translationRu from '@/../public/locales/ru/translation.json';

// eslint-disable-next-line import/no-named-as-default-member
void i18n
  .use(initReactI18next)
  .init({
    resources: { ru: { translation: translationRu } },
    lng: "ru",
    debug: false,
    fallbackLng: "en",
    keySeparator: false,
    nsSeparator: false,
    interpolation: {
      escapeValue: false
    },
  });

// eslint-disable-next-line unicorn/prefer-export-from
export default i18n;
