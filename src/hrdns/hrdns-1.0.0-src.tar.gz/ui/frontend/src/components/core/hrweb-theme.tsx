"use client";

import * as React from 'react';
import { useColorScheme } from '@mui/material';

function hrwebMode(): 'light' | 'dark' {
  if (window.parent !== window) {
    return window.parent.document.documentElement.dataset.theme === 'dark' ? 'dark' : 'light';
  }

  const match = /(?:^|; )theme=([^;]*)/.exec(document.cookie);
  return match && decodeURIComponent(match[1]) === 'light' ? 'light' : 'dark';
}

export function HrwebTheme(): null {
  const { setColorScheme } = useColorScheme();

  React.useEffect(() => {
    const apply = (): void => {
      setColorScheme(hrwebMode());
    };

    apply();
    if (window.parent === window) {
      return;
    }

    const observer = new MutationObserver(apply);
    observer.observe(window.parent.document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    return () => {
      observer.disconnect();
    };
  }, [setColorScheme]);

  return null;
}
