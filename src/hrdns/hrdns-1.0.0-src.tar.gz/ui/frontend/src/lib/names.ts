import * as React from 'react';

import { csrfToken } from '@/lib/hrweb';

interface NamedHost {
  mac: string;
  name: string;
  addr: string[];
}

interface NamesResponse {
  hosts: NamedHost[];
  rules: Record<string, string>;
  groups: Record<string, string>;
}

export interface GroupLabel {
  kind: 'rule' | 'group';
  name: string;
}

const REFRESH_EVERY = 30_000;

export class Names {
  private readonly byMAC = new Map<string, string>();
  private readonly byAddr = new Map<string, string>();

  constructor(private readonly data: NamesResponse) {
    for (const host of data.hosts) {
      this.byMAC.set(host.mac.toLowerCase(), host.name);
      for (const address of host.addr) {
        this.byAddr.set(address, host.name);
      }
    }
  }

  client(address: string, mac?: string): string | undefined {
    return mac ? this.byMAC.get(mac.toLowerCase()) : this.byAddr.get(address);
  }

  group(id: string): GroupLabel | undefined {
    const rule = this.data.rules[id];
    if (rule) {
      return { kind: 'rule', name: rule };
    }

    const name = this.data.groups[id];
    return name ? { kind: 'group', name } : undefined;
  }
}

const listeners = new Set<() => void>();
let current: Names | null = null;
let loadedAt = 0;
let loading = false;

async function load(): Promise<void> {
  if (loading) {
    return;
  }

  loading = true;
  try {
    const response = await fetch('/api', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF': csrfToken() },
      body: JSON.stringify({ m: 'dns.names', p: {} }),
      credentials: 'include',
    });
    const body = await response.json() as { ok: boolean; data?: NamesResponse };
    if (body.ok && body.data) {
      current = new Names(body.data);
      loadedAt = Date.now();
      for (const listener of listeners) {
        listener();
      }
    }
  } catch {
    loadedAt = Date.now();
  } finally {
    loading = false;
  }
}

export function useNames(): Names | null {
  const [names, setNames] = React.useState<Names | null>(current);

  React.useEffect(() => {
    const onChange = (): void => { setNames(current); };
    listeners.add(onChange);
    if (Date.now() - loadedAt > REFRESH_EVERY) {
      void load();
    }

    const timer = setInterval(() => { void load(); }, REFRESH_EVERY);
    return () => {
      listeners.delete(onChange);
      clearInterval(timer);
    };
  }, []);

  return names;
}
