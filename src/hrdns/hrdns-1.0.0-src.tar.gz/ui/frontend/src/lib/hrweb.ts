export const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? '';

export function csrfToken(): string {
  const match = /(?:^|; )csrf=([^;]*)/.exec(document.cookie);
  return match ? decodeURIComponent(match[1]) : '';
}

export function websocketUrl(path: string): string {
  const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
  return `${protocol}://${window.location.host}${basePath}${path}?t=${encodeURIComponent(csrfToken())}`;
}
