export function clientLabel(address: string, name?: string): string {
  return name ? `${name} (${address})` : address;
}
