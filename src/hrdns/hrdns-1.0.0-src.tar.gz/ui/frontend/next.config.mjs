const basePath = '/dns-ui';

/** @type {import('next').NextConfig} */
const config = {
    output: 'export',
    basePath,
    env: { NEXT_PUBLIC_BASE_PATH: basePath },
    typedRoutes: false,
    generateBuildId: () => 'hrdns',
};

export default config;
