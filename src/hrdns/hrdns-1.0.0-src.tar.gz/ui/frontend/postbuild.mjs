import { copyFileSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { constants, gzipSync } from 'node:zlib';

const [out, dest, license] = process.argv.slice(2);
const keepSubsets = new Set(['latin', 'cyrillic']);
const unusedFiles = ['assets/error-401.png', 'assets/error-500.png'];
const storedAsIs = /\.(woff2|png|ico)$/;
const fontFile = /-(latin-ext|latin|cyrillic-ext|cyrillic|greek-ext|greek|vietnamese|math|symbols)-\d+-(?:normal|italic)\.[0-9a-f]+\.woff2?/;

function walk(dir) {
  return readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(join(dir, e.name)) : [join(dir, e.name)]));
}

const dropped = new Set();
for (const file of walk(out).filter((f) => f.endsWith('.css'))) {
  const css = readFileSync(file, 'utf8').replace(/@font-face\{[^}]*\}/g, (block) => {
    const woff2 = /url\(([^)]*\.woff2)\)/.exec(block);
    const subset = woff2 && fontFile.exec(woff2[1])?.[1];
    if (!woff2 || !keepSubsets.has(subset)) {
      for (const [, name] of block.matchAll(/url\([^)]*\/([^/)]+\.woff2?)\)/g)) dropped.add(name);
      return '';
    }

    return block.replace(/,url\([^)]*\.woff\)format\("woff"\)/, '');
  });
  writeFileSync(file, css);
}

for (const file of walk(out)) {
  const rel = relative(out, file);
  if (rel.endsWith('.woff') || dropped.has(rel.split('/').pop()) || unusedFiles.includes(rel) || rel.startsWith('locales/')) rmSync(file);
}

rmSync(dest, { recursive: true, force: true });
let raw = 0;
let packed = 0;
for (const file of walk(out)) {
  const rel = relative(out, file);
  const target = join(dest, rel);
  mkdirSync(dirname(target), { recursive: true });
  const data = readFileSync(file);
  raw += data.length;
  if (storedAsIs.test(rel)) {
    copyFileSync(file, target);
    packed += data.length;
  } else {
    const gz = gzipSync(data, { level: constants.Z_BEST_COMPRESSION });
    writeFileSync(`${target}.gz`, gz);
    packed += gz.length;
  }
}

copyFileSync(license, join(dest, 'LICENSE'));
console.log(`www: ${raw} bytes of assets stored as ${packed} bytes`);
