module hrdns-ui

go 1.25.7
