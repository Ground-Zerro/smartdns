package www

import (
	"bytes"
	"compress/gzip"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"io"
	"io/fs"
	"mime"
	"net/http"
	"path"
	"regexp"
	"strings"
)

type file struct {
	name string
	gz   bool
	tag  string
	mime string
	csp  string
}

const cspTemplate = "default-src 'self'; script-src 'self'%s; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'; object-src 'none'"

var inlineScript = regexp.MustCompile(`(?s)<script(?:\s[^>]*)?>(.*?)</script>`)

func contentSecurityPolicy(html []byte) string {
	hashes := ""
	for _, m := range inlineScript.FindAllSubmatch(html, -1) {
		if len(bytes.TrimSpace(m[1])) == 0 || bytes.Contains(m[0][:bytes.IndexByte(m[0], '>')], []byte(" src=")) {
			continue
		}

		sum := sha256.Sum256(m[1])
		hashes += " 'sha256-" + base64.StdEncoding.EncodeToString(sum[:]) + "'"
	}

	return strings.Replace(cspTemplate, "%s", hashes, 1)
}

type Handler struct {
	fsys  fs.FS
	files map[string]file
}

var mimeTypes = map[string]string{
	".html":  "text/html; charset=utf-8",
	".js":    "text/javascript; charset=utf-8",
	".css":   "text/css; charset=utf-8",
	".json":  "application/json",
	".txt":   "text/plain; charset=utf-8",
	".svg":   "image/svg+xml",
	".ico":   "image/x-icon",
	".png":   "image/png",
	".woff2": "font/woff2",
}

func New(fsys fs.FS) (*Handler, error) {
	h := &Handler{fsys: fsys, files: map[string]file{}}
	err := fs.WalkDir(fsys, ".", func(name string, d fs.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}

		data, err := fs.ReadFile(fsys, name)
		if err != nil {
			return err
		}

		sum := sha1.Sum(data)
		f := file{name: name, tag: `"` + hex.EncodeToString(sum[:8]) + `"`}
		logical := name
		if strings.HasSuffix(name, ".gz") {
			f.gz = true
			logical = strings.TrimSuffix(name, ".gz")
		}

		f.mime = mimeTypes[path.Ext(logical)]
		if f.mime == "" {
			f.mime = mime.TypeByExtension(path.Ext(logical))
		}

		if f.mime == "" {
			f.mime = "application/octet-stream"
		}

		if f.mime == mimeTypes[".html"] {
			html := data
			if f.gz {
				zr, err := gzip.NewReader(bytes.NewReader(data))
				if err != nil {
					return err
				}

				if html, err = io.ReadAll(zr); err != nil {
					return err
				}
			}

			f.csp = contentSecurityPolicy(html)
		}

		h.files[logical] = f
		return nil
	})
	return h, err
}

func (h *Handler) lookup(urlPath string) (file, int) {
	p := strings.TrimPrefix(path.Clean("/"+urlPath), "/")
	candidates := []string{p, p + ".html", path.Join(p, "index.html")}
	if p == "" {
		candidates = []string{"index.html"}
	}

	for _, c := range candidates {
		if f, ok := h.files[c]; ok {
			return f, http.StatusOK
		}
	}

	return h.files["404.html"], http.StatusNotFound
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet && r.Method != http.MethodHead {
		w.Header().Set("Allow", "GET, HEAD")
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}

	f, status := h.lookup(r.URL.Path)
	if f.name == "" {
		http.NotFound(w, r)
		return
	}

	hd := w.Header()
	hd.Set("Content-Type", f.mime)
	hd.Set("Vary", "Accept-Encoding")
	hd.Set("X-Content-Type-Options", "nosniff")
	if f.csp != "" {
		hd.Set("Content-Security-Policy", f.csp)
	}
	if strings.HasPrefix(r.URL.Path, "/_next/static/") {
		hd.Set("Cache-Control", "public, max-age=31536000, immutable")
	} else {
		hd.Set("Cache-Control", "no-cache")
	}

	if status == http.StatusOK {
		hd.Set("ETag", f.tag)
		if r.Header.Get("If-None-Match") == f.tag {
			w.WriteHeader(http.StatusNotModified)
			return
		}
	}

	src, err := h.fsys.Open(f.name)
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	defer src.Close()
	var body io.Reader = src
	if f.gz {
		if strings.Contains(r.Header.Get("Accept-Encoding"), "gzip") {
			hd.Set("Content-Encoding", "gzip")
		} else if body, err = gzip.NewReader(src); err != nil {
			http.Error(w, "internal error", http.StatusInternalServerError)
			return
		}
	}

	w.WriteHeader(status)
	if r.Method == http.MethodGet {
		io.Copy(w, body)
	}
}
