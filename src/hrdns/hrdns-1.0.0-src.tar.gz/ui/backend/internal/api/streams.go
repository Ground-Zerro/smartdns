package api

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"hrdns-ui/internal/ws"
)

const (
	controlType   = 1
	controlPause  = 1
	controlResume = 2
	controlLevel  = 3
)

type Subscriber interface {
	Acquire(logs, audit bool) func()
}

func (s *Server) serveWS(w http.ResponseWriter, r *http.Request, run func(c *ws.Conn, in <-chan []byte, stop <-chan struct{})) error {
	c, err := ws.Accept(w, r)
	if err != nil {
		return &apiError{http.StatusBadRequest, "Need websocket upgrade."}
	}

	defer c.Close()
	in := make(chan []byte, 16)
	stop := make(chan struct{})
	go func() {
		defer close(stop)
		for {
			op, data, err := c.Read()
			if err != nil {
				return
			}

			if op == ws.OpBinary {
				select {
				case in <- data:
				default:
				}
			}
		}
	}()

	run(c, in, stop)
	return nil
}

func (s *Server) metricsStream(w http.ResponseWriter, r *http.Request) error {
	return s.serveWS(w, r, func(c *ws.Conn, _ <-chan []byte, stop <-chan struct{}) {
		tick := time.NewTicker(time.Second)
		defer tick.Stop()
		for {
			data, err := json.Marshal(s.Metrics(r))
			if err != nil || c.WriteText(data) != nil {
				return
			}

			select {
			case <-stop:
				return
			case <-tick.C:
			}
		}
	})
}

func (s *Server) logStream(w http.ResponseWriter, r *http.Request) error {
	return s.serveWS(w, r, func(c *ws.Conn, in <-chan []byte, stop <-chan struct{}) {
		release := s.opts.Subs.Acquire(true, false)
		defer release()
		previous := s.currentLevel(r)
		defer s.restoreLevel(previous)
		s.stream(c, r, s.opts.Logs, in, stop, func(control []byte) {
			if len(control) < 3 || control[1] != controlLevel {
				return
			}

			if level := levelIndex(strings.ToLower(string(control[2:]))); level >= 0 {
				ctx, cancel := context.WithTimeout(context.Background(), resolverTimeout)
				s.opts.Resolver.Call(ctx, "log.set "+itoa(level))
				cancel()
			}
		})
	})
}

func (s *Server) auditStream(w http.ResponseWriter, r *http.Request) error {
	return s.serveWS(w, r, func(c *ws.Conn, in <-chan []byte, stop <-chan struct{}) {
		release := s.opts.Subs.Acquire(false, true)
		defer release()
		s.stream(c, r, s.opts.Audit, in, stop, func([]byte) {})
	})
}

func (s *Server) stream(c *ws.Conn, r *http.Request, hub *Hub, in <-chan []byte, stop <-chan struct{}, onLevel func(control []byte)) {
	lines, cancel := hub.Subscribe()
	defer cancel()
	paused := false
	for {
		select {
		case <-stop:
			return
		case control := <-in:
			if len(control) < 2 || control[0] != controlType {
				continue
			}

			switch control[1] {
			case controlPause:
				paused = true
			case controlResume:
				paused = false
			default:
				onLevel(control)
			}
		case line := <-lines:
			if !paused && c.WriteBinary(line) != nil {
				return
			}
		}
	}
}

func (s *Server) currentLevel(r *http.Request) int {
	data, err := s.call(r, "log.get")
	if err != nil {
		return -1
	}

	var v struct {
		LogLevel int `json:"log_level"`
	}
	if json.Unmarshal(data, &v) != nil {
		return -1
	}

	return v.LogLevel
}

func (s *Server) restoreLevel(level int) {
	if level < 0 {
		return
	}

	ctx, cancel := context.WithTimeout(context.Background(), resolverTimeout)
	defer cancel()
	s.opts.Resolver.Call(ctx, "log.set "+itoa(level))
}
