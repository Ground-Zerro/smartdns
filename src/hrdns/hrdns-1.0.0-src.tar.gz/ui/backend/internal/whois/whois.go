package whois

import (
	"context"
	"errors"
	"io"
	"net"
	"strings"
	"sync"
	"time"
)

const (
	rootServer   = "whois.iana.org"
	port         = "43"
	connectLimit = 10 * time.Second
	readLimit    = 10 * time.Second
	maxResponse  = 64 << 10
	maxHops      = 4
)

var ErrNotFound = errors.New("Cannot find whois.")

type Info struct {
	Domain       string
	Registrar    string
	Organization string
	Address      string
	City         string
	Country      string
}

type Client struct {
	root    string
	port    string
	mu      sync.Mutex
	servers map[string]string
}

func New() *Client { return NewWithServer(rootServer, port) }

func NewWithServer(root, port string) *Client {
	return &Client{root: root, port: port, servers: map[string]string{}}
}

func ValidDomain(name string) bool {
	if name == "" || len(name) > 253 {
		return false
	}

	for _, c := range name {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '.') {
			return false
		}
	}

	return !strings.HasPrefix(name, ".") && !strings.HasSuffix(name, ".") && !strings.Contains(name, "..")
}

var fields = []struct {
	prefix string
	set    func(i *Info, refer *string, v string)
}{
	{"organization:", func(i *Info, _ *string, v string) { i.Organization = v }},
	{"registrant:", func(i *Info, _ *string, v string) { i.Organization = v }},
	{"registrant name:", func(i *Info, _ *string, v string) { i.Organization = v }},
	{"registrant organization:", func(i *Info, _ *string, v string) { i.Organization = v }},
	{"registrar:", func(i *Info, _ *string, v string) { i.Registrar = v }},
	{"registrant street:", func(i *Info, _ *string, v string) { i.Address = v }},
	{"registrant city:", func(i *Info, _ *string, v string) { i.City = v }},
	{"registrant country:", func(i *Info, _ *string, v string) { i.Country = v }},
	{"registrant country code:", func(i *Info, _ *string, v string) { i.Country = v }},
	{"registrar whois server:", func(_ *Info, r *string, v string) { *r = v }},
	{"refer:", func(_ *Info, r *string, v string) { *r = v }},
	{"whois:", func(_ *Info, r *string, v string) { *r = v }},
}

func parse(text string) (info Info, refer string) {
	for _, line := range strings.Split(text, "\n") {
		line = strings.TrimSpace(line)
		lower := strings.ToLower(line)
		for _, f := range fields {
			if strings.HasPrefix(lower, f.prefix) {
				f.set(&info, &refer, strings.TrimSpace(line[len(f.prefix):]))
				break
			}
		}
	}

	return info, refer
}

func (c *Client) ask(ctx context.Context, server, query string) (string, error) {
	dialer := net.Dialer{Timeout: connectLimit}
	conn, err := dialer.DialContext(ctx, "tcp", net.JoinHostPort(server, c.port))
	if err != nil {
		return "", err
	}

	defer conn.Close()
	conn.SetDeadline(time.Now().Add(readLimit))
	if _, err := io.WriteString(conn, query+"\r\n"); err != nil {
		return "", err
	}

	data, err := io.ReadAll(io.LimitReader(conn, maxResponse))
	if err != nil && len(data) == 0 {
		return "", err
	}

	return string(data), nil
}

func (c *Client) knownServer(suffix string) string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if s, ok := c.servers[suffix]; ok {
		return s
	}

	return c.root
}

func (c *Client) remember(suffix, server string) {
	c.mu.Lock()
	c.servers[suffix] = server
	c.mu.Unlock()
}

func candidates(domain string) []string {
	labels := strings.Split(strings.ToLower(domain), ".")
	n := len(labels)
	switch {
	case n < 2:
		return []string{domain}
	case n == 2:
		return []string{domain}
	}

	return []string{strings.Join(labels[n-2:], "."), strings.Join(labels[n-3:], ".")}
}

func (c *Client) Query(ctx context.Context, domain string) (Info, error) {
	var best Info
	for _, name := range candidates(domain) {
		suffix := name[strings.IndexByte(name, '.')+1:]
		server := c.knownServer(suffix)
		for hop := 0; hop < maxHops && server != ""; hop++ {
			text, err := c.ask(ctx, server, name)
			if err != nil {
				if best.Registrar != "" {
					return best, nil
				}

				return Info{}, err
			}

			info, refer := parse(text)
			info.Domain = domain
			if info.Organization != "" {
				return info, nil
			}

			if info.Registrar != "" {
				best = info
			}

			if refer == "" || strings.EqualFold(refer, server) {
				break
			}

			c.remember(suffix, refer)
			server = refer
		}
	}

	if best.Registrar != "" {
		return best, nil
	}

	return Info{}, ErrNotFound
}
