package store

import (
	"encoding/binary"
	"os"
	"path/filepath"
	"slices"
	"time"
)

const (
	blockRecs = 4096
	dictCache = 4
)

type Tri uint8

const (
	Any Tri = iota
	Yes
	No
)

type Filter struct {
	Domain     string
	DomainMode string
	QType      int
	HasQType   bool
	Client     string
	Group      string
	HasGroup   bool
	RCode      int
	HasRCode   bool
	Blocked    Tri
	Cached     Tri
	After      int64
	Before     int64
}

func (f *Filter) unconstrained() bool {
	return f.Domain == "" && f.DomainMode == "" && !f.HasQType && f.Client == "" && !f.HasGroup && !f.HasRCode &&
		f.Blocked == Any && f.Cached == Any && f.After == 0 && f.Before == 0
}

type Record struct {
	ID         uint64
	TimeMs     int64
	Domain     string
	QType      uint16
	Client     string
	MAC        [macLen]byte
	Group      string
	RCode      uint8
	QueryMs    uint32
	PingTenths int32
	Blocked    bool
	Cached     bool
}

type PageSpec struct {
	Num        int
	Size       int
	Asc        bool
	Cursor     uint64
	HasCursor  bool
	Prev       bool
	TotalGiven bool
	Total      uint64
}

func (p *PageSpec) selectIndexes(idsAsc []uint64) []int {
	n := len(idsAsc)
	order := make([]int, n)
	for i := range order {
		order[i] = i
		if !p.Asc {
			order[i] = n - 1 - i
		}
	}

	if !p.HasCursor {
		start := (p.Num - 1) * p.Size
		if start >= n {
			return nil
		}

		return order[start:min(start+p.Size, n)]
	}

	var out []int
	forward := p.Asc
	if p.Prev {
		forward = !forward
	}

	for i := 0; i < n && len(out) < p.Size; i++ {
		idx := i
		if !forward {
			idx = n - 1 - i
		}

		id := idsAsc[idx]
		if (forward && id > p.Cursor) || (!forward && id < p.Cursor) {
			out = append(out, idx)
		}
	}

	if p.Prev {
		slices.Reverse(out)
	}

	return out
}

type dictView struct {
	day     int64
	arena   []byte
	offs    []uint32
	clients []clientKey
	groups  []string
}

func (d *dictView) domain(id uint32) []byte {
	if int(id) >= len(d.offs) {
		return nil
	}

	off := d.offs[id]
	n := binary.LittleEndian.Uint16(d.arena[off:])
	return d.arena[off+2 : off+2+uint32(n)]
}

func (d *dictView) client(id uint16) (addr string, mac [macLen]byte) {
	if int(id) >= len(d.clients) {
		return "", mac
	}

	k := &d.clients[id]
	return k.addr(), k.mac()
}

func (d *dictView) group(id uint8) string {
	if int(id) >= len(d.groups) {
		return ""
	}

	return d.groups[id]
}

func loadDictFiles(dir string, day int64) (*dictView, error) {
	d := &dictView{day: day}
	dom, err := os.ReadFile(filepath.Join(dir, fileNames[dictDom]))
	if err != nil {
		return nil, err
	}

	d.arena = dom
	for off := 0; off+2 <= len(dom); {
		n := int(binary.LittleEndian.Uint16(dom[off:]))
		if off+2+n > len(dom) {
			break
		}

		d.offs = append(d.offs, uint32(off))
		off += 2 + n
	}

	cli, err := os.ReadFile(filepath.Join(dir, fileNames[dictCli]))
	if err != nil {
		return nil, err
	}

	for off := 0; off+clientKeyLen <= len(cli); off += clientKeyLen {
		var k clientKey
		copy(k[:], cli[off:])
		d.clients = append(d.clients, k)
	}

	grp, err := os.ReadFile(filepath.Join(dir, fileNames[dictGrp]))
	if err != nil {
		return nil, err
	}

	for off := 0; off < len(grp) && off+1+int(grp[off]) <= len(grp); off += 1 + int(grp[off]) {
		d.groups = append(d.groups, string(grp[off+1:off+1+int(grp[off])]))
	}

	return d, nil
}

func (s *Store) loadDict(day int64) (*dictView, error) {
	s.dictMu.Lock()
	for _, d := range s.dicts {
		if d.day == day {
			s.dictMu.Unlock()
			return d, nil
		}
	}

	s.dictMu.Unlock()
	d, err := loadDictFiles(s.segDir(day), day)
	if err != nil {
		return nil, err
	}

	s.dictMu.Lock()
	s.dicts = append(s.dicts, d)
	if len(s.dicts) > dictCache {
		s.dicts = s.dicts[1:]
	}

	s.dictMu.Unlock()
	return d, nil
}

func (s *Store) forgetDict(day int64) {
	s.dictMu.Lock()
	s.dicts = slices.DeleteFunc(s.dicts, func(d *dictView) bool { return d.day == day })
	s.dictMu.Unlock()
}

type segView struct {
	s        *Store
	day      int64
	opened   bool
	empty    bool
	files    [numCols]*os.File
	nrec     int
	nflushed int
	pending  []rec
	dict     *dictView
}

func (s *Store) views() []*segView {
	s.mu.RLock()
	days := slices.Clone(s.days)
	c := s.cur
	doms := c.doms
	cur := &segView{
		s:        s,
		day:      c.day,
		opened:   true,
		nflushed: c.flushed,
		pending:  slices.Clone(c.pending),
		dict: &dictView{
			day:     c.day,
			arena:   doms.arena[:len(doms.arena):len(doms.arena)],
			offs:    doms.offs[:len(doms.offs):len(doms.offs)],
			clients: slices.Clone(c.clis),
			groups:  slices.Clone(c.grps.names),
		},
	}
	cur.nrec = cur.nflushed + len(cur.pending)
	curDir := c.dir
	s.mu.RUnlock()

	if !cur.openColumns(curDir) {
		cur.empty = true
	}

	out := make([]*segView, 0, len(days)+1)
	for _, d := range days {
		out = append(out, &segView{s: s, day: d})
	}

	return append(out, cur)
}

func (v *segView) openColumns(dir string) bool {
	for i := 0; i < numCols; i++ {
		f, err := os.Open(filepath.Join(dir, fileNames[i]))
		if err != nil {
			v.close()
			return false
		}

		v.files[i] = f
	}

	return true
}

func (v *segView) open() {
	if v.opened {
		return
	}

	v.opened = true
	dir := v.s.segDir(v.day)
	if !v.openColumns(dir) {
		v.empty = true
		return
	}

	records := -1
	for i, f := range v.files {
		st, err := f.Stat()
		if err != nil {
			v.close()
			v.empty = true
			return
		}

		if n := int(st.Size()) / colWidth[i]; records < 0 || n < records {
			records = n
		}
	}

	dict, err := v.s.loadDict(v.day)
	if err != nil {
		v.close()
		v.empty = true
		return
	}

	v.nrec, v.nflushed, v.dict = records, records, dict
}

func (v *segView) close() {
	for i, f := range v.files {
		if f != nil {
			f.Close()
			v.files[i] = nil
		}
	}
}

type blockBufs struct {
	cols   [numCols][]byte
	loaded [numCols]bool
	start  int
	n      int
	cand   []uint16
}

func newBlockBufs() *blockBufs {
	b := &blockBufs{cand: make([]uint16, 0, blockRecs)}
	for i := range b.cols {
		b.cols[i] = make([]byte, blockRecs*colWidth[i])
	}

	return b
}

func (b *blockBufs) reset(start, n int) {
	b.start, b.n = start, n
	b.loaded = [numCols]bool{}
}

func (v *segView) load(b *blockBufs, col int) bool {
	if b.loaded[col] {
		return true
	}

	w := colWidth[col]
	buf := b.cols[col][:cap(b.cols[col])][:b.n*w]
	if _, err := v.files[col].ReadAt(buf, int64(b.start*w)); err != nil {
		return false
	}

	b.cols[col], b.loaded[col] = buf, true
	return true
}

func (v *segView) loadAll(b *blockBufs) bool {
	for col := 0; col < numCols; col++ {
		if !v.load(b, col) {
			return false
		}
	}

	return true
}

func decodeRec(b *blockBufs, i int, r *rec) {
	r.tms = getU32(b.cols[colTms], i)
	r.dom = getU24(b.cols[colDom], i)
	r.cli = getU16(b.cols[colCli], i)
	r.grp = b.cols[colGrp][i]
	r.qtype = getU16(b.cols[colQType], i)
	r.rcode = b.cols[colRCode][i]
	r.flags = b.cols[colFlags][i]
	r.qms = getU16(b.cols[colQms], i)
	r.ping = getU16(b.cols[colPing], i)
}

const (
	predCli = iota
	predGrp
	predRCode
	predQType
	predFlags
	predDom
	predTime
)

type segFilter struct {
	skip     bool
	preds    []int
	domSet   []bool
	cliSet   []bool
	cliOne   int
	grp      int
	qtype    int
	rcode    int
	flagMask uint8
	flagWant uint8
	loTms    uint32
	hiTms    uint32
	constant bool
}

func lowerByte(c byte) byte {
	if c >= 'A' && c <= 'Z' {
		return c + 32
	}

	return c
}

func containsFold(name []byte, needleLower string) bool {
	n := len(needleLower)
	for i := 0; i+n <= len(name); i++ {
		j := 0
		for j < n && lowerByte(name[i+j]) == needleLower[j] {
			j++
		}

		if j == n {
			return true
		}
	}

	return false
}

func lowerString(s string) string {
	b := []byte(s)
	for i := range b {
		b[i] = lowerByte(b[i])
	}

	return string(b)
}

func (f *Filter) compile(v *segView) segFilter {
	sf := segFilter{grp: -1, qtype: -1, rcode: -1, cliOne: -1, loTms: 0, hiTms: dayMillis - 1}
	dayStart := v.day * dayMillis
	lo, hi := int64(0), int64(dayMillis-1)
	if f.After != 0 {
		lo = max(0, f.After-dayStart)
	}

	if f.Before != 0 {
		hi = min(dayMillis-1, f.Before-dayStart)
	}

	if lo > hi {
		sf.skip = true
		return sf
	}

	sf.loTms, sf.hiTms = uint32(lo), uint32(hi)
	if f.HasQType {
		sf.qtype = f.QType
		sf.preds = append(sf.preds, predQType)
	}

	if f.HasRCode {
		sf.rcode = f.RCode
		sf.preds = append(sf.preds, predRCode)
	}

	if f.HasGroup {
		for i, g := range v.dict.groups {
			if g == f.Group {
				sf.grp = i
			}
		}

		if sf.grp < 0 {
			sf.skip = true
			return sf
		}

		sf.preds = append(sf.preds, predGrp)
	}

	if f.Blocked != Any {
		sf.flagMask |= flagBlocked
		if f.Blocked == Yes {
			sf.flagWant |= flagBlocked
		}
	}

	if f.Cached != Any {
		sf.flagMask |= flagCached
		if f.Cached == Yes {
			sf.flagWant |= flagCached
		}
	}

	if sf.flagMask != 0 {
		sf.preds = append(sf.preds, predFlags)
	}

	if f.Client != "" {
		sf.cliSet = make([]bool, len(v.dict.clients))
		matched := 0
		for i := range v.dict.clients {
			if addr, _ := v.dict.client(uint16(i)); addr == f.Client {
				sf.cliSet[i] = true
				sf.cliOne = i
				matched++
			}
		}

		if matched == 0 {
			sf.skip = true
			return sf
		}

		if matched > 1 {
			sf.cliOne = -1
		}

		sf.preds = append(sf.preds, predCli)
	}

	if f.Domain != "" || f.DomainMode == "notempty" {
		sf.domSet = make([]bool, len(v.dict.offs))
		needle := lowerString(f.Domain)
		matched := 0
		for id := range v.dict.offs {
			name := v.dict.domain(uint32(id))
			var ok bool
			switch f.DomainMode {
			case "contains":
				ok = containsFold(name, needle)
			case "notempty":
				ok = len(name) > 0
			default:
				ok = string(name) == f.Domain
			}

			if ok {
				sf.domSet[id] = true
				matched++
			}
		}

		if matched == 0 {
			sf.skip = true
			return sf
		}

		sf.preds = append(sf.preds, predDom)
	}

	if sf.loTms != 0 || sf.hiTms != dayMillis-1 {
		sf.preds = append(sf.preds, predTime)
	}

	slices.Sort(sf.preds)
	sf.constant = len(sf.preds) == 0
	return sf
}

func (sf *segFilter) matchRec(r *rec) bool {
	if sf.constant {
		return true
	}

	if r.tms < sf.loTms || r.tms > sf.hiTms {
		return false
	}

	if sf.domSet != nil && (int(r.dom) >= len(sf.domSet) || !sf.domSet[r.dom]) {
		return false
	}

	if sf.cliSet != nil && (int(r.cli) >= len(sf.cliSet) || !sf.cliSet[r.cli]) {
		return false
	}

	if sf.grp >= 0 && int(r.grp) != sf.grp {
		return false
	}

	if sf.qtype >= 0 && int(r.qtype) != sf.qtype {
		return false
	}

	if sf.rcode >= 0 && int(r.rcode) != sf.rcode {
		return false
	}

	return r.flags&sf.flagMask == sf.flagWant
}

func (sf *segFilter) testAt(pred int, b *blockBufs, i int) bool {
	switch pred {
	case predCli:
		id := int(getU16(b.cols[colCli], i))
		return id < len(sf.cliSet) && sf.cliSet[id]
	case predGrp:
		return int(b.cols[colGrp][i]) == sf.grp
	case predRCode:
		return int(b.cols[colRCode][i]) == sf.rcode
	case predQType:
		return int(getU16(b.cols[colQType], i)) == sf.qtype
	case predFlags:
		return b.cols[colFlags][i]&sf.flagMask == sf.flagWant
	case predDom:
		id := int(getU24(b.cols[colDom], i))
		return id < len(sf.domSet) && sf.domSet[id]
	default:
		t := getU32(b.cols[colTms], i)
		return t >= sf.loTms && t <= sf.hiTms
	}
}

var predColumn = [...]int{predCli: colCli, predGrp: colGrp, predRCode: colRCode, predQType: colQType, predFlags: colFlags, predDom: colDom, predTime: colTms}

func (sf *segFilter) scanFirst(pred int, b *blockBufs) {
	n := b.n
	cand := b.cand[:0]
	col := b.cols[predColumn[pred]]
	switch pred {
	case predCli:
		if sf.cliOne >= 0 {
			lo, hi := byte(sf.cliOne), byte(sf.cliOne>>8)
			for i := 0; i < n; i++ {
				if col[i*2] == lo && col[i*2+1] == hi {
					cand = append(cand, uint16(i))
				}
			}
		} else {
			for i := 0; i < n; i++ {
				if id := int(getU16(col, i)); id < len(sf.cliSet) && sf.cliSet[id] {
					cand = append(cand, uint16(i))
				}
			}
		}
	case predGrp:
		want := byte(sf.grp)
		for i := 0; i < n; i++ {
			if col[i] == want {
				cand = append(cand, uint16(i))
			}
		}
	case predRCode:
		want := byte(sf.rcode)
		for i := 0; i < n; i++ {
			if col[i] == want {
				cand = append(cand, uint16(i))
			}
		}
	case predQType:
		lo, hi := byte(sf.qtype), byte(sf.qtype>>8)
		for i := 0; i < n; i++ {
			if col[i*2] == lo && col[i*2+1] == hi {
				cand = append(cand, uint16(i))
			}
		}
	case predFlags:
		for i := 0; i < n; i++ {
			if col[i]&sf.flagMask == sf.flagWant {
				cand = append(cand, uint16(i))
			}
		}
	case predDom:
		for i := 0; i < n; i++ {
			if id := int(getU24(col, i)); id < len(sf.domSet) && sf.domSet[id] {
				cand = append(cand, uint16(i))
			}
		}
	default:
		for i := 0; i < n; i++ {
			if t := getU32(col, i); t >= sf.loTms && t <= sf.hiTms {
				cand = append(cand, uint16(i))
			}
		}
	}

	b.cand = cand
}

func (v *segView) matchBlock(sf *segFilter, b *blockBufs) bool {
	if sf.constant {
		b.cand = b.cand[:0]
		for i := 0; i < b.n; i++ {
			b.cand = append(b.cand, uint16(i))
		}

		return true
	}

	for k, pred := range sf.preds {
		if !v.load(b, predColumn[pred]) {
			return false
		}

		if k == 0 {
			sf.scanFirst(pred, b)
			continue
		}

		kept := b.cand[:0]
		for _, i := range b.cand {
			if sf.testAt(pred, b, int(i)) {
				kept = append(kept, i)
			}
		}

		b.cand = kept
		if len(kept) == 0 {
			break
		}
	}

	return true
}

func (v *segView) scan(sf *segFilter, desc bool, lo, hi int, deadline time.Time, fn func(idx int, r *rec) bool) (completed bool) {
	fileHi := min(hi, v.nflushed)
	pendLo := max(lo, v.nflushed)
	if desc {
		for i := hi - 1; i >= pendLo; i-- {
			if r := &v.pending[i-v.nflushed]; sf.matchRec(r) && !fn(i, r) {
				return true
			}
		}
	}

	if lo < fileHi && !v.scanFile(sf, desc, lo, fileHi, deadline, fn) {
		return false
	}

	if !desc {
		for i := pendLo; i < hi; i++ {
			if r := &v.pending[i-v.nflushed]; sf.matchRec(r) && !fn(i, r) {
				return true
			}
		}
	}

	return true
}

func (v *segView) scanFile(sf *segFilter, desc bool, lo, hi int, deadline time.Time, fn func(idx int, r *rec) bool) (completed bool) {
	b := newBlockBufs()
	var r rec
	for step := 0; step < hi-lo; step += blockRecs {
		start, end := lo+step, min(hi, lo+step+blockRecs)
		if desc {
			end = hi - step
			start = max(lo, end-blockRecs)
		}

		if !deadline.IsZero() && time.Now().After(deadline) {
			return false
		}

		b.reset(start, end-start)
		if !v.matchBlock(sf, b) {
			return true
		}

		if len(b.cand) == 0 {
			continue
		}

		if !v.loadAll(b) {
			return true
		}

		for k := range b.cand {
			i := int(b.cand[k])
			if desc {
				i = int(b.cand[len(b.cand)-1-k])
			}

			decodeRec(b, i, &r)
			if !fn(start+i, &r) {
				return true
			}
		}
	}

	return true
}

func (v *segView) count(sf *segFilter, lo, hi int, deadline time.Time) (n uint64, completed bool) {
	fileHi := min(hi, v.nflushed)
	b := newBlockBufs()
	for start := lo; start < fileHi; start += blockRecs {
		if !deadline.IsZero() && time.Now().After(deadline) {
			return n, false
		}

		b.reset(start, min(fileHi, start+blockRecs)-start)
		if !v.matchBlock(sf, b) {
			return n, true
		}

		n += uint64(len(b.cand))
	}

	for i := max(lo, v.nflushed); i < hi; i++ {
		if sf.matchRec(&v.pending[i-v.nflushed]) {
			n++
		}
	}

	return n, true
}

func (v *segView) record(idx int, r *rec) Record {
	addr, mac := v.dict.client(r.cli)
	return Record{
		ID:         recordID(v.day, idx),
		TimeMs:     v.day*dayMillis + int64(r.tms),
		Domain:     string(v.dict.domain(r.dom)),
		QType:      r.qtype,
		Client:     addr,
		MAC:        mac,
		Group:      v.dict.group(r.grp),
		RCode:      r.rcode,
		QueryMs:    uint32(r.qms),
		PingTenths: pingTenths(r.ping),
		Blocked:    r.flags&flagBlocked != 0,
		Cached:     r.flags&flagCached != 0,
	}
}

func pingTenths(v uint16) int32 {
	if v == pingNone {
		return -1
	}

	return int32(v)
}

type ListResult struct {
	Records      []Record
	Total        uint64
	StepByCursor bool
	Truncated    bool
}

func (s *Store) iterate(views []*segView, f *Filter, desc bool, boundary uint64, hasBoundary bool, deadline time.Time, fn func(v *segView, idx int, r *rec) bool) (completed bool) {
	order := views
	if desc {
		order = slices.Clone(views)
		slices.Reverse(order)
	}

	bDay, bIdx := splitID(boundary)
	for _, v := range order {
		if hasBoundary && ((desc && v.day > bDay) || (!desc && v.day < bDay)) {
			continue
		}

		v.open()
		if v.empty {
			continue
		}

		lo, hi := 0, v.nrec
		if hasBoundary && v.day == bDay {
			if desc {
				hi = min(hi, max(bIdx, 0))
			} else {
				lo = min(hi, bIdx+1)
			}
		}

		sf := f.compile(v)
		if sf.skip || lo >= hi {
			continue
		}

		stopped := false
		done := v.scan(&sf, desc, lo, hi, deadline, func(idx int, r *rec) bool {
			if !fn(v, idx, r) {
				stopped = true
				return false
			}

			return true
		})
		if !done {
			return false
		}

		if stopped {
			return true
		}
	}

	return true
}

func (s *Store) List(f *Filter, p PageSpec, budget time.Duration) ListResult {
	views := s.views()
	defer func() {
		for _, v := range views {
			v.close()
		}
	}()

	res := ListResult{StepByCursor: p.HasCursor || p.TotalGiven}
	desc := !p.Asc
	cursorMode := p.HasCursor
	if cursorMode && p.Prev {
		desc = !desc
	}

	skip := 0
	if !cursorMode {
		skip = (p.Num - 1) * p.Size
	}

	s.iterate(views, f, desc, p.Cursor, cursorMode, time.Time{}, func(v *segView, idx int, r *rec) bool {
		if skip > 0 {
			skip--
			return true
		}

		res.Records = append(res.Records, v.record(idx, r))
		return len(res.Records) < p.Size
	})
	if cursorMode && p.Prev {
		slices.Reverse(res.Records)
	}

	if p.TotalGiven {
		res.Total = p.Total
		return res
	}

	total, complete := s.countViews(views, f, budget)
	res.Total, res.Truncated = total, !complete
	return res
}

func (s *Store) countViews(views []*segView, f *Filter, budget time.Duration) (uint64, bool) {
	var total uint64
	if f.unconstrained() {
		for _, v := range views {
			v.open()
			if !v.empty {
				total += uint64(v.nrec)
			}
		}

		return total, true
	}

	var deadline time.Time
	if budget > 0 {
		deadline = time.Now().Add(budget)
	}

	for i := len(views) - 1; i >= 0; i-- {
		v := views[i]
		v.open()
		if v.empty {
			continue
		}

		sf := f.compile(v)
		if sf.skip {
			continue
		}

		n, done := v.count(&sf, 0, v.nrec, deadline)
		total += n
		if !done {
			return total, false
		}
	}

	return total, true
}

func (s *Store) Count(f *Filter, budget time.Duration) (uint64, bool) {
	views := s.views()
	defer func() {
		for _, v := range views {
			v.close()
		}
	}()

	return s.countViews(views, f, budget)
}

func (s *Store) Get(id uint64) (Record, bool) {
	day, idx := splitID(id)
	views := s.views()
	defer func() {
		for _, v := range views {
			v.close()
		}
	}()

	for _, v := range views {
		if v.day != day {
			continue
		}

		v.open()
		if v.empty || idx < 0 || idx >= v.nrec {
			return Record{}, false
		}

		if idx >= v.nflushed {
			r := v.pending[idx-v.nflushed]
			return v.record(idx, &r), true
		}

		b := newBlockBufs()
		b.reset(idx, 1)
		if !v.loadAll(b) {
			return Record{}, false
		}

		var r rec
		decodeRec(b, 0, &r)
		return v.record(idx, &r), true
	}

	return Record{}, false
}
