package store

import (
	"bytes"
	"encoding/binary"
	"net/netip"
)

type domainTable struct {
	arena    []byte
	offs     []uint32
	counts   []uint32
	slots    []uint32
	mask     uint32
	other    uint32
	hasOther bool
}

func newDomainTable() *domainTable {
	return &domainTable{slots: make([]uint32, 1024), mask: 1023}
}

func hashBytes(b []byte) uint32 {
	h := uint32(2166136261)
	for _, c := range b {
		h = (h ^ uint32(c)) * 16777619
	}

	return h
}

func (t *domainTable) count() int { return len(t.offs) }

func (t *domainTable) get(id uint32) []byte {
	off := t.offs[id]
	n := binary.LittleEndian.Uint16(t.arena[off:])
	return t.arena[off+2 : off+2+uint32(n)]
}

func (t *domainTable) find(b []byte, h uint32) (slot uint32, id uint32, found bool) {
	for i := h & t.mask; ; i = (i + 1) & t.mask {
		v := t.slots[i]
		if v == 0 {
			return i, 0, false
		}

		if bytes.Equal(t.get(v-1), b) {
			return i, v - 1, true
		}
	}
}

func (t *domainTable) append(b []byte) uint32 {
	id := uint32(len(t.offs))
	t.offs = append(t.offs, uint32(len(t.arena)))
	t.counts = append(t.counts, 0)
	t.arena = binary.LittleEndian.AppendUint16(t.arena, uint16(len(b)))
	t.arena = append(t.arena, b...)
	return id
}

func (t *domainTable) grow() {
	t.slots = make([]uint32, len(t.slots)*2)
	t.mask = uint32(len(t.slots) - 1)
	for id := range t.offs {
		if t.hasOther && uint32(id) == t.other {
			continue
		}

		i := hashBytes(t.get(uint32(id))) & t.mask
		for t.slots[i] != 0 {
			i = (i + 1) & t.mask
		}

		t.slots[i] = uint32(id) + 1
	}
}

func (t *domainTable) insert(b []byte, id uint32) {
	if len(t.offs)*2 > len(t.slots) {
		t.grow()
	}

	slot, _, _ := t.find(b, hashBytes(b))
	t.slots[slot] = id + 1
}

func (t *domainTable) intern(b []byte) uint32 {
	if len(b) > 0xFFFF {
		b = b[:0xFFFF]
	}

	slot, id, found := t.find(b, hashBytes(b))
	if found {
		return id
	}

	if len(t.offs) >= maxDomains {
		if !t.hasOther {
			t.other = t.append([]byte(overflowDomain))
			t.hasOther = true
		}

		return t.other
	}

	if (len(t.offs)+1)*2 > len(t.slots) {
		t.grow()
		slot, _, _ = t.find(b, hashBytes(b))
	}

	id = t.append(b)
	t.slots[slot] = id + 1
	return id
}

func (t *domainTable) load(arena []byte) int {
	t.arena = t.arena[:0]
	t.offs = t.offs[:0]
	t.counts = t.counts[:0]
	t.hasOther = false
	for i := range t.slots {
		t.slots[i] = 0
	}

	off := 0
	for off+2 <= len(arena) {
		n := int(binary.LittleEndian.Uint16(arena[off:]))
		if off+2+n > len(arena) {
			break
		}

		name := arena[off+2 : off+2+n]
		id := t.append(name)
		if string(name) == overflowDomain {
			t.other = id
			t.hasOther = true
		} else {
			t.insert(name, id)
		}

		off += 2 + n
	}

	return off
}

type clientKey [clientKeyLen]byte

func makeClientKey(family byte, addr [addrLen]byte, mac [macLen]byte) clientKey {
	var k clientKey
	k[0] = family
	copy(k[1:], addr[:])
	copy(k[1+addrLen:], mac[:])
	return k
}

func (k *clientKey) addr() string { return formatAddr(k[0], [addrLen]byte(k[1:1+addrLen])) }

func (k *clientKey) mac() [macLen]byte { return [macLen]byte(k[1+addrLen:]) }

func formatAddr(family byte, addr [addrLen]byte) string {
	switch family {
	case 4:
		return netip.AddrFrom4([4]byte(addr[:4])).String()
	case 6:
		return netip.AddrFrom16(addr).String()
	}

	return ""
}

type groupTable struct {
	names []string
}

func (g *groupTable) intern(b []byte) uint8 {
	for i, n := range g.names {
		if n == string(b) {
			return uint8(i)
		}
	}

	if len(g.names) >= maxGroups {
		return maxGroups - 1
	}

	g.names = append(g.names, string(b))
	return uint8(len(g.names) - 1)
}
