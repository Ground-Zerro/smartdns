package store

import (
	"encoding/json"
	"os"
	"path/filepath"
)

type stateFile struct {
	Total   uint64 `json:"total"`
	Blocked uint64 `json:"blocked"`
	Failed  uint64 `json:"failed"`
}

func (s *Store) statePath() string { return filepath.Join(s.cfg.Dir, "state.json") }

func (s *Store) loadState() error {
	data, err := os.ReadFile(s.statePath())
	if os.IsNotExist(err) {
		return nil
	}

	if err != nil {
		return err
	}

	var st stateFile
	if err := json.Unmarshal(data, &st); err != nil {
		return nil
	}

	s.total.Store(st.Total)
	s.blocked.Store(st.Blocked)
	s.failed.Store(st.Failed)
	return nil
}

func (s *Store) saveState() error {
	data, err := json.Marshal(stateFile{Total: s.total.Load(), Blocked: s.blocked.Load(), Failed: s.failed.Load()})
	if err != nil {
		return err
	}

	return atomicWrite(s.statePath(), data)
}

func (s *Store) Totals() (total, blocked, failed uint64) {
	return s.total.Load(), s.blocked.Load(), s.failed.Load()
}

func atomicWrite(path string, data []byte) error {
	tmp := path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
	if err != nil {
		return err
	}

	if _, err := f.Write(data); err != nil {
		f.Close()
		os.Remove(tmp)
		return err
	}

	if err := f.Sync(); err != nil {
		f.Close()
		os.Remove(tmp)
		return err
	}

	if err := f.Close(); err != nil {
		os.Remove(tmp)
		return err
	}

	return os.Rename(tmp, path)
}
