package ws

import (
	"bufio"
	"crypto/rand"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"
)

type Client struct {
	conn net.Conn
	rd   *bufio.Reader
}

func Dial(rawURL string, header http.Header) (*Client, error) {
	u, err := url.Parse(rawURL)
	if err != nil {
		return nil, err
	}

	conn, err := net.Dial("tcp", u.Host)
	if err != nil {
		return nil, err
	}

	nonce := make([]byte, 16)
	rand.Read(nonce)
	key := base64.StdEncoding.EncodeToString(nonce)
	var sb strings.Builder
	fmt.Fprintf(&sb, "GET %s HTTP/1.1\r\nHost: %s\r\nConnection: Upgrade\r\nUpgrade: websocket\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: %s\r\n", u.RequestURI(), u.Host, key)
	for name, values := range header {
		for _, v := range values {
			fmt.Fprintf(&sb, "%s: %s\r\n", name, v)
		}
	}

	sb.WriteString("\r\n")
	if _, err := conn.Write([]byte(sb.String())); err != nil {
		conn.Close()
		return nil, err
	}

	rd := bufio.NewReader(conn)
	resp, err := http.ReadResponse(rd, &http.Request{Method: http.MethodGet})
	if err != nil {
		conn.Close()
		return nil, err
	}

	if resp.StatusCode != http.StatusSwitchingProtocols {
		resp.Body.Close()
		conn.Close()
		return nil, fmt.Errorf("ws: handshake refused with status %d", resp.StatusCode)
	}

	sum := sha1.Sum([]byte(key + guid))
	if resp.Header.Get("Sec-WebSocket-Accept") != base64.StdEncoding.EncodeToString(sum[:]) {
		conn.Close()
		return nil, errors.New("ws: bad accept key")
	}

	return &Client{conn: conn, rd: rd}, nil
}

func (c *Client) Close() error { return c.conn.Close() }

func (c *Client) Send(op byte, payload []byte) error {
	frame := []byte{0x80 | op}
	switch l := len(payload); {
	case l < 126:
		frame = append(frame, 0x80|byte(l))
	case l <= 0xFFFF:
		frame = append(frame, 0x80|126)
		frame = binary.BigEndian.AppendUint16(frame, uint16(l))
	default:
		frame = append(frame, 0x80|127)
		frame = binary.BigEndian.AppendUint64(frame, uint64(l))
	}

	mask := make([]byte, 4)
	rand.Read(mask)
	frame = append(frame, mask...)
	for i, b := range payload {
		frame = append(frame, b^mask[i&3])
	}

	_, err := c.conn.Write(frame)
	return err
}

func (c *Client) Recv() (op byte, payload []byte, err error) {
	var head [2]byte
	if _, err = io.ReadFull(c.rd, head[:]); err != nil {
		return 0, nil, err
	}

	size := uint64(head[1] & 0x7F)
	switch size {
	case 126:
		var ext [2]byte
		if _, err = io.ReadFull(c.rd, ext[:]); err != nil {
			return 0, nil, err
		}

		size = uint64(binary.BigEndian.Uint16(ext[:]))
	case 127:
		var ext [8]byte
		if _, err = io.ReadFull(c.rd, ext[:]); err != nil {
			return 0, nil, err
		}

		size = binary.BigEndian.Uint64(ext[:])
	}

	payload = make([]byte, size)
	_, err = io.ReadFull(c.rd, payload)
	return head[0] & 0x0F, payload, err
}

func (c *Client) RecvWithin(d time.Duration) (op byte, payload []byte, err error) {
	c.conn.SetReadDeadline(time.Now().Add(d))
	defer c.conn.SetReadDeadline(time.Time{})
	return c.Recv()
}

const OpClose = opClose

func IsUpgrade(r *http.Request) bool {
	return strings.EqualFold(r.Header.Get("Upgrade"), "websocket")
}
