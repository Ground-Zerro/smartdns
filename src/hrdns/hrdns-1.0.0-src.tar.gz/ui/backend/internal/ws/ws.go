package ws

import (
	"bufio"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"
)

const (
	OpText   = 1
	OpBinary = 2
	opClose  = 8
	opPing   = 9
	opPong   = 10

	guid         = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
	maxMessage   = 1 << 20
	writeTimeout = 10 * time.Second
)

var (
	ErrNotUpgrade = errors.New("ws: not a websocket upgrade request")
	ErrProtocol   = errors.New("ws: protocol violation")
	ErrTooLarge   = errors.New("ws: message too large")
)

type Conn struct {
	conn net.Conn
	rd   *bufio.Reader
	mu   sync.Mutex
}

func headerHas(h http.Header, name, token string) bool {
	for _, v := range h.Values(name) {
		for t := range strings.SplitSeq(v, ",") {
			if strings.EqualFold(strings.TrimSpace(t), token) {
				return true
			}
		}
	}

	return false
}

func Accept(w http.ResponseWriter, r *http.Request) (*Conn, error) {
	key := r.Header.Get("Sec-WebSocket-Key")
	if r.Method != http.MethodGet || !headerHas(r.Header, "Connection", "upgrade") || !headerHas(r.Header, "Upgrade", "websocket") ||
		r.Header.Get("Sec-WebSocket-Version") != "13" || key == "" {
		return nil, ErrNotUpgrade
	}

	hj, ok := w.(http.Hijacker)
	if !ok {
		return nil, errors.New("ws: connection cannot be hijacked")
	}

	conn, rw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}

	sum := sha1.Sum([]byte(key + guid))
	resp := "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " +
		base64.StdEncoding.EncodeToString(sum[:]) + "\r\n\r\n"
	conn.SetWriteDeadline(time.Now().Add(writeTimeout))
	if _, err := conn.Write([]byte(resp)); err != nil {
		conn.Close()
		return nil, err
	}

	conn.SetWriteDeadline(time.Time{})
	return &Conn{conn: conn, rd: rw.Reader}, nil
}

func (c *Conn) Close() error { return c.conn.Close() }

func (c *Conn) write(op byte, payload []byte) error {
	var header [10]byte
	header[0] = 0x80 | op
	n := 2
	switch l := len(payload); {
	case l < 126:
		header[1] = byte(l)
	case l <= 0xFFFF:
		header[1] = 126
		binary.BigEndian.PutUint16(header[2:], uint16(l))
		n = 4
	default:
		header[1] = 127
		binary.BigEndian.PutUint64(header[2:], uint64(l))
		n = 10
	}

	c.mu.Lock()
	defer c.mu.Unlock()
	c.conn.SetWriteDeadline(time.Now().Add(writeTimeout))
	if _, err := c.conn.Write(header[:n]); err != nil {
		return err
	}

	_, err := c.conn.Write(payload)
	return err
}

func (c *Conn) WriteText(p []byte) error { return c.write(OpText, p) }

func (c *Conn) WriteBinary(p []byte) error { return c.write(OpBinary, p) }

func (c *Conn) CloseWith(code uint16, reason string) error {
	payload := binary.BigEndian.AppendUint16(nil, code)
	payload = append(payload, reason...)
	if len(payload) > 125 {
		payload = payload[:125]
	}

	c.write(opClose, payload)
	return c.conn.Close()
}

func (c *Conn) Read() (op byte, payload []byte, err error) {
	var message []byte
	var messageOp byte
	for {
		var head [2]byte
		if _, err = io.ReadFull(c.rd, head[:]); err != nil {
			return 0, nil, err
		}

		fin, frameOp, masked := head[0]&0x80 != 0, head[0]&0x0F, head[1]&0x80 != 0
		size := uint64(head[1] & 0x7F)
		switch size {
		case 126:
			var ext [2]byte
			if _, err = io.ReadFull(c.rd, ext[:]); err != nil {
				return 0, nil, err
			}

			size = uint64(binary.BigEndian.Uint16(ext[:]))
		case 127:
			var ext [8]byte
			if _, err = io.ReadFull(c.rd, ext[:]); err != nil {
				return 0, nil, err
			}

			size = binary.BigEndian.Uint64(ext[:])
		}

		if !masked {
			return 0, nil, ErrProtocol
		}

		if size > maxMessage || uint64(len(message))+size > maxMessage {
			return 0, nil, ErrTooLarge
		}

		var mask [4]byte
		if _, err = io.ReadFull(c.rd, mask[:]); err != nil {
			return 0, nil, err
		}

		data := make([]byte, size)
		if _, err = io.ReadFull(c.rd, data); err != nil {
			return 0, nil, err
		}

		for i := range data {
			data[i] ^= mask[i&3]
		}

		switch frameOp {
		case opPing:
			if err = c.write(opPong, data); err != nil {
				return 0, nil, err
			}

			continue
		case opPong:
			continue
		case opClose:
			c.write(opClose, data)
			return 0, nil, io.EOF
		case 0:
			if messageOp == 0 {
				return 0, nil, ErrProtocol
			}
		case OpText, OpBinary:
			if messageOp != 0 {
				return 0, nil, ErrProtocol
			}

			messageOp = frameOp
		default:
			return 0, nil, ErrProtocol
		}

		message = append(message, data...)
		if fin {
			return messageOp, message, nil
		}
	}
}
