package tz

import (
	"encoding/binary"
	"os"
	"strings"
	"time"
)

func Load(path string) *time.Location {
	data, err := os.ReadFile(path)
	if err != nil {
		return time.Local
	}

	loc, err := FromPOSIX(strings.TrimSpace(string(data)))
	if err != nil {
		return time.Local
	}

	return loc
}

func FromPOSIX(spec string) (*time.Location, error) {
	data := appendHeader(nil, 0, 0)
	data = appendHeader(data, 1, 4)
	data = append(data, 0, 0, 0, 0, 0, 0)
	data = append(data, "UTC\x00"...)
	data = append(data, "\n"+spec+"\n"...)
	return time.LoadLocationFromTZData(spec, data)
}

func appendHeader(data []byte, types, chars uint32) []byte {
	data = append(data, "TZif2"...)
	data = append(data, make([]byte, 15)...)
	for _, n := range [...]uint32{0, 0, 0, 0, types, chars} {
		data = binary.BigEndian.AppendUint32(data, n)
	}

	return data
}
