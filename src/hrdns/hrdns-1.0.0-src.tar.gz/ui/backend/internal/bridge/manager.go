package bridge

import (
	"context"
	"encoding/json"
	"sync"
	"time"
)

const subscribeTimeout = 3 * time.Second

type Manager struct {
	client  *Client
	handler Handler
	mu      sync.Mutex
	logSubs int
	audSubs int
}

func NewManager(client *Client, handler Handler) *Manager {
	return &Manager{client: client, handler: handler}
}

func (m *Manager) mask() string {
	mask := "q"
	if m.logSubs > 0 {
		mask += "l"
	}

	if m.audSubs > 0 {
		mask += "a"
	}

	return mask
}

func (m *Manager) Run(ctx context.Context) error {
	done := make(chan error, 1)
	go func() { done <- m.client.Run(m.handler) }()

	m.mu.Lock()
	mask := m.mask()
	m.mu.Unlock()
	subCtx, cancel := context.WithTimeout(ctx, subscribeTimeout)
	err := m.client.Subscribe(subCtx, mask)
	cancel()
	if err != nil {
		return err
	}

	select {
	case err = <-done:
		return err
	case <-ctx.Done():
		return nil
	}
}

func (m *Manager) Hello() Hello { return m.client.Hello() }

func (m *Manager) Call(ctx context.Context, command string) (json.RawMessage, error) {
	return m.client.Call(ctx, command)
}

func (m *Manager) Acquire(logs, audit bool) (release func()) {
	m.mu.Lock()
	if logs {
		m.logSubs++
	}

	if audit {
		m.audSubs++
	}

	m.mu.Unlock()
	m.resubscribe()
	var once sync.Once
	return func() {
		once.Do(func() {
			m.mu.Lock()
			if logs {
				m.logSubs--
			}

			if audit {
				m.audSubs--
			}

			m.mu.Unlock()
			m.resubscribe()
		})
	}
}

func (m *Manager) resubscribe() {
	m.mu.Lock()
	mask := m.mask()
	m.mu.Unlock()
	ctx, cancel := context.WithTimeout(context.Background(), subscribeTimeout)
	defer cancel()
	m.client.Subscribe(ctx, mask)
}
