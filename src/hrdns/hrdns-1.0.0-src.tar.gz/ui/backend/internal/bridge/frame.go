package bridge

import (
	"bufio"
	"encoding/binary"
	"errors"
	"io"
)

const (
	KindCmd   byte = 0x02
	KindUILog byte = 0x03
	KindHello byte = 0x81
	KindReply byte = 0x82
	KindQuery byte = 0x90
	KindLog   byte = 0x91
	KindAudit byte = 0x92
	KindLost  byte = 0x93

	headerSize   = 5
	maxLogText   = 255
	maxFrame     = 8 << 20
	retainedSize = 64 << 10
)

var ErrFrameTooLarge = errors.New("bridge: frame too large")

type FrameReader struct {
	r   *bufio.Reader
	hdr [headerSize]byte
	buf []byte
}

func NewFrameReader(r io.Reader) *FrameReader {
	return &FrameReader{r: bufio.NewReaderSize(r, 32<<10), buf: make([]byte, 0, 1024)}
}

func (f *FrameReader) Next() (byte, []byte, error) {
	if _, err := io.ReadFull(f.r, f.hdr[:]); err != nil {
		return 0, nil, err
	}

	n := int(binary.LittleEndian.Uint32(f.hdr[:4]))
	if n > maxFrame {
		return 0, nil, ErrFrameTooLarge
	}

	var payload []byte
	switch {
	case n > retainedSize:
		payload = make([]byte, n)
	case n > cap(f.buf):
		f.buf = make([]byte, n, retainedSize)
		payload = f.buf
	default:
		payload = f.buf[:n]
	}

	if _, err := io.ReadFull(f.r, payload); err != nil {
		return 0, nil, err
	}

	return f.hdr[4], payload, nil
}

func AppendFrame(dst []byte, kind byte, payload []byte) []byte {
	dst = binary.LittleEndian.AppendUint32(dst, uint32(len(payload)))
	dst = append(dst, kind)
	return append(dst, payload...)
}
