package bridge

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"os"
	"strconv"
	"sync"
	"sync/atomic"
)

var (
	ErrClosed       = errors.New("bridge: connection closed")
	ErrUnexpected   = errors.New("bridge: unexpected frame")
	ErrCommandFails = errors.New("bridge: command failed")
)

type Hello struct {
	Build      string `json:"build"`
	ServerName string `json:"server_name"`
	StartedMs  int64  `json:"started_ms"`
}

type Handler interface {
	OnQuery(q *Query)
	OnLog(level byte, text []byte)
	OnAudit(text []byte)
	OnLost(count uint32)
}

type reply struct {
	ID    uint64          `json:"id"`
	OK    bool            `json:"ok"`
	Data  json.RawMessage `json:"data"`
	Error string          `json:"error"`
}

type Client struct {
	conn    net.Conn
	frames  *FrameReader
	hello   Hello
	nextID  atomic.Uint64
	writeMu sync.Mutex
	mu      sync.Mutex
	pending map[uint64]chan reply
	done    chan struct{}
	err     error
}

func FromFD(fd uintptr) (*Client, error) {
	f := os.NewFile(fd, "bridge")
	defer f.Close()
	conn, err := net.FileConn(f)
	if err != nil {
		return nil, err
	}

	return NewClient(conn)
}

func NewClient(conn net.Conn) (*Client, error) {
	c := &Client{conn: conn, frames: NewFrameReader(conn), pending: map[uint64]chan reply{}, done: make(chan struct{})}
	kind, payload, err := c.frames.Next()
	if err != nil {
		conn.Close()
		return nil, err
	}

	if kind != KindHello {
		conn.Close()
		return nil, ErrUnexpected
	}

	if err := json.Unmarshal(payload, &c.hello); err != nil {
		conn.Close()
		return nil, err
	}

	return c, nil
}

func (c *Client) Hello() Hello { return c.hello }

func (c *Client) Done() <-chan struct{} { return c.done }

func (c *Client) Err() error {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.err
}

func (c *Client) Close() { c.conn.Close() }

func (c *Client) Run(h Handler) error {
	var q Query
	var err error
	for {
		var kind byte
		var payload []byte
		if kind, payload, err = c.frames.Next(); err != nil {
			break
		}

		switch kind {
		case KindQuery:
			if err = q.Decode(payload); err != nil {
				break
			}
			h.OnQuery(&q)
		case KindLog:
			if len(payload) > 0 {
				h.OnLog(payload[0], payload[1:])
			}
		case KindAudit:
			h.OnAudit(payload)
		case KindLost:
			if len(payload) >= 4 {
				h.OnLost(uint32(payload[0]) | uint32(payload[1])<<8 | uint32(payload[2])<<16 | uint32(payload[3])<<24)
			}
		case KindReply:
			c.deliver(payload)
		}

		if err != nil {
			break
		}
	}

	c.fail(err)
	return err
}

func (c *Client) deliver(payload []byte) {
	var r reply
	if json.Unmarshal(payload, &r) != nil {
		return
	}

	c.mu.Lock()
	ch := c.pending[r.ID]
	delete(c.pending, r.ID)
	c.mu.Unlock()
	if ch != nil {
		ch <- r
	}
}

func (c *Client) fail(err error) {
	c.mu.Lock()
	if c.err == nil {
		c.err = err
		close(c.done)
	}
	c.pending = map[uint64]chan reply{}
	c.mu.Unlock()
	c.conn.Close()
}

func (c *Client) Call(ctx context.Context, command string) (json.RawMessage, error) {
	id := c.nextID.Add(1)
	ch := make(chan reply, 1)
	c.mu.Lock()
	if c.err != nil {
		c.mu.Unlock()
		return nil, ErrClosed
	}
	c.pending[id] = ch
	c.mu.Unlock()

	payload := strconv.AppendUint(make([]byte, 0, 32+len(command)), id, 10)
	payload = append(payload, ' ')
	payload = append(payload, command...)
	frame := AppendFrame(nil, KindCmd, payload)

	c.writeMu.Lock()
	_, err := c.conn.Write(frame)
	c.writeMu.Unlock()
	if err != nil {
		c.fail(err)
		return nil, err
	}

	select {
	case r := <-ch:
		if !r.OK {
			return nil, fmt.Errorf("%w: %s", ErrCommandFails, r.Error)
		}
		return r.Data, nil
	case <-c.done:
		return nil, ErrClosed
	case <-ctx.Done():
		c.mu.Lock()
		delete(c.pending, id)
		c.mu.Unlock()
		return nil, ctx.Err()
	}
}

func (c *Client) Log(level byte, text string) {
	text = text[:min(len(text), maxLogText)]
	frame := AppendFrame(nil, KindUILog, append([]byte{level}, text...))
	c.writeMu.Lock()
	c.conn.Write(frame)
	c.writeMu.Unlock()
}

func (c *Client) Subscribe(ctx context.Context, mask string) error {
	_, err := c.Call(ctx, "subscribe "+mask)
	return err
}
