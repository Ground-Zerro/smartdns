package webui

import "embed"

//go:embed all:www
var Assets embed.FS
