#!/bin/sh
set -eu

ROOT=$(cd "$(dirname "$0")/.." && pwd)
VERSION=$(cat "$ROOT/VERSION")
TC=${TC:-}
ARCHS=${ARCHS:-"x86_64 mipsel"}
OPENSSL_VER=3.5.8
OPENSSL_SHA256=a8f84a39918ec6415ce765d9b429d313ba97b8143169c172e734b9514464f5b2
SSL_TRIM="no-err no-filenames no-tls1 no-tls1_1 no-ct no-ocsp no-nextprotoneg no-http no-rfc3779 no-multiblock no-autoload-config no-camellia no-aria no-sm2 no-sm3 no-sm4 no-idea no-seed no-whirlpool no-md4 no-mdc2 no-rc2 no-rc4 no-rc5 no-bf no-cast no-des no-dsa no-srp no-cms no-ts no-siphash no-scrypt no-gost no-rmd160 no-ssl3 no-dtls no-cmp no-ocb no-sctp no-srtp no-psk no-weak-ssl-ciphers no-argon2 no-ec2m no-sm2-precomp no-ml-dsa no-slh-dsa"
BUILD="$ROOT/build"
export SOURCE_DATE_EPOCH=${SOURCE_DATE_EPOCH:-$(date -d 2026-10-04 +%s)}

frontend() {
    (cd "$ROOT/ui/frontend" && npm ci --no-audit --no-fund --loglevel=error \
        && NODE_ENV=production NEXT_TELEMETRY_DISABLED=1 npx next build >"$BUILD/frontend.log" 2>&1 || { cat "$BUILD/frontend.log"; exit 1; }
        node postbuild.mjs out "$ROOT/ui/backend/www" "$ROOT/LICENSES/MIT-smartdns-webui.txt")
}

openssl_source() {
    [ -d "$BUILD/src/openssl-$OPENSSL_VER" ] && return
    mkdir -p "$BUILD/src"
    curl -fsSL "https://github.com/openssl/openssl/releases/download/openssl-$OPENSSL_VER/openssl-$OPENSSL_VER.tar.gz" -o "$BUILD/src/openssl.tar.gz"
    echo "$OPENSSL_SHA256  $BUILD/src/openssl.tar.gz" | sha256sum -c - >/dev/null
    tar xzf "$BUILD/src/openssl.tar.gz" -C "$BUILD/src"
    rm "$BUILD/src/openssl.tar.gz"
}

openssl_build() {
    ssl="$BUILD/$arch/openssl${TRIM:+-trim}"
    [ -f "$ssl/opt/lib/libssl.a" ] && return
    openssl_source
    osrc="$BUILD/$arch/openssl-src"
    rm -rf "$osrc" "$ssl"
    cp -r "$BUILD/src/openssl-$OPENSSL_VER" "$osrc"
    (cd "$osrc" && CC="$CC" AR="$AR" RANLIB="$RANLIB" ./Configure "$ssl_target" \
        no-shared no-tests no-docs no-apps no-engine no-legacy no-comp no-dso no-async no-ui-console ${TRIM:+$SSL_TRIM} \
        --prefix=/opt --openssldir=/opt/etc/ssl --libdir=lib -Os && make -j"$(nproc)" build_libs >/dev/null \
        && make install_dev DESTDIR="$ssl" >/dev/null)
    rm -rf "$osrc"
}

ui_build() {
    (cd "$ROOT/ui/backend" && env GOOS=linux GOARCH="$goarch" ${gomips:+GOMIPS=$gomips} CGO_ENABLED=0 \
        go build -trimpath -buildvcs=false -ldflags "-s -w -X main.version=$VERSION" -o "$out/hrdns-ui" ./cmd/hrdns-ui)
}

core_build() {
    work="$BUILD/$arch/core"
    rm -rf "$work"
    cp -r "$ROOT/core" "$work"
    if [ "$arch" = x86_64 ]; then
        make -C "$work" -j"$(nproc)" WITH_ZLIB=no VER="$VERSION" UI_BLOB="$out/hrdns-ui" >/dev/null
    else
        make -C "$work" -j"$(nproc)" CC="$CC" AR="$AR" STATIC=yes WITH_ZLIB=no VER="$VERSION" UI_BLOB="$out/hrdns-ui" \
            CFLAGS="-Os -ffunction-sections -fdata-sections -I$ssl/opt/include -Iinclude" \
            EXTRA_LDFLAGS="-L$ssl/opt/lib -Wl,--gc-sections -s" >/dev/null
    fi
    cp "$work/hrdns" "$out/hrdns"
}

mkdir -p "$BUILD"
[ -n "${FRONTEND:-}" ] && frontend

for arch in $ARCHS; do
    out="$BUILD/$arch"
    mkdir -p "$out"
    gomips=
    case "$arch" in
        x86_64) goarch=amd64 ;;
        mipsel) tc=mipsel-linux-muslsf; ssl_target=linux-mips32; goarch=mipsle; gomips=softfloat ;;
        mips) tc=mips-linux-muslsf; ssl_target=linux-mips32; goarch=mips; gomips=softfloat ;;
        aarch64) tc=aarch64-linux-musl; ssl_target=linux-aarch64; goarch=arm64 ;;
        *) echo "неизвестная архитектура: $arch" >&2; exit 1 ;;
    esac
    if [ "$arch" != x86_64 ]; then
        [ -n "$TC" ] || { echo "TC — каталог с тулчейнами musl (mipsel-linux-muslsf-cross и т. д.) — не задан" >&2; exit 1; }
        PATH="$TC/$tc-cross/bin:$PATH"
        CC="$tc-gcc"
        AR="$tc-ar"
        RANLIB="$tc-ranlib"
        openssl_build
    fi
    ui_build
    core_build
    ls -l "$out/hrdns-ui" "$out/hrdns"
done
