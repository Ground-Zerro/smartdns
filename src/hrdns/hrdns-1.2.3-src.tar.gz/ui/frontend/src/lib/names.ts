import * as React from 'react';

import { csrfToken } from '@/lib/hrweb';

interface NamedHost {
  mac: string;
  name: string;
  addr: string[];
}

interface NamesResponse {
  hosts?: NamedHost[];
  rules?: Record<string, string>;
  groups?: Record<string, string>;
  blocks?: Record<string, string>;
  servers?: Record<string, string>;
  bootstrap?: string[];
}

export interface GroupLabel {
  kind: 'rule' | 'group';
  name: string;
}

const REFRESH_EVERY = 30_000;

export class Names {
  private readonly byMAC = new Map<string, string>();
  private readonly byAddr = new Map<string, string>();
  private readonly rules: Record<string, string>;
  private readonly groups: Record<string, string>;
  private readonly blocks: Record<string, string>;
  private readonly servers: Record<string, string>;
  private readonly bootstrap: Set<string>;

  constructor(data: NamesResponse) {
    this.rules = data.rules ?? {};
    this.groups = data.groups ?? {};
    this.blocks = data.blocks ?? {};
    this.servers = data.servers ?? {};
    this.bootstrap = new Set(data.bootstrap);
    for (const host of data.hosts ?? []) {
      this.byMAC.set(host.mac.toLowerCase(), host.name);
      for (const address of host.addr) {
        this.byAddr.set(address, host.name);
      }
    }
  }

  client(address: string, mac?: string): string | undefined {
    return mac ? this.byMAC.get(mac.toLowerCase()) : this.byAddr.get(address);
  }

  group(id: string): GroupLabel | undefined {
    const rule = this.rules[id];
    if (rule) {
      return { kind: 'rule', name: rule };
    }

    const name = this.groups[id];
    return name ? { kind: 'group', name } : undefined;
  }

  blockList(id: number): string | undefined {
    return this.blocks[String(id)];
  }

  server(address: string): string | undefined {
    return this.servers[address];
  }

  isBootstrap(ip: string, port: number, type: string): boolean {
    return type === 'udp' && port === 53 && this.bootstrap.has(ip);
  }
}

const listeners = new Set<() => void>();
let current: Names | null = null;
let loadedAt = 0;
let loading = false;

async function load(): Promise<void> {
  if (loading) {
    return;
  }

  loading = true;
  try {
    const response = await fetch('/api', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF': csrfToken() },
      body: JSON.stringify({ m: 'dns.names', p: {} }),
      credentials: 'include',
    });
    const body = await response.json() as { ok: boolean; data?: NamesResponse };
    if (body.ok && body.data) {
      current = new Names(body.data);
      loadedAt = Date.now();
      for (const listener of listeners) {
        listener();
      }
    }
  } catch {
    loadedAt = Date.now();
  } finally {
    loading = false;
  }
}

export function useNames(): Names | null {
  const [names, setNames] = React.useState<Names | null>(current);

  React.useEffect(() => {
    const onChange = (): void => { setNames(current); };
    listeners.add(onChange);
    if (Date.now() - loadedAt > REFRESH_EVERY) {
      void load();
    }

    const timer = setInterval(() => { void load(); }, REFRESH_EVERY);
    return () => {
      listeners.delete(onChange);
      clearInterval(timer);
    };
  }, []);

  return names;
}
