const SIZE_UNITS = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ'];

export function size2str(size: number): string {
    let value = size;
    let unit = 0;
    while (value >= 1024 && unit < SIZE_UNITS.length - 1) {
        value /= 1024;
        unit++;
    }
    return `${value.toLocaleString('ru-RU', { maximumFractionDigits: unit ? 1 : 0 })} ${SIZE_UNITS[unit]}`;
}

export function removeColorCodes (text: string): string {
    const escapeSequence = String.fromCodePoint(0x1B);
    const regex = new RegExp(`${escapeSequence}\\[[\\d;]*m`, 'g');
    return text.replaceAll(regex, '');
}