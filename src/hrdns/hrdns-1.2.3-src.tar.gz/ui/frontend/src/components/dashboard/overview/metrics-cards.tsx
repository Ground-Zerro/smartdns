"use client";

import { websocketUrl } from '@/lib/hrweb';
import * as React from 'react';
import { Alert, Box, IconButton, Tooltip } from '@mui/material';
import CleaningServicesOutlinedIcon from '@mui/icons-material/CleaningServicesOutlined';
import { useSnackbar } from 'notistack';
import { useRouter } from 'next/navigation';
import { t } from 'i18next';
import { MetricsBar, MetricsCard, MetricsPill, MetricsSpark, MetricsUnit, type MetricsTone } from '@/components/dashboard/overview/metrics-card';
import { type Mertrics, smartdnsServer } from '@/lib/backend/server';
import { size2str } from '@/lib/utils';
import { CachedDomainsDialog } from './cached-domains-dialog';
import { paths } from '@/paths';

const QPS_HISTORY = 60;
const FAST_MS = 100;
const SLOW_MS = 300;
const LOW_HIT_RATE = 40;

const count = (n: number): string => n.toLocaleString('ru-RU');
const decimal = (n: number): string => n.toLocaleString('ru-RU', { maximumFractionDigits: 1 });

function speed(ms: number): [MetricsTone, string] {
    if (ms < FAST_MS) return ['ok', 'Fast'];
    if (ms < SLOW_MS) return ['warn', 'Slow'];
    return ['bad', 'Very Slow'];
}

export function MetricsCards(): React.JSX.Element {
    const [cardata, setCardData] = React.useState<Mertrics | null>(null);
    const [qpsHistory, setQpsHistory] = React.useState<number[]>([]);
    const [cacheDialogOpen, setCacheDialogOpen] = React.useState<boolean>(false);
    const [flushing, setFlushing] = React.useState<boolean>(false);
    const reconnectTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);
    const socketRef = React.useRef<WebSocket | null>(null);
    const doClose = React.useRef<boolean>(false);
    const { enqueueSnackbar } = useSnackbar();
    const router = useRouter();
    const connectRef = React.useRef<() => void>(() => { /* will be set below */ });

    function close(): void {
        if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
            reconnectTimeoutRef.current = null;
        }

        if (socketRef.current) {
            socketRef.current.close();
            socketRef.current = null;
        }
    }

    const handleCloseCacheDialog = React.useCallback(() => {
        setCacheDialogOpen(false);
    }, []);

    const flushCache = (): void => {
        setFlushing(true);
        smartdnsServer.FlushCache()
            .then((res) => enqueueSnackbar(t(res.error ? 'Clear Cache Failed' : 'Clear Cache Success')))
            .catch(() => enqueueSnackbar(t('Clear Cache Failed')))
            .finally(() => { setFlushing(false); });
    };

    const connect = React.useCallback((): void => {
        const socket = new WebSocket(websocketUrl('/api/stats/metrics'));
        socketRef.current = socket;

        socket.onmessage = (event: MessageEvent) => {
            try {
                const data = JSON.parse(event.data as string) as Mertrics;
                setCardData(data);
                setQpsHistory((prev) => [...prev.slice(1 - QPS_HISTORY), data.qps]);
            } catch {
                // NOOP
            }
        }

        socket.onclose = (_event: CloseEvent) => {
            if (doClose.current) {
                doClose.current = false;
                return;
            }

            reconnectTimeoutRef.current = setTimeout(function reconnect() {
                close();
                connectRef.current();
            }, 3000);
        }
    }, []);

    React.useEffect(() => {
        connectRef.current = connect;
    }, [connect]);

    React.useEffect(() => {
        connectRef.current();
        return (): void => {
            doClose.current = true;
            close();
        }
    }, [connect]);

    const m = cardata;
    const [speedTone, speedWord] = speed(m?.avg_query_time ?? 0);

    return (
        <Box>
            {m?.is_metrics_suspended ? <Box sx={{ height: '60px' }}>
                <Alert severity="error">{t("Server request processing has been suspended, please check whether there is enough disk space.")}</Alert>
            </Box> : null}
            <Box sx={{ display: 'grid', gap: { xs: 1, sm: 1.5 }, gridAutoRows: '1fr', gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', md: 'repeat(3, minmax(0, 1fr))', xl: 'repeat(6, minmax(0, 1fr))' } }}>
                <MetricsCard title="Total Query Count"
                    value={m ? count(m.total_query_count) : '—'}
                    onClick={() => router.push(paths.dashboard.queryLog)} />
                <MetricsCard title="Blocked Query Count"
                    value={m ? count(m.block_query_count) : '—'}
                    detail={m?.total_query_count ? <MetricsPill tone="warn">{decimal(m.block_query_count / m.total_query_count * 100)}%</MetricsPill> : null}
                    onClick={() => router.push(`${paths.dashboard.queryLog}?is_blocked=true`)} />
                <MetricsCard title="Query Per Second"
                    value={m ? count(m.qps) : '—'}
                    detail={<MetricsSpark history={qpsHistory} />} />
                <MetricsCard title="Cache Hit Rate"
                    value={m ? <>{decimal(m.cache_hit_rate)}<MetricsUnit>%</MetricsUnit></> : '—'}
                    detail={m ? <MetricsBar percent={m.cache_hit_rate} tone={m.cache_hit_rate < LOW_HIT_RATE ? 'warn' : 'ok'} /> : null} />
                <MetricsCard title="Cache Number"
                    value={m ? count(m.cache_number) : '—'}
                    detail={m ? size2str(m.cache_memory_size) : null}
                    action={<Tooltip title={t('Clear Cache')}>
                        <span onClick={(e) => { e.stopPropagation(); }}>
                            <IconButton size="small" aria-label={t('Clear Cache')} disabled={flushing} onClick={flushCache}
                                sx={{ width: 22, height: 22, mt: '-3px', mr: '-6px', borderRadius: '6px', color: 'inherit' }}>
                                <CleaningServicesOutlinedIcon sx={{ fontSize: 15 }} />
                            </IconButton>
                        </span>
                    </Tooltip>}
                    onClick={() => { setCacheDialogOpen(true); }} />
                <MetricsCard title="Average Query Time"
                    value={m ? <>{decimal(m.avg_query_time)}<MetricsUnit>{t('ms')}</MetricsUnit></> : '—'}
                    detail={m ? <MetricsPill tone={speedTone}>{t(speedWord)}</MetricsPill> : null}
                    onClick={() => router.push(paths.dashboard.upstreamServers)} />
            </Box>
            <CachedDomainsDialog open={cacheDialogOpen} onClose={handleCloseCacheDialog} />
        </Box>
    );
}
