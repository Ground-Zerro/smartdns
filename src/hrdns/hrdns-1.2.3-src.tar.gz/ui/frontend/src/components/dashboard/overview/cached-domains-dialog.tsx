"use client";

import * as React from 'react';
import {
    MaterialReactTable,
    useMaterialReactTable,
    type MRT_ColumnDef as MRTColumnDef,
    type MRT_PaginationState as MRTPaginationState,
} from 'material-react-table';
import { MRT_Localization_RU } from 'material-react-table/locales/ru';
import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Tooltip } from '@mui/material';
import { useColorScheme } from '@mui/material/styles';
import RefreshIcon from '@mui/icons-material/Refresh';
import { useTranslation } from 'react-i18next';
import { smartdnsServer } from '@/lib/backend/server';
import type { CachedDomainInfo } from '@/lib/backend/server';
import { clipSx, compactTableOptions } from '@/lib/mrt-table';
import { colorSchemes } from '@/styles/theme/color-schemes';
import { getDomainTypeName } from '@/components/dashboard/query-log/domain-type';

const PAGE_SIZE_KEY = 'cachedDomainsRowsPerPage';
const PAGE_SIZES = [10, 20, 50, 100];

function savedPageSize(): number {
    const saved = Number(localStorage.getItem(PAGE_SIZE_KEY));
    return PAGE_SIZES.includes(saved) ? saved : 20;
}

interface CachedDomainsDialogProps {
    open: boolean;
    onClose: () => void;
}

function CachedDomainsTable(): React.JSX.Element {
    const { t } = useTranslation();
    const { colorScheme } = useColorScheme();
    const [domains, setDomains] = React.useState<CachedDomainInfo[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);
    const [errorMsg, setErrorMsg] = React.useState('');
    const [pagination, setPagination] = React.useState<MRTPaginationState>(() => ({ pageIndex: 0, pageSize: savedPageSize() }));

    const fetchData = React.useCallback(async (): Promise<void> => {
        setIsLoading(true);
        const res = await smartdnsServer.GetCacheDomains();
        setErrorMsg(res.error ? smartdnsServer.getErrorMessage(res.error) : '');
        setDomains(res.data ?? []);
        setIsLoading(false);
    }, []);

    React.useEffect(() => {
        fetchData().catch((_error: unknown) => {
            setErrorMsg(t('Failed to load cache domains'));
            setIsLoading(false);
        });
    }, [fetchData, t]);

    const columns = React.useMemo<MRTColumnDef<CachedDomainInfo>[]>(() => [
        { accessorKey: 'id', header: t('ID') },
        {
            accessorKey: 'domain',
            header: t('Domain'),
            Cell: ({ cell, renderedCellValue }) => (
                <Tooltip title={cell.getValue<string>()} arrow placement="top">
                    <Box component="span" sx={clipSx}>{renderedCellValue}</Box>
                </Tooltip>
            ),
        },
        {
            accessorKey: 'qtype',
            header: t('Type'),
            Cell: ({ cell }) => getDomainTypeName(cell.getValue<number>()),
        },
        {
            accessorKey: 'cached_time',
            header: t('Time'),
            Cell: ({ cell }) => new Date(cell.getValue<number>() * 1000).toLocaleString('ru-RU'),
        },
        { accessorKey: 'ttl_remaining', header: t('TTL (s)') },
    ], [t]);

    const table = useMaterialReactTable({
        columns,
        data: domains,
        localization: MRT_Localization_RU,
        ...compactTableOptions<CachedDomainInfo>(),
        enableColumnActions: false,
        enableColumnFilters: false,
        enableClickToCopy: window.isSecureContext,
        enableGlobalFilterRankedResults: false,
        enableKeyboardShortcuts: false,
        muiPaginationProps: { rowsPerPageOptions: PAGE_SIZES },
        muiToolbarAlertBannerProps: errorMsg ? { color: 'error', children: errorMsg } : undefined,
        onPaginationChange: (updater) => {
            setPagination((prev) => {
                const next = typeof updater === 'function' ? updater(prev) : updater;
                localStorage.setItem(PAGE_SIZE_KEY, String(next.pageSize));
                return next;
            });
        },
        renderTopToolbarCustomActions: () => (
            <Tooltip arrow title={t('Refresh Data')}>
                <span>
                    <IconButton disabled={isLoading} onClick={async () => fetchData()}>
                        <RefreshIcon />
                    </IconButton>
                </span>
            </Tooltip>
        ),
        initialState: {
            density: 'compact',
            showGlobalFilter: true,
        },
        state: {
            pagination,
            showAlertBanner: errorMsg.length > 0,
            showProgressBars: isLoading,
            showSkeletons: isLoading && domains.length === 0,
        },
        mrtTheme: {
            baseBackgroundColor: colorSchemes[colorScheme === 'light' ? 'light' : 'dark'].palette.dashboard.modal,
        },
    });

    return <MaterialReactTable table={table} />;
}

export const CachedDomainsDialog = React.memo(function CachedDomainsDialog({ open, onClose }: CachedDomainsDialogProps): React.JSX.Element {
    const { t } = useTranslation();
    return (
        <Dialog
            open={open}
            onClose={onClose}
            maxWidth="lg"
            fullWidth
            slotProps={{
                backdrop: { sx: { bgcolor: 'var(--mui-palette-dashboard-scrim)' } },
                paper: {
                    elevation: 0,
                    sx: {
                        maxHeight: '85dvh',
                        p: '22px 24px',
                        border: '1px solid var(--mui-palette-dashboard-modalBorder)',
                        borderRadius: '18px',
                        bgcolor: 'var(--mui-palette-dashboard-modal)',
                        backgroundImage: 'none',
                        boxShadow: 'var(--mui-palette-dashboard-modalShadow)',
                    },
                },
            }}
        >
            <DialogTitle sx={{ p: 0, mb: 1.5, fontSize: 18, fontWeight: 600, color: 'var(--mui-palette-dashboard-value)' }}>
                {t('Cached Domains')}
            </DialogTitle>
            <DialogContent sx={{ p: 0 }}>
                <CachedDomainsTable />
            </DialogContent>
            <DialogActions sx={{ p: 0, mt: 1, justifyContent: 'center' }}>
                <Button onClick={onClose}>{t('Close')}</Button>
            </DialogActions>
        </Dialog>
    );
});
