"use client"

import * as React from 'react';
import { useMemo, useState } from 'react';
import {
  MaterialReactTable,
  useMaterialReactTable,
  type MRT_ColumnFilterFnsState as MRTColumnFilterFnsState,
  type MRT_ColumnDef as MRTColumnDef,
  type MRT_ColumnFiltersState as MRTColumnFiltersState,
  type MRT_PaginationState as MRTPaginationState,
  type MRT_SortingState as MRTSortingState,
} from 'material-react-table';
import { Box, IconButton, Tooltip, Chip } from '@mui/material';
import { createTheme, useColorScheme } from '@mui/material/styles';
import RefreshIcon from '@mui/icons-material/Refresh';
import dayjs from 'dayjs';
import {
  QueryClient,
  QueryClientProvider,
  keepPreviousData,
  useQuery,
} from '@tanstack/react-query';

import { type DomainList, type QueryLogsParams, smartdnsServer } from '@/lib/backend/server';
import { useTranslation } from 'react-i18next';
import { MRT_Localization_RU } from 'material-react-table/locales/ru';
import { DeleteSweep } from '@mui/icons-material';
import { type SnackbarOrigin, SnackbarProvider, useSnackbar } from 'notistack';
import { getDomainTypeName, getDomainTypeId } from './domain-type';
import { clientLabel } from '@/lib/client-label';
import { useNames } from '@/lib/names';
import { clipSx, compactTableOptions, usePersistedVisibility } from '@/lib/mrt-table';


interface UserApiResponse {
  data: DomainList[];
  meta: {
    totalRowCount: number;
  };
};

const defaultVisibility = { id: false, timestamp: false, ping_time: false, reply_code: false };

interface PageCursor {
  pageNumber: number;
  firstID: number;
  lastID: number;
}


function TableQueryLogs(): React.JSX.Element {
  const { t } = useTranslation();
  const names = useNames();

  const columns = useMemo<MRTColumnDef<DomainList>[]>(
    () => [
      {
        accessorKey: 'id',
        header: t('ID'),
        enableColumnActions: false,
        columnFilterModeOptions: ['equals'],
      },
      {
        accessorKey: 'domain',
        header: t('Domain'),
        enableColumnActions: false,
        columnFilterModeOptions: ['contains', 'equals'],
        Cell: ({ cell, renderedCellValue }) => (
          <Tooltip title={cell.getValue<string>()} arrow placement="top">
            <Box component="span" sx={clipSx}>{renderedCellValue}</Box>
          </Tooltip>
        ),
      },
      {
        accessorKey: 'is_blocked',
        header: t('Is Blocked'),
        filterVariant: 'select',
        enableColumnFilterModes: false,
        filterSelectOptions: [
          { value: '', label: t('All') },
          { value: 'true', label: t('Blocked') },
          { value: 'false', label: t('Allowed') },
        ],
        filterFn: (row, _id, value) => {
          if (value === '') return true;
          return row.original.is_blocked === (value === 'true');
        },
        Cell: ({ cell, row }) => {
          if (!cell.getValue<boolean>()) {
            return <Chip label={t('Allowed')} color="success" size="small" variant="outlined" />;
          }
          const list = row.original.block_list ? names?.blockList(row.original.block_list) : undefined;
          const label = list ? `${t('Blocked')} · ${list}` : t('Blocked');
          return (
            <Tooltip title={label} arrow placement="top">
              <Chip label={label} color="error" size="small" />
            </Tooltip>
          );
        },
        muiFilterTextFieldProps: {
          sx: {
            '& .MuiInputAdornment-positionEnd': {
              display: 'none',
            },
          },
        },
        enableColumnActions: false,
      },
      {
        accessorKey: 'domain_type',
        header: t('Type'),
        enableColumnActions: false,
        columnFilterModeOptions: ['equals'],
        Cell: ({ cell }) => {
          const type = cell.getValue<number>();
          return (
            <Tooltip title={type} arrow placement="top">
              <span>{getDomainTypeName(type)}</span>
            </Tooltip>
          );
        },
      },
      {
        accessorKey: 'client',
        header: t('Client'),
        enableColumnActions: false,
        columnFilterModeOptions: ['equals'],
        Cell: ({ cell, row }) => {
          const label = clientLabel(cell.getValue<string>(), names?.client(cell.getValue<string>(), row.original.client_mac));
          return (
            <Tooltip title={label} arrow placement="top">
              <Box component="span" sx={clipSx}>{label}</Box>
            </Tooltip>
          );
        },
      },
      {
        accessorKey: 'timestamp',
        header: t('Time'),
        Cell: ({ cell }) => {
          const timestamp = cell.getValue<string>();
          const localTime = new Date(timestamp).toLocaleString('ru-RU');
          return <span>{localTime}</span>;
        },
        filterVariant: 'datetime-range',
        columnFilterModeOptions: ['equals'],
        enableColumnActions: false,
      },
      {
        accessorKey: 'ping_time',
        header: t('Ping'),
        enableColumnActions: false,
        Cell: ({ cell }) => {
          const pingTime = cell.getValue<number>();
          if (pingTime < 0) {
            return <span>N/A</span>;
          }
          return <span>{pingTime} ms</span>;
        },
        columnFilterModeOptions: ['equals'],
      },
      {
        accessorKey: 'domain_group',
        header: t('Group'),
        columnFilterModeOptions: ['equals'],
        enableColumnActions: false,
        Cell: ({ cell }) => {
          const group = cell.getValue<string>();
          if (!group || group === 'default') {
            return <span>{t('Default')}</span>;
          }
          const label = names?.group(group);
          if (!label) {
            return <span>{group}</span>;
          }
          return <span>{label.kind === 'rule' ? `${t('Rule')} «${label.name}»` : label.name}</span>;
        },
      },
      {
        accessorKey: 'query_time',
        header: t('Query Time'),
        Cell: ({ cell }) => {
          const queryTime = cell.getValue<number>();
          return <span>{queryTime} ms</span>;
        },
        columnFilterModeOptions: ['equals'],
        enableColumnActions: false,
      },
      {
        accessorKey: 'reply_code',
        header: t('Reply Code'),
        columnFilterModeOptions: ['equals'],
        enableColumnActions: false,
      },
    ],
    [t, names],
  );

  const [columnFilters, setColumnFilters] = useState<MRTColumnFiltersState>(
    [],
  );
  const [columnFilterFns, setColumnFilterFns] =
    useState<MRTColumnFilterFnsState>(
      () => Object.fromEntries(
        columns.map(({ accessorKey }) => {
          return [accessorKey, 'equals'];
        })
      ) as MRTColumnFilterFnsState
    );
  const [shouldFetchData, setShouldFetchData] = useState(false);
  const [globalFilter, setGlobalFilter] = useState('');
  const [errorMsg, setErrorMsg] = useState("Error loading data");
  const [sorting, setSorting] = useState<MRTSortingState>([]);
  const lastPage = React.useRef(0);
  const pageCursor = React.useRef<PageCursor | null>(null);

  // Load saved pagination settings
  const PAGINATION_KEY = 'querylog-table-pagination';
  const savedPagination = localStorage.getItem(PAGINATION_KEY);
  let jsonParsedPagination: MRTPaginationState = { pageIndex: 0, pageSize: 10 };

  try {
    if (savedPagination) {
      jsonParsedPagination = JSON.parse(savedPagination) as MRTPaginationState;
    }
  } catch {
    localStorage.removeItem(PAGINATION_KEY);
    jsonParsedPagination = { pageIndex: 0, pageSize: 10 };
  }

  const [pagination, setPagination] = useState<MRTPaginationState>({
    pageIndex: 0,
    pageSize: jsonParsedPagination.pageSize,
  });
  const [totalRowCount, setTotalRowCount] = useState(0);
  const totalCountFromParams = React.useRef(false);

  const { enqueueSnackbar } = useSnackbar();

  React.useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const filters: MRTColumnFiltersState = [];

    const timestamp: (dayjs.Dayjs | undefined)[] = [undefined, undefined];
    let existTimestamp = false;
    for (const [key, value] of searchParams.entries()) {
      if (key === 'timestamp_after') {
        const v = dayjs(Number(value));
        if (v.isValid()) {
          timestamp[0] = v;
          existTimestamp = true;
        }

        continue;
      }

      if (key === 'timestamp_before') {
        const v = dayjs(Number(value));
        if (v.isValid()) {
          timestamp[1] = v;
          existTimestamp = true;
        }

        continue;
      }

      if (key === 'total_count') {
        totalCountFromParams.current = true;
        setTotalRowCount(Number(value));
        continue;
      }

      if (!columns.some((column) => column.accessorKey === key)) {
        continue;
      }

      filters.push({ id: key, value });
    }

    if (existTimestamp) {
      filters.push({ id: 'timestamp', value: timestamp });
    }

    setColumnFilters(filters);
    if (!shouldFetchData) {
      setShouldFetchData(true);
    }
  }, [shouldFetchData, columns]);

  const {
    data: { data = [], meta } = {},
    isError,
    isRefetching,
    isLoading,
    refetch,
  } = useQuery<UserApiResponse>({
    enabled: shouldFetchData,
    queryKey: [
      'table-data',
      columnFilterFns,
      columnFilters,
      globalFilter,
      pagination.pageIndex,
      pagination.pageSize,
      sorting,
    ],
    queryFn: async () => {
      const currentPageNumber = pagination.pageIndex + 1;
      const queryParam: QueryLogsParams = {
        'page_num': currentPageNumber,
        'page_size': pagination.pageSize,
      };

      if (totalCountFromParams.current) {
        totalCountFromParams.current = false;
        queryParam['total_count'] = totalRowCount;
      }

      if (pageCursor.current !== null && pageCursor.current !== undefined) {
        if (currentPageNumber > lastPage.current && currentPageNumber === lastPage.current + 1) {
          if (pageCursor.current.lastID >= 0) {
            queryParam['cursor'] = pageCursor.current.lastID;
            queryParam['total_count'] = totalRowCount;
            queryParam['cursor_direction'] = 'next';
          }
        } else if (currentPageNumber < lastPage.current && currentPageNumber === lastPage.current - 1) {
          if (pageCursor.current.firstID >= 0) {
            queryParam['cursor'] = pageCursor.current.firstID;
            queryParam['total_count'] = totalRowCount;
            queryParam['cursor_direction'] = 'prev';
          }
        }
      }

      lastPage.current = currentPageNumber;

      for (const filter of columnFilters) {
        if (filter.id === null || filter.id === undefined || filter.value === null || filter.value === undefined) {
          continue;
        }

        const filterMode = columnFilterFns[filter.id];
        if (filter.id === 'domain' && filterMode === 'contains') {
          queryParam['domain_filter_mode'] = filterMode as string;
        }

        if (filter.id === 'timestamp') {
          const timerange = filter.value as string[];
          if (timerange.length === 2) {
            if (timerange[0]) {
              queryParam['timestamp_after'] = new Date(timerange[0]).getTime();
            }

            if (timerange[1]) {
              queryParam['timestamp_before'] = new Date(timerange[1]).getTime();
            }
          }
        }
        const filterId = filter.id as keyof QueryLogsParams;
        if (filter.id === 'domain_type') {
          const raw = filter.value as string;
          const resolved = /^\d+$/.test(raw)
            ? Number(raw)
            : getDomainTypeId(raw.toUpperCase());
          if (resolved !== undefined) {
            queryParam[filterId] = String(resolved);
          }
        } else {
          queryParam[filterId] = filter.value as string;
        }
      }

      const data = await smartdnsServer.GetQueryLogs(queryParam);
      if (data.error) {
        setErrorMsg(smartdnsServer.getErrorMessage(data.error));
        throw new Error(errorMsg);
      }

      if (data.data === null || data.data === undefined) {
        setErrorMsg('Error loading data');
        throw new Error(errorMsg);
      }

      let totalCount = 0;
      if (data.data.total_count > 0 && data.data.domain_list.length > 0) {
        const newPageCursor: PageCursor = {
          firstID: data.data.domain_list[0].id,
          lastID: data.data.domain_list.at(-1)!.id,
          pageNumber: currentPageNumber + 1,
        };

        pageCursor.current = newPageCursor;
        totalCount = data.data.total_count;
      }

      setTotalRowCount(totalCount)
      const resp: UserApiResponse = {
        data: data.data.domain_list,
        meta: {
          totalRowCount: totalCount,
        },
      };

      return resp;
    },
    placeholderData: keepPreviousData,
  });

  const handleClearLog = React.useCallback(async () => {
    if (!window.confirm(t('Clear the whole query log? This cannot be undone.'))) {
      return;
    }

    const ret = await smartdnsServer.ClearQueryLog();
    if (ret.error) {
      enqueueSnackbar(`${t('Error')}: ${t(smartdnsServer.getErrorMessage(ret.error))}`, { variant: 'error' });
      return;
    }

    enqueueSnackbar(t('Query log cleared.'), { variant: 'success' });
    pageCursor.current = null;
    await refetch();
  }, [t, enqueueSnackbar, refetch]);

  const { colorScheme } = useColorScheme();
  const tableTheme = React.useMemo(
    () => createTheme({ palette: { mode: colorScheme === 'dark' ? 'dark' : 'light' } }),
    [colorScheme],
  );
  const baseBackgroundColor = tableTheme.palette.background.paper;

  const [columnVisibility, onColumnVisibilityChange] = usePersistedVisibility('querylog-columns', defaultVisibility);

  const table = useMaterialReactTable({
    columns,
    data,
    localization: MRT_Localization_RU,
    ...compactTableOptions<DomainList>(),
    enableSorting: false,
    enableColumnOrdering: true,
    enableCellActions: true,
    enableClickToCopy: window.isSecureContext,
    enableGlobalFilter: false,
    columnFilterDisplayMode: 'popover',
    enableColumnFilterModes: true,
    enableColumnPinning: true,
    enableColumnDragging: false,
    enableKeyboardShortcuts: false,
    manualFiltering: true,
    manualPagination: true,
    manualSorting: true,
    muiFilterDateTimePickerProps: {
      ampm: false,
    },
    muiPaginationProps: {
      disabled: isRefetching,
    },
    muiToolbarAlertBannerProps: isError
      ? {
        color: 'error',
        children: errorMsg,
      }
      : undefined,
    onColumnFilterFnsChange: setColumnFilterFns,
    onColumnFiltersChange: (filters) => {
      pageCursor.current = null;
      setColumnFilters(filters);
    },
    onGlobalFilterChange: (filters: React.SetStateAction<string>) => {
      pageCursor.current = null;
      setGlobalFilter(filters);
    },
    onPaginationChange: (updaterOrValue) => {
      const newPagination =
        typeof updaterOrValue === 'function'
          ? updaterOrValue(pagination)
          : updaterOrValue;
      setPagination(newPagination);
      localStorage.setItem(PAGINATION_KEY, JSON.stringify(newPagination));
    },
    onSortingChange: setSorting,
    onColumnVisibilityChange,
    renderTopToolbarCustomActions: () => (
      <>
        <Tooltip arrow title={t("Refresh Data")}>
          <span>
            <IconButton
              disabled={isRefetching}
              onClick={() => {
                pageCursor.current = null;
                refetch().catch((_error: unknown) => {
                  // NOOP
                });
              }
              }>
              <RefreshIcon />
            </IconButton>
          </span>
        </Tooltip>
        <Tooltip arrow title={t("Clear query log")}>
          <span>
            <IconButton
              disabled={isRefetching}
              onClick={() => {
                handleClearLog().catch((_error: unknown) => {
                  // NOOP
                });
              }
              }>
              <DeleteSweep />
            </IconButton>
          </span>
        </Tooltip>
      </>
    ),
    muiLinearProgressProps: {
      color: 'primary',
      variant: 'determinate',
      value: isRefetching ? 50 : 100,
    },
    rowCount: meta?.totalRowCount ?? 0,
    initialState: {
      density: 'compact',
      pagination: {
        pageIndex: 0,
        pageSize: jsonParsedPagination.pageSize,
      },
    },
    state: {
      columnFilters,
      columnFilterFns,
      globalFilter,
      isLoading,
      pagination,
      columnVisibility,
      showAlertBanner: isError,
      showProgressBars: isRefetching,
      showSkeletons: isLoading,
      sorting,
    },
    mrtTheme: (_theme) => ({
      baseBackgroundColor,
    }),
  });

  return (<MaterialReactTable table={table} />);
};

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      gcTime: 0,
      retry: false,
    },
  },
});


export function QueryLogTable(): React.JSX.Element {

  const [state, setState] = React.useState<SnackbarOrigin>({
    vertical: 'top',
    horizontal: 'left',
  });

  React.useEffect(() => {
    const mediaQuery = window.matchMedia('(max-width: 600px)');
    const handleMediaQueryChange = (event: MediaQueryListEvent): void => {
      if (event.matches) {
        setState({ vertical: 'top', horizontal: 'left' });
      } else {
        setState({ vertical: 'bottom', horizontal: 'left' });
      }
    };

    if (mediaQuery.matches) {
      setState({ vertical: 'top', horizontal: 'left' });
    } else {
      setState({ vertical: 'bottom', horizontal: 'left' });
    }

    mediaQuery.addEventListener('change', handleMediaQueryChange);

    return () => {
      mediaQuery.removeEventListener('change', handleMediaQueryChange);
    };
  }, [setState]);

  return (
    <QueryClientProvider client={queryClient}>
      <SnackbarProvider
        anchorOrigin={state}
        maxSnack={5} autoHideDuration={6000}>
        <TableQueryLogs />
      </SnackbarProvider>
    </QueryClientProvider>
  );
}
