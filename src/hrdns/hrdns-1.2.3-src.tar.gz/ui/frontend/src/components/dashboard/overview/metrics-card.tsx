"use client";

import * as React from 'react';
import Box from '@mui/material/Box';
import { useTranslation } from 'react-i18next';

export type MetricsTone = 'ok' | 'warn' | 'bad';

interface MetricsCardProps {
    title: string;
    value: React.ReactNode;
    detail?: React.ReactNode;
    action?: React.ReactNode;
    onClick?: () => void;
}

export function MetricsUnit({ children }: { children: React.ReactNode }): React.JSX.Element {
    return <Box component="span" sx={{ ml: '3px', fontSize: 14, fontWeight: 500, letterSpacing: 0, color: 'var(--mui-palette-dashboard-label)' }}>{children}</Box>;
}

export function MetricsPill({ tone, children }: { tone: MetricsTone; children: React.ReactNode }): React.JSX.Element {
    return (
        <Box component="span" sx={{
            display: 'inline-flex', alignItems: 'center', gap: '6px', height: 22, px: '9px', borderRadius: 999,
            fontSize: 11.5, fontWeight: 600, whiteSpace: 'nowrap',
            bgcolor: `var(--mui-palette-dashboard-${tone}Soft)`, color: `var(--mui-palette-dashboard-${tone})`,
            '&::before': { content: '""', width: 6, height: 6, borderRadius: '50%', bgcolor: 'currentColor' },
        }}>
            {children}
        </Box>
    );
}

export function MetricsBar({ percent, tone }: { percent: number; tone: 'ok' | 'warn' }): React.JSX.Element {
    return (
        <Box sx={{ flex: 1, height: 6, borderRadius: 999, overflow: 'hidden', bgcolor: 'var(--mui-palette-dashboard-track)' }}>
            <Box sx={{ width: `${percent}%`, height: '100%', borderRadius: 'inherit', bgcolor: `var(--mui-palette-dashboard-${tone}Fill)` }} />
        </Box>
    );
}

export function MetricsSpark({ history }: { history: number[] }): React.JSX.Element {
    const height = 22;
    const max = Math.max(1, ...history) * 1.15;
    const last = history.length - 1;
    const points = history.map((v, i) => `${(last ? i / last * 100 : 100).toFixed(2)},${(height - v / max * height).toFixed(2)}`).join(' L');
    return (
        <Box component="svg" viewBox={`0 0 100 ${height}`} preserveAspectRatio="none" aria-hidden="true" sx={{ display: 'block', width: '100%', height, overflow: 'visible' }}>
            {history.length > 1 ? <>
                <path d={`M0,${height} L${points} L100,${height} Z`} fill="var(--mui-palette-dashboard-sparkFill)" />
                <path d={`M${points}`} fill="none" stroke="var(--mui-palette-dashboard-spark)" strokeWidth={1.6} vectorEffect="non-scaling-stroke" />
            </> : null}
        </Box>
    );
}

export function MetricsCard({ title, value, detail, action, onClick }: MetricsCardProps): React.JSX.Element {
    const { t } = useTranslation();
    return (
        <Box
            className="metrics-card"
            role={onClick ? 'link' : undefined}
            tabIndex={onClick ? 0 : undefined}
            onClick={onClick}
            onKeyDown={onClick ? (e) => { if (e.key === 'Enter') onClick(); } : undefined}
            sx={{
                display: 'flex', flexDirection: 'column', gap: 1, minWidth: 0,
                p: { xs: '10px 12px 12px', sm: '12px 14px 14px' }, borderRadius: '12px',
                bgcolor: 'var(--mui-palette-dashboard-card)',
                ...(onClick && {
                    cursor: 'pointer', transition: 'background-color 0.18s ease',
                    '&:hover': { bgcolor: 'var(--mui-palette-dashboard-cardHover)' },
                }),
            }}
        >
            <Box sx={{
                display: 'flex', alignItems: 'flex-start', gap: '6px', minHeight: 34,
                fontSize: 12.5, lineHeight: '17px', fontWeight: 500, overflowWrap: 'anywhere',
                color: 'var(--mui-palette-dashboard-label)',
            }}>
                <Box component="span" sx={{ flex: 1, minWidth: 0 }}>{t(title)}</Box>
                {action}
            </Box>
            <Box sx={{
                fontFamily: '"Roboto Mono", monospace', fontWeight: 600, lineHeight: 1.15, fontSize: { xs: 20, sm: 24 }, letterSpacing: '-0.02em',
                fontVariantNumeric: 'tabular-nums', overflowWrap: 'anywhere', color: 'var(--mui-palette-dashboard-value)',
            }}>
                {value}
            </Box>
            <Box sx={{
                display: 'flex', alignItems: 'center', gap: 1, minHeight: 22, mt: 'auto',
                fontSize: 12, fontVariantNumeric: 'tabular-nums', color: 'var(--mui-palette-dashboard-label)',
            }}>
                {detail}
            </Box>
        </Box>
    );
}
