"use client";

import * as React from 'react';
import Box from '@mui/material/Box';

import { MainNav } from '@/components/dashboard/layout/main-nav';

interface LayoutProps {
  children: React.ReactNode;
}

export default function ClientLayout({ children }: LayoutProps): React.JSX.Element {
  return (
    <Box
      sx={{
        bgcolor: 'var(--mui-palette-background-default)',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        minHeight: '100%',
      }}
    >
      <MainNav />
      {children}
    </Box>
  );
}
