package api

import (
	"encoding/json"
	"errors"
	"math"
	"net/http"
	"strconv"
	"strings"
)

var (
	logLevels     = []string{"debug", "info", "notice", "warn", "error", "fatal", "off"}
	securityNames = []string{"Unknown", "Not Applicable", "Verify Failed", "Insecure", "Secure"}
)

func (s *Server) cacheCount(w http.ResponseWriter, r *http.Request) error {
	data, err := s.call(r, "cache.count")
	if err != nil {
		return err
	}

	writeRaw(w, http.StatusOK, data)
	return nil
}

func (s *Server) cacheFlush(w http.ResponseWriter, r *http.Request) error {
	data, err := s.call(r, "cache.flush")
	if err != nil {
		return err
	}

	writeRaw(w, http.StatusOK, data)
	return nil
}

func (s *Server) cacheDomains(w http.ResponseWriter, r *http.Request) error {
	data, err := s.call(r, "cache.list")
	if err != nil {
		return err
	}

	var entries []struct {
		Domain string `json:"domain"`
		QType  int    `json:"qtype"`
		TTL    int    `json:"ttl"`
		Time   int64  `json:"time"`
	}
	if err := json.Unmarshal(data, &entries); err != nil {
		return err
	}

	out := make([]map[string]any, len(entries))
	for i, e := range entries {
		out[i] = map[string]any{"cached_time": e.Time, "domain": e.Domain, "id": i + 1, "qtype": e.QType, "ttl_remaining": e.TTL}
	}

	writeJSON(w, http.StatusOK, map[string]any{"domains": out})
	return nil
}

func round1(v float64) float64 { return math.Round(v*10) / 10 }

func (s *Server) upstreamServers(w http.ResponseWriter, r *http.Request) error {
	data, err := s.call(r, "servers")
	if err != nil {
		return err
	}

	var servers []struct {
		Host           string  `json:"host"`
		IP             string  `json:"ip"`
		Port           int     `json:"port"`
		Type           string  `json:"type"`
		Iface          string  `json:"iface"`
		Fallback       bool    `json:"fallback"`
		ExcludeDefault bool    `json:"exclude_default"`
		Alive          bool    `json:"alive"`
		Security       int     `json:"security"`
		Total          uint64  `json:"total"`
		Success        uint64  `json:"success"`
		Recv           uint64  `json:"recv"`
		AvgTime        float64 `json:"avg_time"`
	}
	if err := json.Unmarshal(data, &servers); err != nil {
		return err
	}

	out := make([]map[string]any, len(servers))
	for i, sv := range servers {
		status := "Normal"
		if sv.Total == 0 {
			status = "Unknown"
		} else if !sv.Alive {
			status = "Abnormal"
		}

		rate := 0.0
		if sv.Total > 0 {
			rate = round1(float64(sv.Success) / float64(sv.Total) * 100)
		}

		security := securityNames[0]
		if sv.Security >= 0 && sv.Security < len(securityNames) {
			security = securityNames[sv.Security]
		}

		out[i] = map[string]any{
			"avg_time": round1(sv.AvgTime), "host": sv.Host, "ip": sv.IP, "port": sv.Port, "query_success_rate": rate,
			"iface": sv.Iface, "fallback": sv.Fallback, "exclude_default": sv.ExcludeDefault,
			"security": security, "server_type": sv.Type, "status": status, "total_query_count": sv.Total,
			"total_query_recv_count": sv.Recv, "total_query_success": sv.Success,
		}
	}

	writeJSON(w, http.StatusOK, map[string]any{"upstream_server_list": out})
	return nil
}

func levelIndex(name string) int {
	for i, n := range logLevels {
		if n == name {
			return i
		}
	}

	return -1
}

func (s *Server) logLevelGet(w http.ResponseWriter, r *http.Request) error {
	data, err := s.call(r, "log.get")
	if err != nil {
		return err
	}

	var v struct {
		LogLevel int `json:"log_level"`
	}
	if err := json.Unmarshal(data, &v); err != nil || v.LogLevel < 0 || v.LogLevel >= len(logLevels) {
		return errors.New("resolver returned an unknown log level")
	}

	writeJSON(w, http.StatusOK, map[string]string{"log_level": logLevels[v.LogLevel]})
	return nil
}

func (s *Server) logLevelPut(w http.ResponseWriter, r *http.Request) error {
	var body struct {
		LogLevel string `json:"log_level"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1024)).Decode(&body); err != nil {
		return &apiError{http.StatusBadRequest, "log level is invalid"}
	}

	level := levelIndex(strings.ToLower(body.LogLevel))
	if level < 0 {
		return &apiError{http.StatusBadRequest, "log level is invalid"}
	}

	if _, err := s.call(r, "log.set "+strconv.Itoa(level)); err != nil {
		return err
	}

	writeNoContent(w)
	return nil
}

func (s *Server) restart(w http.ResponseWriter, r *http.Request) error {
	if _, err := s.call(r, "restart"); err != nil {
		return err
	}

	writeNoContent(w)
	return nil
}
